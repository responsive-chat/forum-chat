<?PHP

$id = md5(rand(6000,PHP_INT_MAX));
?>
<? 
    $yourdomain = $_SERVER['HTTP_HOST'];
    $yourdomain = preg_replace('/^www\./' , '' , $yourdomain);
    ?>
<!DOCTYPE html>
<html lang="en"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
      <title>Free web hosting | Free domain name</title>
    <meta name="description" content="Free and unlimited web hosting, free domain name, create personal website">
	<meta name="keywords" content="ufaso hostingi, ufaso domeni, domenis registracia, saitis sheqmna, saitis awyoba, saitis gaketeba, make website, make a website, build website, website builder, free hosting, free web hosting, free domain, free domain registration,hosting,linux hosting, shared hosting, shared web hosting, saziaro hostingi, cpanel hosting, cpanel web hosting, linux web hosting">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <link rel="stylesheet" href="./files/bootstrap.min.css">
      <script src="./files/jquery.min.js.download"></script>
      <script src="./files/popper.min.js.download"></script>
      <script src="./files/bootstrap.min.js.download"></script>
<meta property="og:image" content="http://pw.ge/files/image.jpg">
<meta property="og:url" content="http://pw.ge">
   <body>
      <nav class="navbar navbar-expand-sm bg-dark">

         <ul class="navbar-nav">
            <li class="nav-item">
               <img src="./files/logo.jpg">
            </li>
         </ul>
      </nav>
    <br>
      <div class="jumbotron text-center">
  <div class="alert alert-info">
    <b>Welcome to <?echo $yourdomain;?> Hosting</b><br>
	<small>We are specialists in free hosting services using clustered technology powered by one of the largest hosting organizations on the internet. Sign up here for fast free PHP & MySQL hosting including a free sub domain. A powerful control panel provided to manage your website, packed with hundreds of great features including website building tools, SEO tools, FTP add-on domain and much more.</small>
	</div>
  <br><br>
         <div class="container mt-3">
            <h3>Control panel</h3>
            <br>
            <form action="http://cpanel.<?echo $yourdomain;?>/login.php" method="post" name="login" >
               <div class="input-group mb-3">
                  <div class="input-group-prepend">
                     <span class="input-group-text">&#128273;</span>
                  </div>
                  <input type="text" name="uname" id="mod_login_username" class="form-control" placeholder="Username" name="username">
               </div>
               <div class="input-group mb-3">
                  <div class="input-group-prepend">
                     <span class="input-group-text">&#128274;</span>
                  </div>
                  <input type="text" class="form-control" placeholder="Password" id="mod_login_password" name="passwd">
               </div>
         </div>
         <button type="submit" class="btn btn-primary">Login</button></form>
		 <br><br><a class="btn btn-primary" href="http://cpanel.<?echo $yourdomain;?>/lostpassword.php">Forgot your password?</a><br><br>
  <br>
                  <div class="container mt-3">
            <h3>Create a website</h3>
            <br>
            <form method=post action="http://order.<?echo $yourdomain;?>/register2.php">
               <div class="input-group mb-3">
                  <div class="input-group-prepend">
                     <span class="input-group-text">&#127760;</span>
                  </div>
                  <input type="text" class="form-control" placeholder="Site address" name="username" onkeyup="return ismaxlength(this)"><span class="input-group-text">.<?echo $yourdomain;?></span>
               </div>
               <div class="input-group mb-3">
                  <div class="input-group-prepend">
                     <span class="input-group-text">&#128274;</span>
                  </div>
                  <input type="text" class="form-control" placeholder="Password" name="password" onkeyup="return ismaxlength(this)">
               </div>
			   <div class="input-group mb-3">
                  <div class="input-group-prepend">
                     <span class="input-group-text">&#128231;</span>
                  </div>
                  <input type="text" class="form-control" placeholder="E-mail" name="email">
               </div>
			   <div class="input-group mb-3">
                  <div class="input-group-prepend">
                     <span class="input-group-text"><img src="http://order.<? echo "$yourdomain" ;?>/image.php?id=<?PHP echo $id; ?>"></span>
                  </div>
				  <input type=hidden name=id value="<?PHP echo $id; ?>">
                  <input type="text" class="form-control" placeholder="Enter code" name="number">
               </div>
         </div>
         <button type="submit" class="btn btn-primary">Register</button></form>
		 <br>
<?php include "banner.php"; ?>   

</div>

</body></html>