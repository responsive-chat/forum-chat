<center><br><font color="black">&copy; 2020 <?echo $yourdomain;?></font><br><br>

</center>