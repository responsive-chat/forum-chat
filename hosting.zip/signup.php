<?PHP

$id = md5(rand(6000,PHP_INT_MAX));
?>
<? 
    $yourdomain = $_SERVER['HTTP_HOST'];
    $yourdomain = preg_replace('/^www\./' , '' , $yourdomain);
    ?>