<?php


	require 'sys/inc/core.php';

only_reg();

		switch(MODE)
	{
	default:
	
	{

	show_title('კაბინეტი');

	$expressions = file(CONFIG_DIR.'popular_expressions.ini');
	unset($expressions[0]);
	$template -> rand_expression = $expressions[array_rand($expressions)];

	$phase_day = 'ღამე მშვიდობისა';
	$hour = date('G');
	if($hour > 6 && $hour < 12)$phase_day = 'დილა მშვიდობისა';
	elseif($hour > 12 && $hour < 18)$phase_day = 'მშვიდობიანი დღე';
	elseif($hour > 18 && $hour < 23)$phase_day = 'საღამო მშვიდობისა';

	$template -> phase_day = $phase_day;

	$template -> count_bookmarks = $db -> one("SELECT COUNT(*) FROM `topics_bookmarks` WHERE `user_id` = '".USER_ID."'");

	$template -> block = 'index';

	}
	break;
	
	case 'answers_posts':
	
	{

	show_title('კაბინეტი', 'პასუხი ჩემს პოსტებზე');

	$count_answers = $db -> one("SELECT COUNT(*) FROM `posts_answers` WHERE `user_id` = '".USER_ID."'");
	if($count_answers > 0)
		{
		check_page($count_answers, PATH.'umenu.php?answers_posts');

		$template_answers = array();

		$i = START_POSTS;

				while($answer = $db -> fetch("SELECT *,(SELECT `name` FROM `topics` WHERE `topics`.`id` = `posts_answers`.`tid`) AS topic_name FROM `posts_answers` WHERE `user_id` = '".USER_ID."' ORDER BY `answer_pid` DESC, `pid` DESC LIMIT ".START_POSTS.",".ONPAGE_POSTS))
			{
			$i ++;

			$template_answer = array('i' => $i,'tid' => $answer['tid'], 'topic_name' => $answer['topic_name'], 'date' => xdate($answer['date']), 'answer_user' => get_user($answer['answer_user']), 'answer_pid' => $answer['answer_pid']);

			$template_answers[] = $template_answer;
			}

		$template -> assign('answers', $template_answers);

		}

	$template -> block = 'answers_posts';

	}
	break;
	
	case 'set':
	
	{

	show_title('კაბინეტი', 'პარამეტრები');

	if(postval('save', 1))
		{
		check_fields(PATH.'umenu.php?mode=set', array(array('onpage_topics', 'not null'), array('onpage_posts', 'not null'), array('time_shift', 'values' => range(-12,12))));

		$onpage_topics = int($_POST['onpage_topics']);
		$onpage_posts = int($_POST['onpage_posts']);
		if($onpage_topics > 50 || $onpage_topics < 3)$onpage_topics = $cfg['onpage_topics'];
		if($onpage_posts > 70 || $onpage_posts < 5)$onpage_posts = $cfg['onpage_posts'];
		$time_shift = $_POST['time_shift'];
		$fast_post = postval('fast_post', 1, false);

		if($db -> sql("UPDATE `users` SET `set_onpage_topics` = '$onpage_topics', `set_onpage_posts` = '$onpage_posts', `set_time_shift` = '$time_shift', `set_fast_post` = '$fast_post' WHERE `id` = '".USER_ID."'"))
			{
			msg('პარამეტრები შეიცვალა', PATH.'index.php');
			}
		else
			{
			err('შეცდომა', PATH.'umenu.php?mode=set');
			}

		}

	$template -> assign(array
		(
		'set_onpage_topics'	 => $userdata['set_onpage_topics'],
		'set_onpage_posts'	 => $userdata['set_onpage_posts'],
		'set_fast_post'	 => (bool)$userdata['set_fast_post']
		)
	);

	$template_times = array();
			for($i = -12;$i <= 12;$i ++)
		{
		$template_time = array('time' => date('d.m G:i', TIME + ($i * 3600)), 'shift' => $i);
		if($userdata['set_time_shift'] == $i)$template_time['selected'] = ' selected="selected"';

		$template_times[] = $template_time;
		}

	$template -> assign('times', $template_times);

	$template -> block = 'set';

	}
	break;
	
	case 'profile':
	
	{

	show_title('კაბინეტი', 'პაროლის შეცვლა');

	if(postval('save', 1))
		{
		check_fields(PATH.'umenu.php?mode=profile', array(array('pass', 'not null'), array('npass', 'not null'), array('npass2', 'not null')));

		$pass = trim($_POST['pass']);
		$npass = trim($_POST['npass']);
		$npass2 = trim($_POST['npass2']);

		if(!LOCALHOST)sleep(3);

		if(get_hash($pass) == $userdata['password'])
			{
			if($npass == $npass2)
				{
				$pass_hash = get_hash($npass);
				if($db -> sql("UPDATE `users` SET `password` = '$pass_hash' WHERE `id` = '".USER_ID."'"))
					{
					$_SESSION['userdata']['password'] = $pass_hash;
					xcookie('user_password', base64_encode(get_int_hash($pass_hash)));
					msg('პაროლი შეიცვალა '.$npass, PATH.'index.php');
					}
				else
					{
					err('შეცდომა', PATH.'umenu.php?mode=profile');
					}
				}
			else
				{
				err('პაროლები განსხვავდება', PATH.'umenu.php?mode=profile');
				}
			}
		else
			{
			err('პაროლი არასწორია', PATH.'umenu.php?mode=profile');
			}


		}

	$template -> block = 'profile';

	}
	break;
	
	case 'info':
	
	{

	show_title('კაბინეტი', 'ანკეტა');

	if(postval('save', 1))
		{
		check_fields(PATH.'umenu.php?mode=info', array(array('name', 'maxlen' => 50), array('city', 'maxlen' => 70), array('email', 'maxlen' => 100), array('tel', 'maxlen' => 50), array('site', 'maxlen' => 50), array('about', 'maxlen' => 500), array('interest', 'maxlen' => 500), array('sex', 'values' => array('0', '1')), array('avatar', 'maxlen' => 5000)));

		$name = str($_POST['name']);
		$birthday = str($_POST['birthday']);
		$city = str($_POST['city']);
		$email = str($_POST['email']);
		$tel = str($_POST['tel']);
		$site = str($_POST['site']);
		$about = str($_POST['about']);
		$interest = str($_POST['interest']);
		$avatar = str($_POST['avatar']);
		$sex = int($_POST['sex']);

		if($db -> sql("UPDATE `users` SET `info_name` = '$name', `info_birthday` = '$birthday', `info_city` = '$city', `info_email` = '$email', `info_tel` = '$tel', `info_site` = '$site', `info_about` = '$about', `info_interest` = '$interest', `info_avatar` = '$avatar', `info_sex` = '$sex' WHERE `id` = '".USER_ID."'"))
			{
			msg('პროფილი შეიცვალა', PATH.'index.php');
			}
		else
			{
			err('შეცდომა', PATH.'umenu.php?mode=info');
			}


		}

	$template -> user_info_name = $userdata['info_name'];
	
	$template -> user_info_birthday = $userdata['info_birthday'];

	$template -> user_info_city = $userdata['info_city'];
	
	$template -> user_info_email = $userdata['info_email'];
	
	$template -> user_info_tel = $userdata['info_tel'];
	
	$template -> user_info_site = $userdata['info_site'];
	
	$template -> user_info_about = $userdata['info_about'];
	
	$template -> user_info_interest = $userdata['info_interest'];

	$template -> user_info_avatar = $userdata['info_avatar'];

	$template -> user_info_sex = $userdata['info_sex'];

	$template -> block = 'info';

	}
	break;
	
	case 'private':
	
	{

	
	if($db -> one("SELECT COUNT(*) FROM `users_punishes` WHERE `user_id` = '".USER_ID."' AND `to_date` > '".TIME."' AND `close_private` = '1'") > 0)err('პირადი ფოსტა დახურულია თქვენთვის', PATH.'umenu.php');

			switch(ACT)
		{
		default:
		
		{

		show_title('კაბინეტი', 'პირადი ფოსტა');

		
		if(isset($_GET['adduser']) && postval('add', 1))
			{
			check_fields(PATH.'umenu.php?mode=private&'.RAND, array(array('nick', 'not null', 'maxlen' => 40, 'minlen' => 3)));

			$nick = str($_POST['nick']);

			if($db -> one("SELECT COUNT(*) FROM `users` WHERE `nick` = '$nick'") > 0)locate(PATH.'umenu.php?mode=private&act=user&id='.$db -> one("SELECT `id` FROM `users` WHERE `nick` = '$nick'"));
			else locate(PATH.'umenu?mode=private&'.RAND);

			}

		$count_contacts = $db -> one("SELECT COUNT(*) FROM `private_contacts` WHERE `user_id` = '".USER_ID."' OR `contact_user_id` = '".USER_ID."'");
		if($count_contacts > 0)
			{
			check_page($count_contacts, PATH.'umenu?mode=private&page={$page}', ONPAGE_TOPICS);

			$template_contacts = array();

			$i = START_TOPICS;

					while($contact = $db -> fetch("SELECT IF(`p_c`.`user_id` = '".USER_ID."', `p_c`.`contact_user_id`, `p_c`.`user_id`) AS `c_user_id`, `u`.`nick` AS `user_nick`, (SELECT COUNT(*) FROM `private_messages` WHERE ((`user_id` = '".USER_ID."' AND `to_user_id` = `c_user_id`) OR (`to_user_id` = '".USER_ID."' AND `user_id` = `c_user_id`))) AS `count_messages`, (SELECT COUNT(*) FROM `private_messages` WHERE `new` = '1' AND `to_user_id` = '".USER_ID."' AND `user_id` = `c_user_id`) AS `count_new_messages`, (SELECT MAX(`date`) FROM `private_messages` WHERE ((`user_id` = '".USER_ID."' AND `to_user_id` = `c_user_id`) OR (`to_user_id` = '".USER_ID."' AND `user_id` =  `c_user_id`))) AS `last_message`
FROM `private_contacts` AS `p_c`, `users` AS `u`
WHERE (`p_c`.`user_id` = '".USER_ID."' OR `p_c`.`contact_user_id` = '".USER_ID."') AND `u`.`id` = IF(`p_c`.`user_id` = '".USER_ID."', `p_c`.`contact_user_id`, `p_c`.`user_id`)
ORDER BY `last_message` DESC, `count_new_messages` DESC, `user_nick` ASC
LIMIT ".START_TOPICS.",".ONPAGE_TOPICS))
				{
				$i ++;

				

				$template_contact = array('i' => $i, 'user_id' => $contact['c_user_id'], 'user_nick' => $contact['user_nick'], 'count_messages' => $contact['count_messages']);

				if(!empty($contact['last_message']))$template_contact['date'] = 'ბოლო შეტყობინებები: '.xdate($contact['last_message']);

				if(!empty($contact['count_new_messages']))$template_contact['count_new_messages'] = '/<font color="red">+'.$contact['count_new_messages'].'</font>';

				$template_contacts[] = $template_contact;
				}

			$template -> assign('contacts', $template_contacts);

			pagebar($str, PAGE, PATH.'umenu?mode=private&page={$page}');

			}

		$template -> block = 'private';

		}
		break;

		case 'remove':
{

if(!$db -> sql("DELETE FROM `private_contacts` WHERE `user_id` = '".USER_ID."'"))
				{
				err('შეცდომა', PATH.'umenu.php?mode=private');
				}
				err('კონტაქტები ამოიშალა', PATH.'umenu.php?mode=private');
				}
	
		case 'delete':
{

if(!$db -> sql("DELETE FROM `private_messages` WHERE `user_id` = '".USER_ID."'"))
				{
				err('შეცდომა', PATH.'umenu.php?mode=private');
				}
				err('წერილები გასუფთავდა', PATH.'umenu.php?mode=private');
				}
		
		case 'user':
		
		{

		if(ID == 0 || ID == USER_ID)locate(PATH.'umenu?mode=private');

		
		if($db -> one("SELECT COUNT(*) FROM `private_contacts` WHERE (`user_id` = '".USER_ID."' AND `contact_user_id` = '".ID."') OR (`user_id` = '".ID."' AND `contact_user_id` = '".USER_ID."')") == 0)
			{
			if(!$db -> sql("INSERT INTO `private_contacts` SET `user_id` = '".USER_ID."', `contact_user_id` = '".ID."'"))
				{
				err('შეცდომა', PATH.'umenu.php?mode=private');
				}
			}

		$user_nick = get_user(ID);

		$template -> assign('user', array('id' => ID, 'nick' => $user_nick));

		show_title('კაბინეტი', 'პირადი ფოსტა: '.$user_nick);

		if(isset($_GET['add']) && postval('add', 1))
			{
			if($cfg['time_antispam_private'] > 0 && USER_LEVEL < USER_ADMIN)
				{
				if(($last_post = $db -> one("SELECT MAX(`date`) FROM `private_messages` WHERE `user_id` = '".USER_ID."'")) > 0)
					{
					if((TIME - $last_post) < $cfg['time_antispam_private'])
						{
						err('თქვენ არ შეგიძლიათ ასე სწრაფად წერილების გაგზავნა', PATH.'umenu.php?mode=private&act=user&id='.ID.'&'.RAND);
						}
					}
				}

			check_fields(PATH.'umenu.php?mode=private&act=user&id='.ID.'&'.RAND, array(array('post', 'not null', 'minlen' => 2, 'maxlen' => $cfg['maxlen_post'])));

			$post = str($_POST['post']);

			

			if(USER_LEVEL < USER_ADMIN && $db -> one("SELECT COUNT(*) FROM `private_messages` WHERE `user_id` = '".USER_ID."' AND `date` > ('".TIME."' - 300) AND `text` = '$post'") > 0)
				{
				err('თქვენი შეტყობინება იმეორებს წინას', PATH.'umenu.php?mode=private&act=user&id='.ID.'&'.RAND);
				}

			if($db -> sql("INSERT INTO `private_messages` SET `user_id` = '".USER_ID."', `to_user_id` = '".ID."', `date` = '".TIME."', `text` = '$post', `ip` = '".MY_INT_IP."', `ua` = '".MY_UA."', `new` = '1'"))
				{
				msg('შეტყობინრბა დაემატა', PATH.'umenu.php?mode=private&act=user&id='.ID.'&'.RAND.'#message-'.($db -> last_id()));
				}
			else
				{
				err('შეცდომა', PATH.'umenu.php?mode=private&act=user&id='.ID.'&'.RAND);
				}

			}

		
		$count_messages = $db -> one("SELECT COUNT(*) FROM `private_messages` WHERE (`user_id` = '".USER_ID."' AND `to_user_id` = '".ID."') OR (`user_id` = '".ID."' AND `to_user_id` = '".USER_ID."')");
		if($count_messages > 0)
			{
			check_page($count_messages, PATH.'umenu.php?mode=private&act=user&id='.ID.'&page={$page}');

			$template_messages = array();

			
			$readed_messages = array();

			$i = $count_messages;
			if(PAGE > 1)
				{
				$i -= (PAGE - 1) * ONPAGE_TOPICS;
				}

					while($message = $db -> fetch("SELECT * FROM `private_messages` WHERE (`user_id` = '".USER_ID."' AND `to_user_id` = '".ID."') OR (`user_id` = '".ID."' AND `to_user_id` = '".USER_ID."') ORDER BY `date` DESC LIMIT ".START_POSTS.",".ONPAGE_POSTS))
				{

				$template_message = array('i' => $i, 'id' => $message['id'], 'new' => ($message['new'] ? '<b>-&gt;</b>' : null), 'date' => xdate($message['date']), 'text' => post($message['text']), 'ip' => long2ip($message['ip']), 'ua' => $message['ua'], 'who' => ($message['user_id'] == USER_ID ? 'მე' : 'ის'));

				if($message['new'] && $message['user_id'] != USER_ID)
					{
					$readed_messages[] = $message['id'];
					}

				$i --;

				$template_messages[] = $template_message;
				}

			
			if(!empty($readed_messages))$db -> sql("UPDATE `private_messages` SET `new` = '0' WHERE `id` IN (".implode(',', $readed_messages).")");

			$template -> assign('messages', $template_messages);

			pagebar($str, PAGE, PATH.'umenu.php?mode=private&act=user&id='.ID.'&page={$page}');

			}

		$template -> block = 'private_user';

		}
		break;
		}

	}
	break;
	
	case 'bookmarks':
	
	{

	show_title('კაბინეტი', 'სანიშნი');

	
	$type = (!empty($_GET['type']) && in_array($_GET['type'], array('all', 'new'))) ? $_GET['type'] : 'all';

	$count_topics = $db -> one("SELECT COUNT(*)
FROM `topics` AS `t`, `topics_bookmarks` AS `t_b`
WHERE `t_b`.`user_id` = '".USER_ID."' AND `t`.`id` = `t_b`.`tid`".($type == 'new' ? 'AND `t`.`last_date` > `t_b`.`date`' : null));


	if(ID > 0 && $count_topics > 0)
		{
		if($db -> one("SELECT COUNT(*) FROM `topics_bookmarks` WHERE `tid` = '".ID."' AND `user_id` = '".USER_ID."'") == 0)locate(PATH.'umenu.php?mode=bookmarks&'.RAND);

		if($db -> sql("DELETE FROM `topics_bookmarks` WHERE `tid` = '".ID."' AND `user_id` = '".USER_ID."'"))
			{
			msg('ჩანიშნული წაიშალა', PATH.'umenu.php?mode=bookmarks&'.RAND);
			}
		else
			{
			err('შეცდომა', PATH.'umenu.php?mode=bookmarks&'.RAND);
			}

		}


	if($count_topics > 0)
		{
		check_page($count_topics, PATH.'umenu.php?mode=bookmarks&type='.$type.'&page={$page}', ONPAGE_TOPICS);

		$template_topics = array();

		$i = START_TOPICS;

				while($topic = $db -> fetch("SELECT `t`.`id`, `t`.`name`, `t`.`last_user_id`, `t`.`date`, `t`.`count_posts`, `u`.`nick` AS `last_user`
FROM `topics` AS `t`, `topics_bookmarks` AS `t_b`, `users` AS `u`
WHERE `t_b`.`user_id` = '".USER_ID."' AND `u`.`id` = IF(`t`.`last_user_id` > 0, `t`.`last_user_id`, `t`.`user_id`) AND `t`.`id` = `t_b`.`tid`".($type == 'new' ? 'AND `t`.`last_date` > `t_b`.`date`' : null)."
ORDER BY `t`.`last_date`, `t`.`date` DESC
LIMIT ".START_TOPICS.", ".ONPAGE_TOPICS))
			{
			$i ++;

			$template_topic = array('i' => $i, 'id' => $topic['id'], 'name' => $topic['name'], 'user' => $topic['last_user'], 'date' => xdate($topic['date']), 'count_posts' => $topic['count_posts'], 'i' => $i);

			$template_topics[] = $template_topic;
			}

		$template -> assign('topics', $template_topics);

		pagebar($str, PAGE, PATH.'umenu.php?mode=bookmarks&type='.$type.'&page={$page}');

		}

	$template -> type = $type;

	$template -> block = 'bookmarks';

	}
	break;
	}

$template -> display('umenu.page');



show_foot();


?>