<?php

	require_once 'sys/inc/core.php';

if(ID > 0 && $db -> one("SELECT COUNT(*) FROM `forums` WHERE `id` = '".ID."' AND `level` <= '".USER_LEVEL."'") == 0)locate(PATH.'index.php');

$forum_info = $db -> fetch("SELECT * FROM `forums` WHERE `id` = '".ID."'");

$template -> forum_id = ID;
$template -> forum_name = $forum_info['name'];
$template -> forum_description = $forum_info['description'];

show_title($forum_info['name'], $forum_info['name']);

		switch(MODE)
	{
	default:
	
	{


	$count_topics = $db -> one("SELECT COUNT(*) FROM `topics` WHERE `fid` = '".ID."' AND `level` <= '".USER_LEVEL."'");
	if($count_topics > 0)
		{

		
		if($forum_info['count_topics'] != $count_topics)$db -> sql("UPDATE `forums` SET `count_topics` = '$count_topics' WHERE `id` = '".ID."' AND `level` <= '".USER_LEVEL."'");

		check_page($count_topics, PATH.'forum'.ID.'/page{$page}/', ONPAGE_TOPICS);

		$template_topics = array();

		$i = START_TOPICS;
				while($topic = $db -> fetch("SELECT *, (SELECT `date` FROM `topics_views` WHERE `tid` = `topics`.`id` AND `user_id` = '".USER_ID."') AS `view_date` FROM `topics` WHERE `fid` = '".ID."' ORDER BY `top` DESC, IF (`last_date` = 0, `date`, `last_date`) DESC LIMIT ".START_TOPICS.",".ONPAGE_TOPICS))
			{
			$i ++;

			$topic_icons = show_topic_icons($topic);

			$template_topic = array('id' => $topic['id'], 'name' => $topic['name'], 'icons' => $topic_icons, 'user' => get_user(!empty($topic['last_user_id']) ? $topic['last_user_id'] : $topic['user_id']), 'date' => xdate(!empty($topic['last_date']) ? $topic['last_date'] : $topic['date']), 'count_posts' => $topic['count_posts'], 'i' => $i);

			$template_topics[] = $template_topic;
			}

		$template -> assign('topics', $template_topics);

		pagebar($str, PAGE, PATH.'forum'.ID.'/page{$page}/');

		}
	else
		{
		
		if($forum_info['count_posts'] != 0)$db -> sql("UPDATE `forums` SET `count_posts` = 0 WHERE `id` = '".ID."'");
		}

	$template -> forum_level = $forum_info['level'];
	$template -> forum_level_topics = $forum_info['level_topics'];
	$template -> forum_counter_posts = (bool)$forum_info['counter_posts'];
	$template -> forum_counter_topics = (bool)$forum_info['counter_topics'];

	$template -> block = 'index';


	}
	break;
	
	case 'newtopic':
	
	{

	only_reg();

	
	if($forum_info['level_topics'] > USER_LEVEL)err('თქვენ არ შეგიძლიათ გახსნათ ახალი თემა ამ განყოფილებაში', PATH.'forum'.ID.'/');

	
	if((TIME - $userdata['date_reg']) < $cfg['time_silence'])err('თქვენ არ შეგიძლიათ აქტიურობა ამ განყოფილებაში.', PATH.'forum'.ID.'/');

	
	if($db -> one("SELECT COUNT(*) FROM `users_punishes` WHERE `user_id` = '".USER_ID."' AND `to_date` > '".TIME."' AND `ban` = '1'") > 0)err('თქვენ დაბლოკილი ხართ', PATH.'forum'.ID.'/');

	if($cfg['time_antispam_topics'] > 0 && USER_LEVEL < USER_ADMIN)
		{
		if(($last_topic = $db -> one("SELECT MAX(`date`) FROM `topics` WHERE `user_id` = '".USER_ID."'")) > 0)
			{
			if((TIME - $last_topic) < $cfg['time_antispam_topics'])
				{
				err('ასე ხშირად არ შეგიძლიათ თემის შექმნა', PATH.'forum'.ID.'/');
				}
			}
		}

	if(isset($_POST['create']))
		{
		check_fields(PATH.'forum'.ID.'/newtopic/', array(array('topic_name', 'not null', 'minlen' => 5, 'maxlen' => 100), array('topic_post', 'not null', 'minlen' => 2, 'maxlen' => $cfg['maxlen_post'])));

		$topic_name = str($_POST['topic_name']);
		$topic_post = str($_POST['topic_post']);

		$add_topics = $add_posts = 0;

		if($db -> sql("INSERT INTO `topics` SET `fid` = '".ID."', `name` = '$topic_name', `user_id` = '".USER_ID."', `date` = '".TIME."', `count_posts` = '0', `open` = '1', `level` = '0', `level_posts` = '1'"))
			{
			$add_topics ++;

			$topic_id = $db -> last_id();

			if($db -> sql("INSERT INTO `posts` SET `tid` = '$topic_id', `fid` = '".ID."', `user_id` = '".USER_ID."', `date` = '".TIME."', `ip` = '".MY_INT_IP."', `ua` = '".MY_UA."'"))
				{
				$add_posts ++;

				$post_id = $db -> last_id();
				if($db -> sql("INSERT INTO `posts_text` SET `pid` = '$post_id', `text` = '$topic_post'"))
					{
					$show_on_pages = postval('post_on_pages', 1) ? 1 : 0;
					$db -> sql("UPDATE `topics` SET `first_post` = '$post_id', `first_post_on_pages` = '$show_on_pages' WHERE `id` = '$topic_id'");
					$db -> sql("UPDATE `forums` SET `count_topics` = `count_topics` + '$add_topics', `count_posts` = `count_posts` + '$add_posts' WHERE `id` = '".ID."'");
					msg('თემა &quot;'.$topic_name.'&quot; შეიქმნა', PATH.'topic'.$topic_id.'/');
					}
				else
					{
					$db -> sql("DELETE FROM `topics` WHERE `id` = '$topic_id'");
					$db -> sql("DELETE FROM `posts` WHERE `id` = '$post_id'");
					err('Ошибка', PATH.'forum'.ID.'/newtopic/');
					}
				}
			else
				{
				$db -> sql("DELETE FROM `topics` WHERE `id` = '$topic_id'");
				err('Ошибка', PATH.'forum'.ID.'/newtopic/');
				}

			}
		else
			{
			err('Ошибка', PATH.'forum'.ID.'/newtopic/');
			}

		}

	$template -> page_zag = 'ახალი თემის გახსნა';

	$template -> block = 'newtopic';

	}
	break;
	
	case 'edit':
	
	{

	only_reg(USER_ADMIN);

	if(postval('edit', 1))
		{
		check_fields(PATH.'forum'.ID.'/', array(array('forum_name', 'not null', 'maxlen' => 50), array('forum_description', 'maxlen' => 250), array('level', 'values' => array('0', '1', '2', '3'))));

		$forum_name = str($_POST['forum_name']);
		$forum_description = str($_POST['forum_description']);
		$forum_counter_posts = postval('counter_posts');
		$forum_counter_topics = postval('counter_topics');

		if(xtolower($forum_name) != xtolower($forum_info['name']) && $db -> one("SELECT COUNT(*) FROM `forums` WHERE `name` = '$forum_name'") > 0)
			{
			err('განყოფილება &quot;'.$forum_name.'&quot; უკვე არსებობს', PATH.'forum'.ID.'/');
			}

		
		$count_topics = $db -> one("SELECT COUNT(*) FROM `topics` WHERE `fid` = '".ID."'");
		$count_posts = $db -> one("SELECT COUNT(*) FROM `posts` WHERE `fid` = '".ID."' AND (SELECT COUNT(*) FROM `topics` WHERE `topics`.`first_post` = `posts`.`id`) = 0");

		$level = int($_POST['level']);
		$level_topics = int($_POST['level_topics']);

		if($db -> sql("UPDATE `forums` SET `name` = '$forum_name', `description` = '$forum_description', `count_topics` = '$count_topics', `count_posts` = '$count_posts', `level` = '$level', `level_topics` = '$level_topics', `counter_posts` = '$forum_counter_posts', `counter_topics` = '$forum_counter_topics' WHERE `id` = '".ID."'"))
			{

			
			$db -> sql("UPDATE `topics` SET `count_posts` = (SELECT COUNT(*) FROM `posts` WHERE `posts`.`tid` = `topics`.`id` AND `posts`.`id` != `topics`.`first_post`)  WHERE `fid` = '".ID."'");

			msg('განყოფილება &quot;'.$forum_name.'&quot; რედაქტირებულია', PATH.'forum'.ID.'/');
			}
		else
			{
			err('შეცდომა', PATH.'forum'.ID.'/');
			}

		}

	$template -> page_zag = 'განყოფილების რედაქტირება';
    
    

	$template -> level = $forum_info['level'];
	$template -> level_topics= $forum_info['level_topics'];
	$template -> counter_posts = (bool)$forum_info['counter_posts'];
	$template -> counter_topics = (bool)$forum_info['counter_topics'];

	$template -> block = 'edit';


	}
	break;
	
	case 'del':
	
	{

	if(postval('del', 1))
		{
		$into_forum = (!empty($_POST['into_forum']) && int($_POST['into_forum']) > 0) ? int($_POST['into_forum']) : false;

		if($into_forum != false && $db -> one("SELECT COUNT(*) FROM `forums` WHERE `id` = '$into_forum'") == 0)err('განყოფილება არაა არჩეული', PATH.'forum'.ID.'/del/');

		
		if($into_forum != false)
			{
			
			if(!$db -> sql("UPDATE `posts` SET `fid` = '$into_forum' WHERE `fid` = '".ID."'"))
				{
				err('შეცდომა პოსტების გადატანისას', PATH.'forum'.ID.'/del/');
				}

			
			if(!$db -> sql("UPDATE `topics` SET `fid` = '$into_forum' WHERE `fid` = '".ID."'"))
				{
				err('შეცდომა თემის გადატანისას', PATH.'forum'.ID.'/del/');
				}

			}
		
		else
			{

			
			if(!$db -> sql("DELETE FROM `posts_text` WHERE (SELECT `fid` FROM `posts` WHERE `id` = `posts_text`.`pid`) = '".ID."'"))
				{
				err('შეცდომა პოსტის ტექსტის წაშლისას', PATH.'forum'.ID.'/del/');
				}

			
			if(!$db -> sql("DELETE FROM `posts` WHERE `fid` = '".ID."'"))
				{
				err('შეცდომა გამოხმაურების წაშლისას', PATH.'forum'.ID.'/del/');
				}

			
			if(!$db -> sql("DELETE FROM `topics_logs` WHERE (SELECT `fid` FROM `topics` WHERE `id` = `topics_logs`.`tid`) = '".ID."'"))
				{
				err('შეცდომა თემის ისტორიის წაშლისას', PATH.'forum'.ID.'/del/');
				}

			
			if(!$db -> sql("DELETE FROM `topics_views` WHERE (SELECT `tid` FROM `topics` WHERE `id` = `topics_views`.`tid`) = '".ID."'"))
				{
				err('შეცდომა თემების ნახვების ისტორიის წაშლისას', PATH.'forum'.ID.'/del/');
				}

			
			if(!$db -> sql("DELETE FROM `topics_bookmarks` WHERE (SELECT `tid` FROM `topics` WHERE `id` = `topics_bookmarks`.`tid`) = '".ID."'"))
				{
				err('შეცდომა თემის სანიშნის წაშლისას', PATH.'forum'.ID.'/del/');
				}

			
			if(!$db -> sql("DELETE FROM `topics`  WHERE `fid` = '".ID."'"))
				{
				err('შეცდომა თემის წაშლისას', PATH.'forum'.ID.'/del/');
				}
			}

		if(!$db -> sql("DELETE FROM `forums` WHERE `id` = '".ID."'"))
			{
			err('შეცდომა განყოფილების წაშლისას', PATH.'forum'.ID.'/del/');
			}

		
		if($into_forum != false)
			{
			$db -> sql("UPDATE `forums` SET `count_topics` = `count_topics` + '{$forum_info['count_topics']}', `count_posts` = `count_posts` + '{$forum_info['count_posts']}' WHERE `id` = '$into_forum'");
			}

		msg('განყოფილება &quot;'.$forum_info['name'].'&quot; წაიშალა'.($into_forum != false ? '<br />თემები და გამოხმაურებები გადატანილია განყოფილებაში &quot;'.$db -> one("SELECT `name` FROM `forums` WHERE `id` = '$into_forum'").'&quot;' : null), PATH.'index.php');

		}

	
	if($db -> one("SELECT COUNT(*) FROM `forums` WHERE `id` != '".ID."'") > 0)
		{
		$template_forums = array();

				while($forum = $db -> fetch("SELECT `id`, `name` FROM `forums` WHERE `id` != '".ID."' ORDER BY `position` ASC"))
			{
			$template_forum = array('id' => $forum['id'], 'name' => $forum['name']);

			$template_forums[] = $template_forum;

			}

		$template -> assign('forums', $template_forums);

		}

	$template -> page_zag = 'განყოფილების წაშლა';

	$template -> block = 'del';

	}
	break;
	}

$template -> display('forum.page');

show_foot();

?>