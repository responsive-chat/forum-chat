<?php


	require 'sys/inc/core.php';

only_reg();

if(ID > 0 && $db -> one("SELECT COUNT(*) FROM `users` WHERE `id` = '".ID."'") == 0)locate(PATH.'index.php');

$user_info = $db -> fetch("SELECT * FROM `users` WHERE `id` = '".ID."'");

$template -> userid = ID;

$template -> usernick = $user_info['nick'];

$user_info['status'] = $levels[$user_info['level']][1];

$user_info['active'] = (bool)$user_info['active'];

		switch(MODE)
	{
	default:
	
	{

	show_title($user_info['nick']);

	$user_info['reg'] = xdate($user_info['date_reg']);

	$user_info['last'] = xdate($user_info['date_last_visit']);

	$user_info['online'] = ((TIME - $user_info['date_last_visit']) < 300);

	$user_info['info_sex'] = $user_info['info_sex'] ? 'მამრობითი' : 'მდედრობითი';

	

	




	if((USER_LEVEL >= USER_MODERATOR && $user_info['level'] < USER_LEVEL) || USER_ID == 1)
		{
		$template -> manage_moderator = true;
		if(USER_LEVEL >= USER_ADMIN)
			{
			$template -> manage_admin = true;
			}
		}


	$user_info['count_posts'] = $db -> one("SELECT COUNT(*) FROM `posts` WHERE `user_id` = '".ID."' AND (SELECT `level` FROM `topics` WHERE `id` = `posts`.`tid`) <= '".USER_LEVEL."' AND (SELECT COUNT(*) FROM `forums` WHERE `id` = `posts`.`fid` AND `level` <= '".USER_LEVEL."' AND `counter_posts` = '1') > 0");
	$user_info['count_topics'] = $db -> one("SELECT COUNT(*) FROM `topics` WHERE `user_id` = '".ID."' AND `level` <= '".USER_LEVEL."' AND (SELECT COUNT(*) FROM `forums` WHERE `id` = `topics`.`fid` AND `level` <= '".USER_LEVEL."' AND `counter_topics` = '1') > 0");

	
	$count_punishes = $db -> one("SELECT COUNT(*) FROM `users_punishes` WHERE `user_id` = '".ID."'");

	
	if(USER_LEVEL >= USER_MODERATOR || ID == USER_ID)
		{
		$template -> punish_all = $count_punishes;
		}

	if($count_punishes > 0)
		{
		if($db -> one("SELECT COUNT(*) FROM `users_punishes` WHERE `user_id` = '".ID."' AND `to_date` > '".TIME."'") > 0)
			{

			
			$punish_info = $db -> fetch("SELECT *,(SELECT COUNT(*) FROM `posts` WHERE `id` = `users_punishes`.`pid`) AS `is_post` FROM `users_punishes` WHERE `user_id` = '".ID."' ORDER BY `date` DESC LIMIT 0,1");

			$template -> punish = true;
			$template -> punish_ban = (bool)$punish_info['ban'];

			$template -> punish_time = xtime($punish_info['to_date'] - TIME);

			
			if($punish_info['rule'] > 0)
				{
				if($db -> one("SELECT COUNT(*) FROM `rules` WHERE `id` = '{$punish_info['rule']}'") > 0)
					{
					$rule_info = $db -> fetch("SELECT `id`, `title`, `cid` FROM `rules` WHERE `id` = '{$punish_info['rule']}'");

					
					$template -> punish_rule = array('id' => $punish_info['rule'], 'title' => $rule_info['title'], 'cid' => $rule_info['cid']);

					}
				else
					{
					
					$db -> sql("UPDATE `users_punishes` SET `rule` = '0' WHERE `id` = '{$punish_info['id']}'");
					}
				}

			
			if($punish_info['is_post'])
				{
				$template -> punish_post = $punish_info['pid'];
				}

			}
		else
			{
			
			if($user_info['punish_to_date'] > TIME)$db -> sql("UPDATE `users` SET `punish_to_date` = '0', `punish_pid` = '0', `punish_ban` = '0' WHERE `id` = '".ID."'");
			}


		}
	else
		{
		
		if($user_info['punish_to_date'] > 0)$db -> sql("UPDATE `users` SET `punish_to_date` = '0', `punish_pid` = '0', `punish_ban` = '0' WHERE `id` = '".ID."'");
		}


	$template -> block = 'index';
	}
	break;
	
	case 'edit':
	
	{

	if((USER_LEVEL < USER_MODERATOR || $user_info['level'] > USER_LEVEL) && USER_ID != 1)locate(PATH.'user'.ID.'/');

	show_title($user_info['nick'], 'პროფილის რედაქტირება');

	if(postval('edit', 1))
		{

		

		check_fields(PATH.'user'.ID.'/edit/', array(array('nick', 'not null'), array('set_onpage_topics', 'not null'), array('set_onpage_posts', 'not null'), array('set_time_shift', 'values' => range(-12, 12)), array('set_onpage_topics', 'not null'), array('info_name', 'maxlen' => 50), array('info_birthday', 'maxlen' => 50), array('info_city', 'maxlen' => 70), array('info_email', 'maxlen' => 100), array('info_tel', 'maxlen' => 50), array('info_site', 'maxlen' => 50), array('info_about', 'maxlen' => 500), array('info_interest', 'maxlen' => 500), array('info_avatar', 'maxlen' => 5000), array('info_sex', 'values' => array('0', '1'))));

		

		$nick = str($_POST['nick']);
		$access = (USER_LEVEL >= USER_ADMIN && USER_ID != ID);

		
		$password = $access && !empty($_POST['passrod']) ? get_hash($_POST['password']) : $user_info['password'];
		$level = $access ? int($_POST['level']) : $user_info['level'];
		$active = $access ? postval('active', 1) : $user_info['active'];

		
		$set_onpage_topics = int($_POST['set_onpage_topics']);
		$set_onpage_posts = int($_POST['set_onpage_posts']);
		$set_fast_post = postval('set_fast_post', 1, false);
		$set_time_shift = int($_POST['set_time_shift']);

		
		$info_name = str($_POST['info_name']);
		$info_birthday = str($_POST['info_birthday']);
		$info_city = str($_POST['info_city']);
		$info_email = str($_POST['info_email']);
		$info_tel = str($_POST['info_tel']);
		$info_site = str($_POST['info_site']);
		$info_about = str($_POST['info_about']);
		$info_interest = str($_POST['info_interest']);
		$info_avatar = str($_POST['info_avatar']);
		$info_sex = int($_POST['info_sex']);

		if($db -> sql("UPDATE `users` SET `nick` = '$nick', `password` = '$password', `level` = '$level', `active` = '$active', `set_onpage_topics` = '$set_onpage_topics', `set_onpage_posts` = '$set_onpage_posts', `set_fast_post` = '$set_fast_post', `set_time_shift` = '$set_time_shift', `info_name` = '$info_name', `info_birthday` = '$info_birthday', `info_city` = '$info_city', `info_email` = '$info_email', `info_tel` = '$info_tel', `info_site` = '$info_site', `info_about` = '$info_about', `info_interest` = '$info_interest', `info_avatar` = '$info_avatar', `info_sex` = '$info_sex' WHERE `id` = '".ID."'"))
			{
			msg('მომხმარებელი &quot;'.$user_info['nick'].'&quot; რედაქტირებულია', PATH.'user'.ID.'/');
			}
		else
			{
			err('შეცდომა', PATH.'user'.ID.'/edit/');
			}


		}

	$template_times = array();
			for($i = -12;$i <= 12;$i ++)
		{
		$template_time = array('time' => date('d.m G:i', TIME + ($i * 3600)), 'shift' => $i);
		if($user_info['set_time_shift'] == $i)$template_time['selected'] = ' selected="selected"';

		$template_times[] = $template_time;
		}

	$template -> assign('times', $template_times);

	$template -> block = 'edit';

	}
	break;
	
	case 'active':
	
	{

	if(((USER_LEVEL < USER_ADMIN || $user_info['level'] > USER_LEVEL) && USER_ID != 1) || $user_info['active'])locate(PATH.'user'.ID.'/');

	if($db -> sql("UPDATE `users` SET `active` = '1' WHERE `id` = '".ID."'"))
		{
		msg('მომხმარებელი &quot;'.$user_info['nick'].'&quot; გააქტიურდა', PATH.'user'.ID.'/');
		}
	else
		{
		err('შეცდომა', PATH.'user'.ID.'/');
		}


	}
	
	case 'deactive':
	
	{

	if(((USER_LEVEL < USER_ADMIN || $user_info['level'] > USER_LEVEL) && USER_ID != 1) || !$user_info['active'])locate(PATH.'user'.ID.'/');

	if($db -> sql("UPDATE `users` SET `active` = '0' WHERE `id` = '".ID."'"))
		{
		msg('მომხმარებელი &quot;'.$user_info['nick'].'&quot; დეაქტივირებულია', PATH.'user'.ID.'/');
		}
	else
		{
		err('შეცდომა', PATH.'user'.ID.'/');
		}


	}
	break;
	
	case 'punish':
	
	{

	show_title($user_info['nick'], 'დაბლოკვა');

	if(((USER_LEVEL < USER_MODERATOR || $user_info['level'] > USER_LEVEL) && USER_ID != 1) || ID == USER_ID)locate(PATH.'user'.ID.'/');

	if($db -> one("SELECT COUNT(*) FROM `users_punishes` WHERE `user_id` = '".ID."' AND `to_date` > '".TIME."' AND `ban` = '1' ORDER BY `date` DESC LIMIT 0,1") > 0)
		{
		err('მომხმარებელი &quot;'.$user_info['nick'].'&quot; უკვე რეგისტრირებულია', PATH.'user'.ID.'/');
		}

	if(postval('punish', 1))
		{
		check_fields(PATH.'user'.ID.'/punish/', array(array('rule'), array('time1', 'not null'), array('time2', 'not null'), array('comment', 'maxlen' => 500)));

		$rule = int($_POST['rule']);

		$time1 = int($_POST['time1']);
		$time2 = int($_POST['time2']);
		$to_date = TIME + ($time1 * $time2);

		$comment = str($_POST['comment']);

		$ban = postval('ban', 1, false);
		$close_private = postval('close_private', 1, false);

		if($db -> sql("INSERT INTO `users_punishes` SET `rule` = '$rule', `user_id` = '".ID."', `date` = '".TIME."', `to_date` = '$to_date', `comment` = '$comment', `punished_user_id` = '".USER_ID."', `ban` = '$ban', `close_private` = '$close_private', `ip` = '".MY_INT_IP."', `ua` = '".MY_UA."'"))
			{
			$punish_id = $db -> last_id();
			if($db -> sql("UPDATE `users` SET `punish_ban` = '$ban', `punish_to_date` = '$to_date' WHERE `id` = '".ID."'"))
				{

				msg('მომხმარებელი &quot;'.$user_info['nick'].'&quot; დაბლოკილია', PATH.'user'.ID.'/');

				}
			else
				{
				err('შეცდომა მომხმარებლის ინფორმაციის რედაქტირებისას', PATH.'user'.ID.'/punish/');
				}

			}
		else
			{
			err('შეცდომა დარღვევის შენახვისას', PATH.'user'.ID.'/punish/');
			}


		}

	
	$count_rules = $db -> one("SELECT COUNT(*) FROM `rules`");
	if($count_rules > 0)
		{
		$template_rules_cat = array();
				while($rules_cat = $db -> fetch("SELECT * FROM `rules_cats` ORDER BY `position` ASC"))
			{
			$template_rules_cat = array('id' => $rules_cat['id'], 'name' => $rules_cat['name']);

			

			
			if($db -> one("SELECT COUNT(*) FROM `rules` WHERE `cid` = '{$rules_cat['id']}' AND `title` != ''") > 0)
				{
						while($rule = $db -> fetch("SELECT * FROM `rules` WHERE `cid` = '{$rules_cat['id']}' AND `title` != '' ORDER BY `title` ASC"))
					{
					$template_rule = array('id' => $rule['id'], 'title' => $rule['title']);

					$template_rules[] = $template_rule;
					}
				}
			}
		$template -> assign('rules', $template_rules);
		}

	$template -> block = 'punish';

	}
	break;
	
	case 'punishes':
	
	{

	

	show_title($user_info['nick'], 'დაბლოკვა');

	

	
	if(ACT != null && preg_match('~^(del|edit)([0-9]+)$~', ACT, $act))
		{
		if(USER_LEVEL < USER_MODERATOR)locate(PATH.'user'.ID.'/punishes/');

		
		if($db -> one("SELECT COUNT(*) FROM `users_punishes` WHERE `user_id` = '".ID."' AND `id` = '$act[2]'") == 0)err('Наказани не найдено', PATH.'user'.ID.'/punishes/');

		$punish_info = $db -> fetch("SELECT * FROM `users_punishes` WHERE `user_id` = '".ID."' AND `id` = '$act[2]'");

		
		if(TIME > $punish_info['to_date'] && USER_LEVEL < USER_ADMIN)locate(PATH.'user'.ID.'/punishes/');

		
		$punish_info['last'] = ($db -> one("SELECT COUNT(*) FROM `users_punishes` WHERE `user_id` = '".ID."' AND `to_date` > '{$punish_info['to_date']}'") > 0) ? true : false;

		
		if($act[1] == 'edit')
			{

			if(postval('edit', 1))
				{
				check_fields(PATH.'user'.ID.'/punishes/edit'.$act[2].'/', array(array('rule'), array('time1', 'not null'), array('time2', 'not null'), array('comment', 'maxlen' => 500)));

				$rule = int($_POST['rule']);

				$time1 = int($_POST['time1']);
				$time2 = int($_POST['time2']);
				$to_date = TIME + ($time1 * $time2);

				$comment = str($_POST['comment']);

				$ban = postval('ban', 1, false);
				$close_private = postval('close_private', 1, false);

				$pid = postval('clean_pid', 1) ? 0 : $punish_info['pid'];

				

				if($db -> sql("UPDATE `users_punishes` SET `rule` = '$rule', `user_id` = '".ID."', `date` = '".TIME."', `to_date` = '$to_date', `comment` = '$comment', `punished_user_id` = '".USER_ID."', `ban` = '$ban', `close_private` = '$close_private', `pid` = '$pid', `ip` = '".MY_INT_IP."', `ua` = '".MY_UA."' WHERE `id` = '{$punish_info['id']}'"))
					{
					
					$last = ($db -> one("SELECT COUNT(*) FROM `users_punishes` WHERE `user_id` = '".ID."' AND `to_date` > '$to_date'") > 0) ? true : false;
					if($last)
						{
						if(!$db -> sql("UPDATE `users` SET `punish_ban` = '$ban', `punish_to_date` = '$to_date' WHERE `id` = '".ID."'"))
							{
							err('შეცდომა მომხმარებლის ინფორმაციის რედაქტირებისას', PATH.'user'.ID.'/punishes/edit'.$act[2].'/');
							}
						}
					else
						{
						
						$last_punish = $db -> fetch("SELECT `ban`, `to_date`, `pid` FROM `users_punishes` WHERE `user_id` = '".ID."' ORDER BY `to_date` DESC LIMIT 0,1");
						if(!$db -> sql("UPDATE `users` SET `punish_ban` = '{$last_punish['ban']}', `punish_to_date` = '{$last_punish['to_date']}', `punish_pid` = '{$last_punish['pid']}' WHERE `id` = '".ID."'"))
							{
							err('შეცდომა მომხმარებლის ინფორმაციის რედაქტირებისას', PATH.'user'.ID.'/punishes/edit'.$act[2].'/');
							}
						}



					msg('ბლოკირება შეიცვალა', PATH.'user'.ID.'/punishes/#punish-'.$act[2]);


					}
				else
					{
					err('შეცდომა დარღვევის რედაქტირებისას', PATH.'user'.ID.'/punishes/edit'.$act[2].'/');
					}


				}


			
			$template_punish = $punish_info;

			
			$count_rules = $db -> one("SELECT COUNT(*) FROM `rules`");
			if($count_rules > 0)
				{
				$template_rules_cat = array();
						while($rules_cat = $db -> fetch("SELECT * FROM `rules_cats` ORDER BY `position` ASC"))
					{
					$template_rules_cat = array('id' => $rules_cat['id'], 'name' => $rules_cat['name']);

					
					if($db -> one("SELECT COUNT(*) FROM `rules` WHERE `cid` = '{$rules_cat['id']}' AND `title` != ''") > 0)
						{
								while($rule = $db -> fetch("SELECT * FROM `rules` WHERE `cid` = '{$rules_cat['id']}' AND `title` != '' ORDER BY `title` ASC"))
							{
							$template_rule = array('id' => $rule['id'], 'title' => $rule['title']);

							if($rule['id'] == $punish_info['rule'])$template_rule['selected'] = ' selected="selected"';

							$template_rules[] = $template_rule;
							}
						}
					}
				$template -> assign('rules', $template_rules);
				}

			
			$punish_time = $punish_info['to_date'] - TIME;
					foreach($times as $times_limit => $times_strings)
				{
				if($punish_time >= $times_limit)
					{
					$template_punish['time'] = int(ceil($punish_time / $times_limit));
					$template_punish['time_limit'] = $times_limit;
					break;
					}
				}

			$template_punish['ban'] = (bool)$template_punish['ban'];
			$template_punish['close_private'] = (bool)$template_punish['close_private'];
			$template_punish['is_pid'] = (bool)$template_punish['pid'];

			

			$template -> assign('punish', $template_punish);


			$template -> block = 'punish_edit';

			}
		
		else
			{
			if(postval('del', 1))
				{
				
				if(!$db -> sql("DELETE FROM `users_punishes` WHERE `id` = '{$act[2]}'"))
					{
					err('შეცდომა დარღვევის წაშლისას', PATH.'user'.ID.'/punishes/edit'.$act[2].'/');
					}

				
				if($punish_info['last'])
					{
					if(!$db -> sql("UPDATE `users` SET `punish_ban` = '0', `punish_to_date` = '0', `punish_pid` = '0' WHERE `id` = '".ID."'"))
						{
						err('შეცდომა მომხმარებლის ინფორმაციის რედაქტირებისას', PATH.'user'.ID.'/punishes/edit'.$act[2].'/');
						}
					}
				else
					{
					
					$last_punish = $db -> fetch("SELECT `ban`, `to_date`, `pid` FROM `users_punishes` WHERE `user_id` = '".ID."' ORDER BY `to_date` DESC LIMIT 0,1");
					if(!$db -> sql("UPDATE `users` SET `punish_ban` = '{$last_punish['ban']}', `punish_to_date` = '{$last_punish['to_date']}', `punish_pid` = '{$last_punish['pid']}' WHERE `id` = '".ID."'"))
						{
						err('შეცდომა მომხმარებლის ინფორმაციის რედაქტირებისას', PATH.'user'.ID.'/punishes/edit'.$act[2].'/');
						}
					}

				msg('ბლოკირება წაიშალა', PATH.'user'.ID.'/punishes/');

				}

			$template -> punish_id = $act[2];

			$template -> block = 'punish_del';

			}

		}
	else
		{

		$count_punishes = $db -> one("SELECT COUNT(*) FROM `users_punishes` WHERE `user_id` = '".ID."'");
		if($count_punishes > 0)
			{

			check_page($count_punishes, PATH.'user'.ID.'/punishes/page{$page}');

			$template_punishes = array();


			$i = START_POSTS;

					while($punish = $db -> fetch("SELECT `u_p`.*, `u`.`nick` AS  `punished_user_nick`, (SELECT `text` FROM `posts_text` WHERE  `u_p`.`pid` != 0 AND `pid` = `u_p`.`pid`) AS `post_text`
	FROM `users_punishes` AS `u_p`, `users` AS `u`
	WHERE `u_p`.`user_id` = '".ID."' AND `u`.`id` = `u_p`.`punished_user_id`
	ORDER BY `u_p`.`to_date` DESC
	LIMIT ".START_POSTS.",".ONPAGE_POSTS))
				{
				$i ++;

				
				$template_punish = array('i' => $i,'id' => $punish['id'], 'punished_user_id' => $punish['punished_user_id'], 'punished_user' => $punish['punished_user_nick'], 'date' => xdate($punish['date']), 'to_date' => xdate($punish['to_date']),  'ban' => (bool)$punish['ban'], 'close_private' => (bool)$punish['close_private'], 'ban' => (bool)$punish['ban'], 'ip' => long2ip($punish['ip']), 'ua' => $punish['ua'], 'pid' => $punish['pid']);

				
				if($punish['to_date'] > TIME)
					{
					
					$template_punish['time'] = xtime($punish['to_date'] - TIME);
					$template_punish['was'] = false;
					}
				else
					{
					
					$template_punish['time'] = xdate($punish['to_date']);
					$template_punish['was'] = true;
					
					}

				
				if(!empty($punish['comment']))
					{
					
					$template_punish['comment'] = post($punish['comment']);
					}

				
				if(!empty($punish['pid']))
					{
					if(!empty($punish['post_text']))
						{
						
						$template_punish['post'] = get_short_post($punish['post_text']);
						}

					else
						{
						
						$db -> sql("UPDATE `users_punishes` SET `pid` = '0' WHERE `id` = '{$punish['id']}'");
						}
					}

				
				if($punish['rule'] > 0)
					{
					if($db -> one("SELECT COUNT(*) FROM `rules` WHERE `id` = '{$punish['rule']}'") > 0)
						{
						$rule_info = $db -> fetch("SELECT `id`, `title`, `cid` FROM `rules` WHERE `id` = '{$punish['rule']}'");

						
						
						$template_punish['rule_cid'] = $rule_info['cid'];
						$template_punish['rule_title'] = $rule_info['title'];

						}
					else
						{
						
						$db -> sql("UPDATE `users_punishes` SET `rule` = '0' WHERE `id` = '{$punish['id']}'");
						}
					}

				if($punish['close_private'])
					{
					
					$template_punish['close_private'] = true;
					}

				
				if(USER_LEVEL >= USER_MODERATOR)
					{
					if($punish['to_date'] > TIME || USER_LEVEL >= USER_ADMIN)
						{
						
						$template_punish['manage'] = true;
						}

					
					$template_punish['manage_info'] = true;
					$template_punish['ip'] = long2ip($punish['ip']);
					$template_punish['ua'] = $punish['ua'];
					}

				$template_punishes[] = $template_punish;

				}


			
			pagebar($str, PAGE, PATH.'user'.ID.'/punishes/page{$page}/');

			
			$template -> assign('punishes', $template_punishes);

			}

		$template -> block = 'punishes';

		}

	}
	break;
	
	case 'topics':
	
	{

	show_title($user_info['nick'], 'Темы');

	
	$count_topics = $db -> one("SELECT COUNT(*) FROM `topics` WHERE `user_id` = '".ID."' AND `level` <= '".USER_LEVEL."' AND (SELECT COUNT(*) FROM `forums` WHERE `id` = `topics`.`fid` AND `level` <= '".USER_LEVEL."') > 0");

	$template -> count_topics = $count_topics;

	if($count_topics > 0)
		{

		check_page($count_topics, PATH.'user'.ID.'/topics/page{$page}/', ONPAGE_TOPICS);

		$template_topics = array();

		$i = START_TOPICS;
				while($topic = $db -> fetch("SELECT `id`, `name`, `last_user_id`, `last_date`, `date`, `count_posts`, (SELECT `nick` FROM `users` WHERE `id` = `topics`.`last_user_id`) AS `last_user` FROM `topics` WHERE `user_id` = '".ID."' AND `level` <= '".USER_LEVEL."' ORDER BY `top` DESC, `last_date` DESC, `date` DESC LIMIT ".START_TOPICS.",".ONPAGE_TOPICS))
			{
			$i ++;

			

			$template_topic = array('id' => $topic['id'], 'name' => $topic['name'], 'user' => (!empty($topic['last_user']) ? $topic['last_user'] : $user_info['nick']), 'date' => xdate(!empty($topic['last_date']) ? $topic['last_date'] : $topic['date']), 'count_posts' => $topic['count_posts'], 'i' => $i);

			$template_topics[] = $template_topic;
			}

		$template -> assign('topics', $template_topics);

		pagebar($str, PAGE, PATH.'user'.ID.'/topics/page{$page}/');

		}

	$template -> block = 'topics';

	}
	break;
	
	case 'posts':
	
	{

	show_title($user_info['nick'], 'Сообщения');

	
	$count_posts = $db -> one("SELECT COUNT(*) FROM `posts` WHERE `user_id` = '".ID."' AND (SELECT `level` FROM `topics` WHERE `id` = `posts`.`tid`) <= '".USER_LEVEL."' AND (SELECT COUNT(*) FROM `forums` WHERE `id` = `posts`.`fid` AND `level` <= '".USER_LEVEL."') > 0");

	$template -> count_posts = $count_posts;

	if($count_posts > 0)
		{

		check_page($count_posts, PATH.'user'.ID.'/posts/page{$page}/', ONPAGE_TOPICS);

		$template_posts = array();

		$i = START_POSTS;
				while($post = $db -> fetch("SELECT `p`.`id`, `p`.`date`, `p`.`tid`, `p_t`.`text` AS `post_text`, `t`.`name` AS `topic_name`, `t`.`count_posts` AS `topic_count_posts`
FROM `posts` AS `p`, `posts_text` AS `p_t`, `topics` AS `t`, `forums` AS `f`
WHERE `p`.`user_id` = '".ID."' AND `p_t`.`pid` = `p`.`id` AND `t`.`id` = `p`.`tid` AND `t`.`level` <= '".USER_LEVEL."' AND `f`.`id` = `p`.`fid` AND `f`.`level` <= '".USER_LEVEL."'
ORDER BY `p`.`date` DESC
LIMIT ".START_POSTS.",".ONPAGE_POSTS))
			{
			$i ++;

			



			$template_post = array('i' => $i, 'id' => $post['id'], 'date' => xdate($post['date']), 'text' => get_short_post($post['post_text']), 'tid' => $post['tid'], 'topic_name' => $post['topic_name'], 'topic_count_posts' => $post['topic_count_posts']);

			$template_posts[] = $template_post;
			}

		$template -> assign('posts', $template_posts);

		pagebar($str, PAGE, PATH.'user'.ID.'/posts/page{$page}/');

		}

	$template -> block = 'posts';

	}
	break;
	}

$template -> user = $user_info;

$template -> display('user.page');

show_foot();


?>