<?php


	require_once 'sys/inc/core.php';

$_SESSION['captcha'] = rand(99, 9999);
$code = (string)($_SESSION['captcha']);
$width = strlen($code) * 15;
$image = imagecreatetruecolor($width, 23);
imagefilledrectangle($image, 0, 0, $width, 23,imagecolorallocate($image, rand(200, 220), rand(200, 220), rand(200, 220)));

		for($s = strlen($code), $i = 0;$i < $s;$i ++)
	{
	$color = imagecolorallocatealpha($image, rand(120, 180), rand(120, 180), rand(120, 180), rand(20, 50));
	imagettftext($image, rand(15, 19), rand(-20, 20), (13 * $i), rand(18, 20),$color, CONFIG_DIR.'captcha.ttf', $code{$i});
	}


header('Content-Type: image/png');
imagepng($image, null, 1);
imagedestroy($image);
exit;


?>