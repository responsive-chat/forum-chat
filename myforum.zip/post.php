<?php

	require_once 'sys/inc/core.php';

if(ID > 0 && $db -> one("SELECT COUNT(*) FROM `posts` WHERE `id` = '".ID."'") == 0)locate(PATH.'index.php');

$post_info = $db -> fetch("SELECT *,(SELECT `text` FROM `posts_text` WHERE `posts_text`.`pid` = `posts`.`id`) AS text FROM `posts` WHERE `id` = '".ID."'");

if($db -> one("SELECT COUNT(*) FROM `topics` WHERE `id` = '{$post_info['tid']}' AND `level` <= '".USER_LEVEL."'") == 0)locate(PATH.'index.php');

$topic_info = $db -> fetch("SELECT * FROM `topics` WHERE `id` = '{$post_info['tid']}'");

if($db -> one("SELECT COUNT(*) FROM `forums` WHERE `id` = '{$post_info['fid']}' AND `level` <= '".USER_LEVEL."'") == 0)locate(PATH.'index.php');

$forum_info = $db -> fetch("SELECT * FROM `forums` WHERE `id` = '{$post_info['fid']}'");



$template -> forum_id = $forum_info['id'];
$template -> forum_name = $forum_info['name'];

$template -> topic_id = $topic_info['id'];
$template -> topic_name = $topic_info['name'];

$template -> post_id = ID;
$template -> post_text = $post_info['text'];

$post_info['user_level'] = get_user($post_info['user_id'], 'level');

show_title($topic_info['name'], 'შეტყობინება თემაში &quot;'.$topic_info['name'].'&quot;');

		switch(MODE)
	{
	default:
	
	{

    if(isset($backup['session_msgs']))$_SESSION['msg'] = $backup['session_msgs'];
	if(isset($backup['session_errors']))$_SESSION['err'] = $backup['session_errors'];
	
	locate(PATH.'post'.ID.'/');

	}
	break;
	
	case 'edit':
	
	{

	only_reg();

	
	if(!$topic_info['open'] && USER_LEVEL < USER_MODERATOR)err('თემა დახურულია', PATH.'post'.ID.'/');

	
	if($topic_info['level_posts'] > USER_LEVEL)err('პოსტის რედაქტირება ვერ ხერხდება', PATH.'post'.ID.'/');

	
	if($db -> one("SELECT COUNT(*) FROM `users_punishes` WHERE `user_id` = '".USER_ID."' AND `to_date` > '".TIME."' AND `ban` = '1'") > 0)err('თქვენ დაბლოკილი ხართ', PATH.'post'.ID.'/');



	
	if((USER_LEVEL < USER_MODERATOR) && (USER_ID != $post_info['user_id'] || (TIME - $post_info['date']) > $cfg['time_edit_post']))
		{
		locate(PATH.'topic'.$topic_info['id'].'/');
		}


	if(postval('edit', 1))
		{
		check_fields(PATH.'post'.ID.'/edit/', array(array('post', 'not null', 'minlen' => 2, 'maxlen' => $cfg['maxlen_post'])));

		$post = str($_POST['post']);

		if(!$db -> sql("UPDATE `posts_text` SET `text` = '$post' WHERE `pid` = '".ID."'"))
			{
			err('შეცდომა პოსტის რედაქტირებისას', PATH.'post'.ID.'/edit/');
			}

		if(USER_LEVEL < USER_ADMIN || !postval('not_view_edit', 1))
			{
			if(!$db -> sql("UPDATE `posts` SET `edit_count` = `edit_count` + 1, `edit_date` = '".TIME."', `edit_user_id` = '".USER_ID."' WHERE `id` = '".ID."'"))
				{
				err('შეცდომა გამოხმაურების შესახებ ინფორმაციის შეცვლისას', PATH.'post'.ID.'/edit/');
				}
			}

		msg('გამოხმაურება შეიცვალა', PATH.'post'.ID.'/');

		}



	$template -> block = 'edit';

	$template -> post_manage = USER_LEVEL >= USER_ADMIN;

	$template -> page_zag = 'გამოხმაურების რედაქტირება';

	}
	break;
	
	case 'del':
	
	{

	only_reg(USER_MODERATOR);

	
	if($topic_info['level_posts'] > USER_LEVEL)err('გამოხმაურების წაშლა ვერ ხერხდება', PATH.'post'.ID.'/');

	if(postval('del', 1))
		{

		if(!$db -> sql("DELETE FROM `posts_text` WHERE `pid` = '".ID."'"))
			{
			err('შეცდომა გამოხმაურების წაშლისას', PATH.'post'.ID.'/del/');
			}

		if(!$db -> sql("DELETE FROM `posts` WHERE `id` = '".ID."'"))
			{
			err('შეცდომა პოსტის შესახებ ინფორმაციის წაშლისას', PATH.'post'.ID.'/del/');
			}

		$db -> sql("UPDATE `forums` SET `count_posts` = `count_posts` - 1 WHERE `id` = '{$forum_info['id']}'");
		$db -> sql("UPDATE `topics` SET `count_posts` = `count_posts` - 1 WHERE `id` = '{$topic_info['id']}'");

		msg('გამოხმაურება წაიშალა', PATH.'topic'.$topic_info['id'].'/');

		}

	$template -> block = 'del';

	$template -> page_zag = 'გამოხმაურების წაშლა';

	}
	break;
	
	case 'trans':
	
	{

	only_reg(USER_MODERATOR);

	
	if($topic_info['level_posts'] > USER_LEVEL)err('გამოხმაურებების გადატანა შეუძლებელია', PATH.'post'.ID.'/');

	if(postval('yes', 1))
		{
		check_fields(PATH.'post'.ID.'/trans/', array(array('create', 'values' => array('0', '1'))));

		$create = (bool)$_POST['create'];

		
		if($create)
			{

			check_fields(PATH.'post'.ID.'/trans/', array(array('into_forum', 'not null'), array('topic_name', 'not null', 'minlen' => 2, 'maxlen' => $cfg['maxlen_post'])));

			$into_forum = int($_POST['into_forum']);

			$topic_name = str($_POST['topic_name']);

			$as_first_post = postval('as_first_post', 1);

			if($db -> one("SELECT COUNT(*) FROM `forums` WHERE `id` = '$into_forum'") == 0)err('განყოფილება არაა არჩეული', PATH.'post'.ID.'/trans/');

			$new_topic_author = $as_first_post ? $post_info['user_id'] : USER_ID;

			$new_topic_date = $as_first_post ? $post_info['date'] : TIME;

			$new_topic_last_user_id = $as_first_post ? 0 : $post_info['user_id'];

			$new_topic_last_date = $as_first_post ? 0 : $post_info['date'];

			$new_topic_count_posts = $as_first_post ? 0 : 1;

			$new_topic_first_post = $as_first_post ? ID : 0;


			if(!$db -> sql("INSERT INTO `topics` SET `fid` = '$into_forum', `name` = '$topic_name', `user_id` = '$new_topic_author', `date` = '$new_topic_date', `last_user_id` = '$new_topic_last_user_id', `last_date` = '$new_topic_last_date', `count_posts` = '$new_topic_count_posts', `first_post` = '$new_topic_first_post', `level` = '0', `level_posts` = '1'"))
				{
				err('შეცდომა თემის შექმნისას', PATH.'post'.ID.'/trans/');
				}

			$topic_id = $db -> last_id();
			if(!$db -> sql("UPDATE `posts` SET `tid` = '$topic_id', `fid` = '$into_forum' WHERE `id` = '".ID."'"))
				{
				err('შეცდომა გამოხმაურების გადატანისას ', PATH.'topic'.ID.'/trans/');
				}

			$db -> sql("UPDATE `forums` SET `count_topics` = `count_topics` + 1, `count_posts` = `count_posts` + 1 WHERE `id` = '$into_forum'");
			$db -> sql("UPDATE `forums` SET `count_posts` = `count_posts` - 1 WHERE `id` = '{$forum_info['id']}'");
			$db -> sql("UPDATE `topics` SET `count_posts` = `count_posts` - 1 WHERE `id` = '".ID."'");

			msg('გამოხმაურება გადავიდა<br /><a href="'.PATH.'topic'.$topic_id.'/">თემაში გადასვლა</a>', PATH.'topic'.$topic_info['id'].'/');

			}
		else
			{

			check_fields(PATH.'post'.ID.'/trans/', array(array('into_topic', 'not null')));

			$into_topic = int($_POST['into_topic']);

			if($topic_info['id'] == $into_topic)msg('მონაცემები არ შეიცვალა', PATH.'post'.ID.'/');

			if($db -> one("SELECT COUNT(*) FROM `topics` WHERE `id` = '$into_topic'") == 0)err('თემა არ არსებობს', PATH.'post'.ID.'/trans/');

			$into_topic_info = $db -> fetch("SELECT `name`, `fid`, `last_date`, `last_user_id` FROM `topics` WHERE `id` = '$into_topic'");

			if(!$db -> sql("UPDATE `posts` SET `tid` = '$into_topic', `fid` = '{$into_topic_info['fid']}' WHERE `id` = '".ID."'"))
				{
				err('შეცდომა გამოხმაურების გადატანისას', PATH.'post'.ID.'/trans/');
				}

			
			$last_date = max($into_topic_info['last_date'], $post_info['date']);
			$last_user_id = ($into_topic_info['last_date'] > $post_info['date']) ? $into_topic_info['last_user_id'] : $post_info['id'];
			if(!$db -> sql("UPDATE `topics` SET `last_date` = '$last_date', `last_user_id` = '$last_user_id', `count_posts` = `count_posts` + 1 WHERE `id` = '$into_topic'"))
				{
				err('შეცდომა თემის შეცვლისას (ნომერი '.$into_topic.')', PATH.'post'.ID.'/trans/');
				}


			$db -> sql("UPDATE `forums` SET `count_posts` = `count_posts` + 1 WHERE `id` = '{$into_topic_info['fid']}'");
			$db -> sql("UPDATE `forums` SET `count_posts` = `count_posts` - 1 WHERE `id` = '{$forum_info['id']}'");
			$db -> sql("UPDATE `topics` SET `count_posts` = `count_posts` - 1 WHERE `id` = '".ID."'");
			msg('გამოხმაურება გადატანილია<br /><a href="'.PATH.'topic'.$into_topic.'/">თემაში გადასვლა</a>', PATH.'topic'.$topic_info['id'].'/');

			}


		}

	
	if($db -> one("SELECT COUNT(*) FROM `forums`") > 0)
		{
		$template_forums = array();

				while($forum = $db -> fetch("SELECT `id`, `name` FROM `forums` ORDER BY `position` ASC"))
			{
			$template_forum = array('id' => $forum['id'], 'name' => $forum['name']);

			$template_forums[] = $template_forum;

			}

		$template -> assign('forums', $template_forums);

		}


	$template -> block = 'trans';

	$template -> page_zag = 'გამოხმაურების გადატანა';

	}
	break;
	
	case 'answer';
	
	case 'quote';
	
	{
	only_reg();

	$template -> mode = MODE;

	
	if(!$topic_info['open'] && USER_LEVEL < USER_MODERATOR)err('თემა დახურულია', PATH.'post'.ID.'/');

	
	if($topic_info['level_posts'] > USER_LEVEL)err('თქვენ არ შეგიძლიათ დაწეროთ პოსტები', PATH.'post'.ID.'/');

	
	if((TIME - $userdata['date_reg']) < $cfg['time_silence'])err('თქვენ ჯერ არ შეგიძლიათ აქტიურობა ამ განყოფილებაში.', PATH.'post'.ID.'/');

	
	if($db -> one("SELECT COUNT(*) FROM `users_punishes` WHERE `user_id` = '".USER_ID."' AND `to_date` > '".TIME."' AND `ban` = '1'") > 0)err('თქვენ დაბლოკილი ხართ', PATH.'post'.ID.'/');

	if($cfg['time_antispam_posts'] > 0 && USER_LEVEL < USER_ADMIN)
		{
		if(($last_post = $db -> one("SELECT MAX(`date`) FROM `posts` WHERE `user_id` = '".USER_ID."'")) > 0)
			{
			if((TIME - $last_post) < $cfg['time_antispam_posts'])
				{
				err('ასე სწრაფად არ შეიძლება პოსტების წერა', PATH.'post'.ID.'/');
				}
			}
		}

	if(postval('add', 1))
		{
		check_fields(PATH.'post'.ID.'/'.MODE.'/', array(array('post', 'not null', 'minlen' => 2, 'maxlen' => $cfg['maxlen_post'])));

		$post = str($_POST['post']);

		check_repeat_post(PATH.'post'.ID.'/'.MODE.'/', $post);

		if($db -> sql("INSERT INTO `posts` SET `tid` = '{$topic_info['id']}', `fid` = '{$forum_info['id']}', `user_id` = '".USER_ID."', `date` = '".TIME."', `ip` = '".MY_INT_IP."', `ua` = '".MY_UA."', `answer_to` = '".ID."'"))
			{
			$post_id = $db -> last_id();
			if($db -> sql("INSERT INTO `posts_text` SET `pid` = '$post_id', `text` = '$post'"))
				{
				$db -> sql("INSERT INTO `posts_answers` SET `user_id` = '{$post_info['user_id']}', `pid` = '".ID."', `answer_user` = '".USER_ID."', `answer_pid` = '$post_id', `tid` = '{$topic_info['id']}', `date` = '". TIME."'");
				$db -> sql("UPDATE `forums` SET `count_posts` = `count_posts` + '1' WHERE `id` = '{$forum_info['id']}'");
				$db -> sql("UPDATE `topics` SET `count_posts` = `count_posts` + '1', `last_date` = '".TIME."', `last_user_id` = '".USER_ID."' WHERE `id` = '{$topic_info['id']}'");
				
				msg('გამოხმაურება დაემატა', PATH.'post'.$post_id.'/');
				}
			else
				{
				$db -> sql("DELETE FROM `posts` WHERE `id` = '$post_id'");
				err('შეცდომა', PATH.'post'.ID.'/'.MODE.'/');
				}
			}
		else
			{
			err('შეცდომა', PATH.'post'.ID.'/'.MODE.'/');
			}

		}

	$template -> short_post_text = get_short_post($post_info['text']);

	$template -> page_zag = 'პასუხი გამოხმაურებაზე';

	$template -> block = 'answer';

	if(MODE == 'answer')$template -> answer_text = '[b]'.get_user($post_info['user_id']).'[/b], ';
	else $template -> answer_text = '[quote='.get_user($post_info['user_id']).']'.$post_info['text'].'[/quote]
';

	}
	break;
	
	case 'punish':
	
	{

	if(((USER_LEVEL < USER_MODERATOR || get_user($post_info['user_id'], 'level') > USER_LEVEL) && USER_ID != 1) || $post_info['user_id'] == USER_ID)locate(PATH.'post'.ID.'/');

	if($db -> one("SELECT COUNT(*) FROM `users_punishes` WHERE `user_id` = '{$post_info['user_id']}' AND `to_date` > '".TIME."' AND `ban` = '1' ORDER BY `date` DESC LIMIT 0,1") > 0)
		{
		err('მომხმარებელი &quot;'.get_user($post_info['user_id']).'&quot; უკვე დაბლოკილია', PATH.'post'.ID.'/');
		}

	if(postval('punish', 1))
		{
		check_fields(PATH.'post'.ID.'/punish/', array(array('rule'), array('time1', 'not null'), array('time2', 'not null'), array('comment', 'maxlen' => 500)));

		$rule = int($_POST['rule']);

		$time1 = int($_POST['time1']);
		$time2 = int($_POST['time2']);
		$to_date = TIME + ($time1 * $time2);

		$comment = str($_POST['comment']);

		$ban = postval('ban', 1, false);
		$close_private = postval('close_private', 1, false);

		if($db -> sql("INSERT INTO `users_punishes` SET `rule` = '$rule', `user_id` = '{$post_info['user_id']}', `date` = '".TIME."', `to_date` = '$to_date', `comment` = '$comment', `pid` = '".ID."', `punished_user_id` = '".USER_ID."', `ban` = '$ban', `close_private` = '$close_private', `ip` = '".MY_INT_IP."', `ua` = '".MY_UA."'"))
			{
			$punish_id = $db -> last_id();
			if($db -> sql("UPDATE `users` SET `punish_ban` = '$ban', `punish_pid` = '".ID."', `punish_to_date` = '$to_date' WHERE `id` = '{$post_info['user_id']}'"))
				{

				msg('მომხმარებელი &quot;'.get_user($post_info['user_id']).'&quot; დასჯილია', PATH.'post'.ID.'/');

				}
			else
				{
				err('შეცდომა მომხმარებლის ინფორმაციის შეცვლისას', PATH.'post'.ID.'/punish/');
				}

			}
		else
			{
			err('შეცდომა დარღვევის შენახვისას', PATH.'post'.ID.'/punish/');
			}


		}

	
	$count_rules = $db -> one("SELECT COUNT(*) FROM `rules`");
	if($count_rules > 0)
		{
		$template_rules_cat = array();
				while($rules_cat = $db -> fetch("SELECT * FROM `rules_cats` ORDER BY `position` ASC"))
			{
			$template_rules_cat = array('id' => $rules_cat['id'], 'name' => $rules_cat['name']);

			

			
			if($db -> one("SELECT COUNT(*) FROM `rules` WHERE `cid` = '{$rules_cat['id']}' AND `title` != ''") > 0)
				{
						while($rule = $db -> fetch("SELECT * FROM `rules` WHERE `cid` = '{$rules_cat['id']}' AND `title` != '' ORDER BY `title` ASC"))
					{
					$template_rule = array('id' => $rule['id'], 'title' => $rule['title']);

					$template_rules[] = $template_rule;
					}
				}
			}
		$template -> assign('rules', $template_rules);
		}



	$template -> page_zag = 'დაბლოკვა';

	$template -> block = 'punish';

	}
	break;
	}

$template -> display('post.page');

show_foot();

?>