<?php


	require 'sys/inc/core.php';

unset($template);

if(!file_exists(CONFIG_DIR.'sitemap.xml') || (TIME - filemtime(CONFIG_DIR.'sitemap.xml')) > 259200)
	{
	generate_sitemap();
	}

header('Content-Type: text/xml;charset=utf-8');
header('Content-Length: '.filesize(CONFIG_DIR.'sitemap.xml'));
readfile(CONFIG_DIR.'sitemap.xml');
exit;


?>