<?php


$smiles = array
	(
	':)' => 'smile.gif',
	':(' => 'smile2.gif',
	';)' => 'smile3.gif',
	'%)' => 'smile4.gif',
	'8)' => '8.gif',
	':D' => 'bugaga.gif',
	';D' => 'D.gif',
	':P' => 'P.gif',
	':O' => 'O.gif',
	':beer:' => 'beer.gif',
	':brawo:' => 'brawo.gif',
	':bomb:' => 'bomb.gif',
	':bye:' => 'bye.gif',
	':crazy:' => 'crazy.gif',
	':dance:' => 'dance.gif',
	':hello:' => 'hello.gif',
	':help:' => 'help.gif',
	':kiss:' => 'kiss.gif',
	':love:' => 'love.gif',
	':music:' => 'music.gif',
	':no:' => 'no.gif',
	':ok:' => 'ok.gif',
	':rolf:' => 'rolf.gif',
	':stena:' => 'stena.gif',
	':stop:' => 'stop.gif',
	':write:' => 'write.gif',
	':yes:' => 'yes.gif',
	':admin:' => 'admin.gif',
	':moder:' => 'moder.gif',
	':zona:' => 'zona.gif'
	);


		function get_user($user_id, $field = 'nick', $one = false)
	{
	static $users, $count;

	if(!isset($users[$user_id][$field]))
		{

		$db = $GLOBALS['db'];

		if($db -> one("SELECT COUNT(*) FROM `users` WHERE `id` = '$user_id'") > 0)
			{
			$count[$user_id][$field] = 0;
			if($field == 'viewnick')
				{
				
				$data = $db -> fetch("SELECT `id`, `nick`, `level`, `date_last_visit`, `punish_to_date`, `punish_pid`, `punish_ban` FROM `users` WHERE `id` = '$user_id'");


				
				if(TIME < $data['punish_to_date'])
					{
					
					$pid = $GLOBALS['post']['id'];

					if($data['punish_pid'] == $pid)
						{
						$GLOBALS['post']['punish'] = array('ban' => $data['punish_ban']);
						$data['nick'] = ($data['punish_ban'] ? '#' : '!').$data['nick'];
						}

					$data['nick'] = '<font color="black">'.$data['nick'].'</font>';

					}
				$result = '<a href="'.PATH.'user'.$user_id.'/"><b>'.$data['nick'].'</b></a>';

				
				$result  .= ' <small>'.(((TIME - $data['date_last_visit']) < 300) ? '<font color="green">'.(($data['date_last_visit'] - TIME) == 0 ? 'on' : 'away '.(TIME - $data['date_last_visit'])).'</font>' : '<font color="red">off</font>').'</small>';


				$users[$user_id][$field] = $result;

				
				}
			else
				{
				$users[$user_id][$field] = $db -> one("SELECT `$field` FROM `users` WHERE `id` = '$user_id'");
				}
			}
		else
			{
			$users[$user_id][$field] = 'Unknow';
			}
		}

	$count[$user_id][$field] ++;

	if(!$one || $count[$user_id][$field] <= 1)return $users[$user_id][$field];
	return null;
	}



		function show_user($data)
	{
	
	


	$nick = $data['user_nick'];
	
	if($data['user_active'] == 0)
		{
		$nick = '<font color="black"><strike>'.$nick.'</strike></font>';
		}
	else
	
	if(TIME < $data['user_punish_to_date'])
		{
		if($data['user_ban'])$nick = '<strike>'.$nick.'</strike>';

		if($data['user_punish_pid'] == $data['id'])
			{
			$nick = ($data['user_punish_ban'] ? '#' : '!').$nick;
			}

		$nick = '<font color="black">'.$nick.'</font>';

		}
	$nick = '<a href="'.PATH.'user'.$data['user_id'].'/"><b>'.$nick.'</b></a>';

	$nick  .= ' <small>'.(((TIME - $data['user_visit']) < 300) ? '<font color="green">'.(($data['user_visit'] - TIME) == 0 ? 'on' : 'away '.(TIME - $data['user_visit'])).'</font>' : '<font color="red">off</font>').'</small>';

	return $nick;
	}


		function show_topic_icons($data)
	{
	
	
	$result = null;

	if($data['top'])$result = '!'.$result;

	if(!$data['open'])$result = '#'.$result;

	if(USER_LEVEL < $data['level_posts'])$result = '~'.$result;

	if($data['view_date'] < (!empty($data['last_date']) ? $data['last_date'] : $data['date']))$result  = '&raquo;'.$result;


	return (!empty($result) ? '<b>'.$result.'</b>' : null);
	}

		function check_repeat_post($to, $text)
	{
	$db = $GLOBALS['db'];

	if($db -> one("SELECT COUNT(*) FROM `posts` AS `p`, `posts_text` AS `p_t` WHERE `p`.`user_id` = '".USER_ID."' AND `p`.`date` > ('".TIME."' - 300) AND `p_t`.`pid` = `p`.`id` AND `p_t`.`text` = '$text'"))
		{
		err('თქვენი შეტყობინება იმეორებს წინას', $to);
		}

	return true;
	}

		function get_short_post($text)
	{
	if(xstrlen($text) > $GLOBALS['cfg']['maxlen_short_post'])$text = xsubstr($text, 0, $GLOBALS['cfg']['maxlen_short_post']).' ...';

	return $text;
	}

		function post($text, $nl2br = true, $smiles = true, $bbcode = true)
	{
	$userdata = $GLOBALS['userdata'];
	$smiles = $GLOBALS['smiles'];

	if($smiles)
		{


				foreach($smiles as $smile => $image)
			{
			$text = str_replace($smile, '<img src="http://'.DOMAIN.PATH.'/images/smiles/'.$image.'" alt="'.$smile.'" title="'.$smile.'"/>', $text);
			}

		}

	if($bbcode)
		{
		
		$text = preg_replace('~\[(b|i|u|small)\](.+)\[\/\\1\]~uUs','<$1>$2</$1>', $text);
		$text = preg_replace('~\[(del|strike)\](.+)\[\/\\1\]~uUs','<strike>$2</strike>', $text);
		$text = preg_replace('~\[offtop\](.+)\[\/offtop\]~uUs','<span class="offtop">$1</span>', $text);
		$text = preg_replace('~\[geo\](.+)\[\/geo\]~uUse','translit(\'\\1\')', $text);

		
		$text = preg_replace_callback('~\[url(=(.+))?\](.+)\[\/url\]~uUs','bbcode_url', $text);
		
		
		$text = preg_replace_callback('~\[img(=(.+))?\](.+)\[\/img\]~uUs','bbcode_img', $text);
		
		
		$text = preg_replace_callback('~\[youtube(=(.+))?\](.+)\[\/youtube\]~uUs','bbcode_youtube', $text);

		
		$text = preg_replace('~\[(red|blue|green|yellow|black)\](.+)\[\/\\1\]~uUs','<font color="$1">$2</font>', $text);

		
		$text = preg_replace_callback('~\[(hide|hidden)\](.+)\[\/\\1\]~uUs','bbcode_hide', $text);

		
		$text = preg_replace_callback('~\[code\](.+)\[\/code\]~uUs','bbcode_code', $text);

		
		$text = str_replace(array('[user:id]', '[user:nick]', '[user:name]'), array(USER_ID, $userdata['nick'], $userdata['info_name']), $text);

		
		$text = preg_replace_callback('~\[quote(\=(.+))?\](.+)\[\/quote\]~uUs', 'bbcode_quote', $text);

		}

	if($nl2br)$text = nl2br($text);

	return $text;

	}

		function post_del($text)
	{
	
	$text = preg_replace('~\[(b|i|u|small)\](.+)\[\/\\1\]~uUs','$2', $text);
	$text = preg_replace('~\[(del|strike)\](.+)\[\/\\1\]~uUs','$2', $text);
	$text = preg_replace('~\[offtop\](.+)\[\/offtop\]~uUs','$1', $text);
	$text = preg_replace('~\[geo\](.+)\[\/geo\]~uUse','translit(\'\\1\')', $text);

	
	$text = preg_replace('~\[url\](.+)\[\/url\]~uUs','$1', $text);
	$text = preg_replace('~\[url(=(.+))?\](.+)\[\/url\]~uUs','$3 ($2)', $text);
	$text = preg_replace('~\[img\](.+)\[\/img\]~uUs','$1', $text);
	$text = preg_replace('~\[img(=(.+))?\](.+)\[\/img\]~uUs','$3 ($2)', $text);
	$text = preg_replace('~\[youtube\](.+)\[\/youtube\]~uUs','$1', $text);
	$text = preg_replace('~\[youtube(=(.+))?\](.+)\[\/youtube\]~uUs','$3 ($2)', $text);

	
	$text = preg_replace('~\[(red|blue|green|yellow|black)\](.+)\[\/\\1\]~uUs', '$2', $text);

	
	$text = preg_replace('~\[(hide|hidden)\](.+)\[\/\\1\]~uUs', null, $text);

	
	$text = preg_replace('~\[code\](.+)\[\/code\]~uUse','htmlspecialchars_decode("\\1", ENT_QUOTES)', $text);

	
	$text = str_replace(array('[user:id]', '[user:nick]', '[user:name]'), array(null, null, null), $text);

	
	$text = preg_replace('~\[quote(\=(.+))?\](.+)\[\/quote\]~uUs', '$3', $text);

	return $text;
	}

		function bbcode_url($data)
	{
	
	if(!empty($data[2]))return '<a href="'.$data[2].'" title="'.$data[2].'" target="_blank">'.$data[3].'</a>';
	return '<a href="'.$data[3].'" title="'.$data[3].'">'.$data[3].'</a>';
	}
		function bbcode_img($data)
	{
	
	if(!empty($data[2]))return '<img src="'.$data[2].'" alt="ფოტო სურათი" style="max-width:100%;height:auto;">';
	return '<img src="'.$data[3].'" alt="ფოტო სურათი" style="max-width:100%;height:auto;">';
	}
		function bbcode_youtube($data)
	{
	
	if(!empty($data[2]))return '<iframe width="300" height="220" src="https://www.youtube.com/embed/'.$data[2].'" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>';
	return '<iframe width="300" height="220" src="https://www.youtube.com/embed/'.$data[3].'" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>';
	}

		function bbcode_hide($data)
	{
	return '<div class="hide">'.(USER_AUTH ? $data[2] : 'დაფარული ტექსტი.<br />ტექსტის სანახავად საჭიროა <a href="'.PATH.'login.php?mode=enter">შესვლა</a> თქვენი ანგარიშით.').'</div>';
	}

		function bbcode_code($data)
	{
	$code = $data[1];
	
	
	$code = preg_replace('~\<img src\="http\:\/\/'.DOMAIN.PATH.'\/images\/smiles\/(.*)" alt\="(.*)" title\="(.*)"\/\>~uUs', '$2', $code);

	
	$code = htmlspecialchars_decode($code, ENT_QUOTES);
	$code = str_replace('<br />', null, $code);

	$code = str_replace(array('&#96;', '&#123;', '&#125;', '&#36;'), array('`', '{', '}', '$'), $code);


	
	$code = highlight_php($code);

	return '<div class="code">'.$code.'</div>';

	

	}

		function bbcode_quote($data)
	{
	return '<div class="quote">'.(!empty($data[2]) ? '<b>'.$data[2].'</b> :<br />' : null).'<span class="quote_text">'.$data[3].'</span></div>';
	}


		function generate_sitemap()
	{
	$db = $GLOBALS['db'];

	file_write(CONFIG_DIR.'sitemap.xml', 'w', null);

	$rn = "\r\n";

	$result = '<?xml version="1.0" encoding="UTF-8"?>'.$rn;
	$result .= '<urlset>'.$rn;

	
			while($topic = $db -> fetch("SELECT `id`, `top` FROM `topics` WHERE `level` <= '0' AND (SELECT `level` FROM `forums` WHERE `id` = `topics`.`fid`) <= '0'"))
		{
		$result .= '	<url>';
		if($topic['top'] == 1)$result .= '		<priority>1.0</priority>';
		$result .= '		<loc>http://'.DOMAIN.PATH.'topic'.$topic['id'].'/</loc>';
		$result .= '	</url>';
		}

	$result .= '</urlset>';

	if(file_write(CONFIG_DIR.'sitemap.xml', 'w', $result))
		{
		return true;
		}

	return false;
	}


?>