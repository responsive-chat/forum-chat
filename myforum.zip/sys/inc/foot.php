<?php


$template -> microtime = round(microtime(true) - MT, 3);
$template -> display('footer');

		while(ob_get_level())
	{
	ob_end_flush();
	}

exit;


?>