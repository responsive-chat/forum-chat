<?php


header('Content-Type: text/html;charset=utf-8');
header('Expires: Mon, 26 Jul 1997 05:00:00 GMT');
header('Cache-Control: no-cache, must-revalidate');
header('Pragma: no-cache');
header('Last-Modified: '.gmdate('D, d M Y H:i:s').'GMT');

if(substr_count(MY_ACCEPT_ENCODING, 'deflate'))
	{
			function output_compress($output, $mark = true)
		{
		if($mark == true)$output = output_mark($output);
		return gzdeflate($output, 9);
		}

	header('Content-Encoding: deflate');
	ob_implicit_flush(0);
	$gzip_method = 'deflate';

	}
elseif(substr_count(MY_ACCEPT_ENCODING, 'gzip'))
	{
			function output_compress($output, $mark = true)
		{
		if($mark == true)$output = output_mark($output);
		return gzencode($output, 9);
		}

	header('Content-Encoding: gzip');
	ob_implicit_flush(0);
	$gzip_method = 'gzip';

	}
elseif(substr_count(MY_ACCEPT_ENCODING, 'x-gzip'))
	{

			function output_compress($output, $mark = true)
		{
		if($mark == true)$output = output_mark($output);
		$size = strlen($output);
		$crc = crc32($output);
		$output = gzcompress($output, 9);
		$output = substr($output, 0, strlen($output) - 4);
		return "\x1f\x8b\x08\x00\x00\x00\x00\x00".$output.pack('V', $crc).pack('V', $size);
		}

	header('Content-Encoding: x-gzip');

	ob_implicit_flush(0);
	$gzip_method = 'x-gzip';

	}
else
	{
			function output_compress($output, $mark = true)
		{
		if($mark == true)$output = output_mark($output);
		return $output;
		}
		$gzip_method = 'none';
	}

		function output_mark($content)
	{
	
	return $content;
	}

ob_start('output_compress');

$template -> page_title = $page_title;
$template -> page_sec = $page_sec;

$template -> display('header');

if(USER_AUTH)
	{
	$template -> user_nick = $userdata['nick'];
	$template -> user_id = USER_ID;

	
	$count_answer_to_my_posts =& $GLOBALS['count_answer_to_my_posts'];
	$count_answer_to_my_posts = $db -> one("SELECT COUNT(*) FROM `posts_answers` WHERE `user_id` = '".USER_ID."'");
	if($count_answer_to_my_posts > 0)
		{
		$template -> user_count_answers = $count_answer_to_my_posts;
		}

	
	$count_new_private_messages = $db -> one("SELECT COUNT(*) FROM `private_messages` WHERE `new` = '1' AND (`to_user_id` = '".USER_ID."')");
	if($count_new_private_messages > 0 && substr(MY_URI, 0, strlen(PATH.'umenu.php?mode=private')) != PATH.'umenu.php?mode=private')
		{
		$template -> user_count_pm_new = $count_new_private_messages;
		}

	
	
	$count_new_messages_from_bookmarks_topics = $db -> one("SELECT COUNT(*)
FROM `topics` AS `t`, `topics_bookmarks` AS `t_b`
WHERE `t_b`.`user_id` = '".USER_ID."' AND `t`.`id` = `t_b`.`tid` AND `t`.`last_date` > `t_b`.`date`");

	if($count_new_messages_from_bookmarks_topics > 0 && substr(MY_URI, 0, strlen(PATH.'umenu.php?mode=bookmarks')) != PATH.'umenu.php?mode=bookmarks')
		{
		$template -> user_count_new_msg_bookmarks = $count_new_messages_from_bookmarks_topics;
		}

	
	if($userdata['punish_to_date'] > TIME)
		{
		$template -> user_punish = true;
		$template -> user_ban = (bool)$userdata['punish_ban'];
		}

	$template -> display('user.block');
	}
	


if(isset($_SESSION['msg']) && count($_SESSION['msg']) > 0)
	{

	$GLOBALS['backup']['session_msgs'] = $_SESSION['msg'];

	$template -> messages = $_SESSION['msg'];
	$template -> display('msg.block');

	unset($_SESSION['msg']);

	

	}

if(isset($_SESSION['err']) && count($_SESSION['err']) > 0)
	{

	$GLOBALS['backup']['session_erros'] = $_SESSION['err'];

	$template -> errors = $_SESSION['err'];
	$template -> display('err.block');

	

	unset($_SESSION['err']);

	

	}


?>