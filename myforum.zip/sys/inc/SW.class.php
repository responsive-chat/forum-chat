<?php


class SW
	{

	public $mysql_prefix = null;

	private $mysql_connect = false;
	private $connected = false;
	private $mysql_db = null;
	private $fetch_sqls = array();
	private $debug_mode = false;

	private $tables = array();

			function __construct($user = 'root', $password = null, $host = 'localhost', $db = null, $prefix = null, $debug_mode = false)
		{

		$this -> debug_mode = $debug_mode;

		if(!($this -> mysql_connect = @mysql_connect($host, $user, $password)))
			{
			if($this -> debug_mode)$this -> fatalError('შეუძლებელია დაკავშირება');
			}

		$this -> connected = true;
		@mysql_query('SET NAMES utf8', $this -> mysql_connect);


		if(!empty($prefix))
			{
			$this -> mysql_prefix = $prefix;
			}

		if(!empty($db))
			{

			$this -> select_db($db);

			}

		}

			function __destruct()
		{
		if($this -> connected)
			{
			@mysql_close($this -> mysql_connect);
			}
		}

			public function select_db($db = null)
		{
		if(!(@mysql_select_db($db,$this -> mysql_connect)))
			{
			if($this -> debug_mode)$this -> fatalError('Невозможно выбрать бд');
			return false;
			}
		$this -> mysql_db = $db;

		$this -> tables[$db] = array();
		if(!empty($this -> mysql_prefix))
			{
					while($table = $this -> fetch('SHOW TABLES'))
				{
				$this -> tables[$db][] = substr($table[0], strlen($this -> mysql_prefix));
				}

			}

		return true;

		}

			public function sql($sql = null, $add_prefix = true)
		{

		if(empty($sql))
			{
			if($this -> debug_mode)$this -> fatalError('არ არის მითითებული SQL ბრძანება');
			return false;
			}

		if($add_prefix)$sql = $this -> prepare($sql);

		if(!($result = @mysql_query($sql,$this -> mysql_connect)))
			{
			if($this -> debug_mode)$this -> fatalError('<p>შეცდომა SQL ბრძანებაში <code><i>"'.$sql.'"</i></code> : '.@mysql_error($this -> mysql_connect).'</p>');

			return @mysql_error($this -> mysql_connect);
			}

		$this -> fetch_sql = array($sql, $result);

		return $result;

		}

			public function prepare($sql)
		{
		if(!empty($this -> mysql_prefix))
			{
			$sql = preg_replace('~`('.implode('|', $this -> tables[$this -> mysql_db]).')`~', '`'.$this -> mysql_prefix.'$1`', $sql);
			}

		return $sql;
		}

			public function one($sql)
		{
		return @mysql_result($this -> sql($sql), 0);
		}

			public function allfetch($sql, $one_field = false)
		{
		$data = array();

				while($res = $this -> fetch($sql))
			{
			$data[] = ($one_field ? $res[0] : $res);
			}

		return (count($data) > 0) ? $data : null;
		}

			public function last_id()
		{
		
		return $this -> one('SELECT LAST_INSERT_ID()');
		}

			public function fetch($sql)
		{

		if(is_resource($sql))
			{
			if(get_resource_type($sql) == 'mysql result')
				{
				return @mysql_fetch_array($sql);
				}
			else
				{
				if($this -> debug_mode)fatalError('არასწორია შეყვანილი მონაცემები');
				return false;
				}
			}

		$backtrace = debug_backtrace();
		$postfix = $backtrace[0]['line'].'_'.$backtrace[0]['file'];

		if(!isset($this -> fetch_sqls[$sql.':'.$postfix]))
			{
			$this -> fetch_sqls[$sql.':'.$postfix] = $this -> sql($sql);
			}

			return @mysql_fetch_array($this -> fetch_sqls[$sql.':'.$postfix]);

		}

			public function num_rows($sql)
		{
		if(is_resource($sql))
			{
			if(get_resource_type($sql) == 'mysql result')
				{
				return @mysql_num_rows($sql);
				}
			else
				{
				if($this -> debug_mode)fatalError('არასწორია შეყვანილი მონაცემები');
				return false;
				}
			}


		return @mysql_num_rows($this -> sql($sql));
		}

			public function connect()
		{
		return $this -> mysql_connect;
		}

			public function is_connect()
		{
		return $this -> connected;
		}

			private function fatalError($msg = 'უცნობი შეცდომა')
		{
		die('<b>SW error</b> : '.$msg);
		}

	}


?>