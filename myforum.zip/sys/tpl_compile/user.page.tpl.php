<?php /* გენერირებულია 5:27:55 11.10.2020 ფაილიდან /home/f0474738/domains/forumi.eu.org/public_html/sys/tpl_compile/user.page.tpl */ ?>
<?php switch(isset($this -> vars['block']) ? $this -> vars['block'] : null): ?>
<?php case 'index': ?>

სტატუსი: <b><?php if(isset($this -> vars['user']['status']))echo $this -> vars['user']['status']; ?></b><br />
დარეგისტრირდა: <b><?php if(isset($this -> vars['user']['reg']))echo $this -> vars['user']['reg']; ?></b><br />
<?php if(isset($this -> vars['user']['last']) && (bool)$this -> vars['user']['last']): ?>ბოლო ვიზიტი: <b><?php if(isset($this -> vars['user']['last']))echo $this -> vars['user']['last']; ?></b><br /><?php endif; ?>
<?php if(isset($this -> vars['user']['online']) && $this -> vars['user']['online'] === true): ?><span class="msg">მომხმარებელი ამჟამად საიტზეა</span><br /><?php endif; ?>
<?php if(!isset($this -> vars['user']['active']) || $this -> vars['user']['active'] !== true): ?><span class="err">მომხმარებელი დეაქტივირებულია</span><br /><?php endif; ?>
<?php if(isset($this -> vars['punish']) && $this -> vars['punish'] === true): ?>
<br />
<span class="err">მომხმარებელი <?php if(isset($this -> vars['punish_ban']) && $this -> vars['punish_ban'] === true): ?>დაბლოკილია<?php endif; ?><?php if(!isset($this -> vars['punish_ban']) || $this -> vars['punish_ban'] !== true): ?>გაფრთხილებულია<?php endif; ?></span><br />
<?php if(isset($this -> vars['punish_rule']) && (bool)$this -> vars['punish_rule']): ?>წესების დარღვევა: <a href="<?php if(isset($this -> vars['path']))echo $this -> vars['path']; ?>index.php?mode=rules&id=<?php if(isset($this -> vars['punish_rule']['cid']))echo $this -> vars['punish_rule']['cid']; ?>&rid=<?php if(isset($this -> vars['punish_rule']['id']))echo $this -> vars['punish_rule']['id']; ?>#rule-<?php if(isset($this -> vars['punish_rule']['id']))echo $this -> vars['punish_rule']['id']; ?>"><?php if(isset($this -> vars['punish_rule']['title']))echo $this -> vars['punish_rule']['title']; ?></a><br /><?php endif; ?>
ავტომატურად <?php if(isset($this -> vars['punish_ban']) && $this -> vars['punish_ban'] === true): ?>ბლოკის<?php endif; ?><?php if(!isset($this -> vars['punish_ban']) || $this -> vars['punish_ban'] !== true): ?>გაფრთხილების<?php endif; ?> მოხსნამდე დარჩა: <?php if(isset($this -> vars['punish_time']))echo $this -> vars['punish_time']; ?><br />
<?php if(isset($this -> vars['punish_post']) && (bool)$this -> vars['punish_post']): ?>დასჯილია <a href="<?php if(isset($this -> vars['path']))echo $this -> vars['path']; ?>post<?php if(isset($this -> vars['punish_post']))echo $this -> vars['punish_post']; ?>/">ამ</a> პოსტისთვის<br /><?php endif; ?>
<?php if(isset($this -> vars['punish_all']) && (bool)$this -> vars['punish_all']): ?>სულ დასჯების რაოდენობა: <a href="<?php if(isset($this -> vars['path']))echo $this -> vars['path']; ?>user<?php if(isset($this -> vars['user']['id']))echo $this -> vars['user']['id']; ?>/punishes/"><?php if(isset($this -> vars['punish_all']))echo $this -> vars['punish_all']; ?></a><br /><?php endif; ?><?php endif; ?>
<br />
თემების რაოდენობა: <a href="<?php if(isset($this -> vars['path']))echo $this -> vars['path']; ?>user<?php if(isset($this -> vars['user']['id']))echo $this -> vars['user']['id']; ?>/topics/"><?php if(isset($this -> vars['user']['count_topics']))echo $this -> vars['user']['count_topics']; ?></a><br />
გამოხმაურებების რაოდენობა: <a href="<?php if(isset($this -> vars['path']))echo $this -> vars['path']; ?>user<?php if(isset($this -> vars['user']['id']))echo $this -> vars['user']['id']; ?>/posts/"><?php if(isset($this -> vars['user']['count_posts']))echo $this -> vars['user']['count_posts']; ?></a><br />
<?php if(isset($this -> vars['user']['info_name']) && (bool)$this -> vars['user']['info_name']): ?>სახელი: <b><?php if(isset($this -> vars['user']['info_name']))echo $this -> vars['user']['info_name']; ?></b><br /><?php endif; ?>
<?php if(isset($this -> vars['user']['info_birthday']) && (bool)$this -> vars['user']['info_birthday']): ?>დაბადების თარიღი: <?php if(isset($this -> vars['user']['info_birthday']))echo $this -> vars['user']['info_birthday']; ?><br /><?php endif; ?>
<?php if(isset($this -> vars['user']['info_city']) && (bool)$this -> vars['user']['info_city']): ?>მდებარეობა: <?php if(isset($this -> vars['user']['info_city']))echo $this -> vars['user']['info_city']; ?><br /><?php endif; ?>
<?php if(isset($this -> vars['user']['info_email']) && (bool)$this -> vars['user']['info_email']): ?>ელ. ფოსტა: <?php if(isset($this -> vars['user']['info_email']))echo $this -> vars['user']['info_email']; ?><br /><?php endif; ?>
<?php if(isset($this -> vars['user']['info_tel']) && (bool)$this -> vars['user']['info_tel']): ?>ტელ. ნომერი: <?php if(isset($this -> vars['user']['info_tel']))echo $this -> vars['user']['info_tel']; ?><br /><?php endif; ?>
<?php if(isset($this -> vars['user']['info_site']) && (bool)$this -> vars['user']['info_site']): ?>ვებსაიტი: <a href="<?php if(isset($this -> vars['user']['info_site']))echo $this -> vars['user']['info_site']; ?>"><?php if(isset($this -> vars['user']['info_site']))echo $this -> vars['user']['info_site']; ?></a><br /><?php endif; ?>
<?php if(isset($this -> vars['user']['info_avatar']) && (bool)$this -> vars['user']['info_avatar']): ?><a href="<?php if(isset($this -> vars['user']['info_avatar']))echo $this -> vars['user']['info_avatar']; ?>"><img src="<?php if(isset($this -> vars['user']['info_avatar']))echo $this -> vars['user']['info_avatar']; ?>" height="150" width="150" alt="avatar" /></a><br /><?php endif; ?>
სქესი: <?php if(isset($this -> vars['user']['info_sex']))echo $this -> vars['user']['info_sex']; ?><br />
<?php if(isset($this -> vars['user']['info_interest']) && (bool)$this -> vars['user']['info_interest']): ?>ინტერესები: <?php if(isset($this -> vars['user']['info_interest']))echo $this -> vars['user']['info_interest']; ?><br /><?php endif; ?>
<?php if(isset($this -> vars['user']['info_about']) && (bool)$this -> vars['user']['info_about']): ?>ჩემს შესახებ: <?php if(isset($this -> vars['user']['info_about']))echo $this -> vars['user']['info_about']; ?><br /><?php endif; ?>
<br />
<?php if(isset($this -> vars['user_id']) && isset($this -> vars['user']['id']) && $this -> vars['user_id'] == $this -> vars['user']['id']): ?>&raquo; <a href="<?php if(isset($this -> vars['path']))echo $this -> vars['path']; ?>umenu.php?mode=info">ანკეტის რედაქტირება</a><br /><?php endif; ?>
<?php if(isset($this -> vars['user_id']) && isset($this -> vars['user']['id']) && $this -> vars['user_id'] != $this -> vars['user']['id']): ?>&raquo; <a href="<?php if(isset($this -> vars['path']))echo $this -> vars['path']; ?>umenu.php?mode=private&act=user&id=<?php if(isset($this -> vars['user']['id']))echo $this -> vars['user']['id']; ?>">წერილის მიწერა</a><br /><?php endif; ?>
<?php if(isset($this -> vars['manage_moderator']) && $this -> vars['manage_moderator'] === true): ?>
&raquo; <a href="<?php if(isset($this -> vars['path']))echo $this -> vars['path']; ?>user<?php if(isset($this -> vars['user']['id']))echo $this -> vars['user']['id']; ?>/edit/">პროფილის შეცვლა</a><br />
<?php if(isset($this -> vars['user_id']) && isset($this -> vars['user']['id']) && $this -> vars['user_id'] != $this -> vars['user']['id']): ?>
&raquo; <a href="<?php if(isset($this -> vars['path']))echo $this -> vars['path']; ?>user<?php if(isset($this -> vars['user']['id']))echo $this -> vars['user']['id']; ?>/punish/">დაბლოკვა</a><br />
<?php if(isset($this -> vars['manage_admin']) && $this -> vars['manage_admin'] === true): ?>
&raquo; <a href="<?php if(isset($this -> vars['path']))echo $this -> vars['path']; ?>user<?php if(isset($this -> vars['user']['id']))echo $this -> vars['user']['id']; ?>/<?php if(isset($this -> vars['user']['active']) && $this -> vars['user']['active'] === true): ?>de<?php endif; ?>active/"><?php if(isset($this -> vars['user']['active']) && $this -> vars['user']['active'] === true): ?>დე<?php endif; ?>აქტივაცია პროფილის</a><br /><?php endif; ?><?php endif; ?><?php endif; ?>

<?php break; ?>


<?php case 'edit': ?>

<form action="<?php if(isset($this -> vars['path']))echo $this -> vars['path']; ?>user<?php if(isset($this -> vars['user']['id']))echo $this -> vars['user']['id']; ?>/edit/<?php if(isset($this -> vars['rand']))echo $this -> vars['rand']; ?>/" method="post"><input type="hidden" name="edit" value="1"/>
მეტსახელი: <br />
<input type="text" name="nick" value="<?php if(isset($this -> vars['user']['nick']))echo $this -> vars['user']['nick']; ?>"/><br />
<?php if(isset($this -> vars['user_level']) && isset($this -> vars['user_admin']) && $this -> vars['user_level'] >= $this -> vars['user_admin']): ?>
<?php if(isset($this -> vars['user_id']) && isset($this -> vars['user']['id']) && $this -> vars['user_id'] != $this -> vars['user']['id']): ?>
პაროლი (თუ არ გსურთ შეცვალოთ, დატოვეთ ველი ცარიელი): <br />
<input type="text" name="password"/><br />
სტატუსის მინიჭება: <br />
<select name="level">
<option value="0"<?php if(isset($this -> vars['user']['level']) && $this -> vars['user']['level'] == 0): ?> selected="selected"<?php endif; ?>>უბრალო სტატუსი</option>
<option value="1"<?php if(isset($this -> vars['user']['level']) && $this -> vars['user']['level'] == 1): ?> selected="selected"<?php endif; ?>>მომხმარებელი</option>
<option value="2"<?php if(isset($this -> vars['user']['level']) && $this -> vars['user']['level'] == 2): ?> selected="selected"<?php endif; ?>>მოდერატორი</option>
<option value="3"<?php if(isset($this -> vars['user']['level']) && $this -> vars['user']['level'] == 3): ?> selected="selected"<?php endif; ?>>ადმინისტრატორი</option>
</select><br />
<label><input type="checkbox" name="active" value="1"<?php if(isset($this -> vars['user']['active']) && $this -> vars['user']['active'] === true): ?> checked="checked"<?php endif; ?>/>მომხმარებლის აქტივაცია</label><br /><?php endif; ?><?php endif; ?>
<hr/>
თემები თითო გვერძზე: <br />
<input type="text" name="set_onpage_topics" value="<?php if(isset($this -> vars['user']['set_onpage_topics']))echo $this -> vars['user']['set_onpage_topics']; ?>" size="4" maxlength="4"/><br />
შეტყობინებები თითო გვერძზე: <br />
<input type="text" name="set_onpage_posts" value="<?php if(isset($this -> vars['user']['set_onpage_posts']))echo $this -> vars['user']['set_onpage_posts']; ?>" size="4" maxlength="4"/><br />
მიმდინარე დრო: <br />
<select name="set_time_shift">
<?php if (!empty($this -> vars['times'])): ?>
		<?php for($_cycles_1_c = count($this -> vars['times']), $_cycles_1_i = 0; $_cycles_1_i < $_cycles_1_c; $_cycles_1_i ++): ?>
	<?php $_cycles_1 = $this -> vars['times'][$_cycles_1_i]; ?>

<option value="<?php if(isset($_cycles_1['shift']))echo $_cycles_1['shift']; ?>"<?php if(isset($_cycles_1['selected']))echo $_cycles_1['selected']; ?>><?php if(isset($_cycles_1['time']))echo $_cycles_1['time']; ?> (<?php if(isset($_cycles_1['shift']))echo $_cycles_1['shift']; ?>)</option>		<?php endfor; ?>
<?php endif; ?>
</select><br />
<label><input type="checkbox" name="set_fast_post" value="1"<?php if(isset($this -> vars['user']['set_fast_post']) && $this -> vars['user']['set_fast_post'] === true): ?> checked="checked"<?php endif; ?>/>სწრაფი პასუხის ველის ჩვენება</label><br />
<hr/>
ნამდვილი სახელი: <br />
<input type="text" name="info_name" value="<?php if(isset($this -> vars['user']['info_name']))echo $this -> vars['user']['info_name']; ?>"/><br />
დაბადების თარიღი: <br />
<input type="text" name="info_birthday" value="<?php if(isset($this -> vars['user']['info_birthday']))echo $this -> vars['user']['info_birthday']; ?>"/><br />
მდებარეობა: <br />
<input type="text" name="info_city" value="<?php if(isset($this -> vars['user']['info_city']))echo $this -> vars['user']['info_city']; ?>"/><br />
ელ. ფოსტა: <br />
<input type="text" name="info_email" value="<?php if(isset($this -> vars['user']['info_email']))echo $this -> vars['user']['info_email']; ?>"/><br />
ტელ. ნომერი: <br />
<input type="text" name="info_tel" value="<?php if(isset($this -> vars['user']['info_tel']))echo $this -> vars['user']['info_tel']; ?>"/><br />
ვებსაიტის ბმული: <br />
<input type="text" name="info_site" value="<?php if(isset($this -> vars['user']['info_site']))echo $this -> vars['user']['info_site']; ?>"/><br />
ფოტო ავატარის ბმული: <br />
<input type="text" name="info_avatar" value="<?php if(isset($this -> vars['user']['info_avatar']))echo $this -> vars['user']['info_avatar']; ?>"/><br />
ინტერესები: <br />
<input type="text" name="info_interest" value="<?php if(isset($this -> vars['user']['info_interest']))echo $this -> vars['user']['info_interest']; ?>"/><br />
ჩემს შესახებ: <br />
<input type="text" name="info_about" value="<?php if(isset($this -> vars['user']['info_about']))echo $this -> vars['user']['info_about']; ?>"/><br />
ჩემი სქესი: <br />
<select name="info_sex">
<option value="0"<?php if(isset($this -> vars['user']['info_sex']) && $this -> vars['user']['info_sex'] == 0): ?> selected="selected"<?php endif; ?>>მდედრობითი</option>
<option value="1"<?php if(isset($this -> vars['user']['info_sex']) && $this -> vars['user']['info_sex'] == 1): ?> selected="selected"<?php endif; ?>>მამრობითი</option>
</select><br />
<input type="submit" value="შენახვა"/><br />
</form>

<?php break; ?>


<?php case 'punish': ?>

<form action="<?php if(isset($this -> vars['path']))echo $this -> vars['path']; ?>user<?php if(isset($this -> vars['user']['id']))echo $this -> vars['user']['id']; ?>/punish/<?php if(isset($this -> vars['rand']))echo $this -> vars['rand']; ?>/" method="post" class="unit"><input type="hidden" name="punish" value="1"/>
სასჯელი წესის მიხედვით: <br />
<select name="rule">
<option value="0">---</option>
<?php if (!empty($this -> vars['rules'])): ?>
		<?php for($_cycles_2_c = count($this -> vars['rules']), $_cycles_2_i = 0; $_cycles_2_i < $_cycles_2_c; $_cycles_2_i ++): ?>
	<?php $_cycles_2 = $this -> vars['rules'][$_cycles_2_i]; ?>

<option value="<?php if(isset($_cycles_2['id']))echo $_cycles_2['id']; ?>"><?php if(isset($_cycles_2['title']))echo $_cycles_2['title']; ?></option>		<?php endfor; ?>
<?php endif; ?>
</select><br />
ბლოკის ვადა: <br />
<input type="text" name="time1" value="1" size="3" maxlength="3"/>
<select name="time2">
<option value="60">წუთი</option>
<option value="3600">საათი</option>
<option value="86400">დღე</option>
<option value="604800">კვირა</option>
<option value="2592000">თვე</option>
</select><br />
კომენტარი: <br />
<input type="text" name="comment" maxlength="500"/><br />
<label><input type="checkbox" name="ban" value="1">პოსტების დაწერის და თემების შექმნის აკრძალვა</label><br />
<label><input type="checkbox" name="close_private" value="1">პირადი წერილების გაგზავნის და წაკითხვის აკრძალვა</label><br />
<input type="submit" value="დაბლოკვა"/>
</form>

<?php break; ?>


<?php case 'punishes': ?>

<?php if (!empty($this -> vars['punishes'])): ?>
		<?php for($_cycles_3_c = count($this -> vars['punishes']), $_cycles_3_i = 0; $_cycles_3_i < $_cycles_3_c; $_cycles_3_i ++): ?>
	<?php $_cycles_3 = $this -> vars['punishes'][$_cycles_3_i]; ?>

<div class="unit"><i>#<?php if(isset($_cycles_3['i']))echo $_cycles_3['i']; ?>.</i> <a href="<?php if(isset($this -> vars['path']))echo $this -> vars['path']; ?>user<?php if(isset($_cycles_3['punished_user_id']))echo $_cycles_3['punished_user_id']; ?>/"><b><?php if(isset($_cycles_3['punished_user']))echo $_cycles_3['punished_user']; ?></b></a> / <?php if(isset($_cycles_3['date']))echo $_cycles_3['date']; ?><br />
<span class="err">მომხმარებელი<?php if(isset($this -> vars['punishes'][$_cycles_3_i]['was']) && $this -> vars['punishes'][$_cycles_3_i]['was'] === true): ?> იყო<?php endif; ?> <?php if(isset($this -> vars['punishes'][$_cycles_3_i]['ban']) && $this -> vars['punishes'][$_cycles_3_i]['ban'] === true): ?>დაბლოკილი<?php endif; ?><?php if(!isset($this -> vars['punishes'][$_cycles_3_i]['ban']) || $this -> vars['punishes'][$_cycles_3_i]['ban'] !== true): ?>გაფრთხილებული<?php endif; ?></span><br />
<?php if(isset($this -> vars['punishes'][$_cycles_3_i]['was']) && $this -> vars['punishes'][$_cycles_3_i]['was'] === true): ?>ბლოკი მოიხსნა: <?php endif; ?><?php if(!isset($this -> vars['punishes'][$_cycles_3_i]['was']) || $this -> vars['punishes'][$_cycles_3_i]['was'] !== true): ?>მოხსნამდე დარჩენილია: <?php endif; ?><?php if(isset($_cycles_3['time']))echo $_cycles_3['time']; ?><br />
<?php if(isset($this -> vars['punishes'][$_cycles_3_i]['rule_title']) && (bool)$this -> vars['punishes'][$_cycles_3_i]['rule_title']): ?>წესების დარღვევა: <a href="<?php if(isset($this -> vars['path']))echo $this -> vars['path']; ?>index.php?mode=rules&id=<?php if(isset($_cycles_3['rule_cid']))echo $_cycles_3['rule_cid']; ?>&rid=<?php if(isset($_cycles_3['rule']))echo $_cycles_3['rule']; ?>#rule-<?php if(isset($_cycles_3['rule']))echo $_cycles_3['rule']; ?>"><?php if(isset($_cycles_3['rule_title']))echo $_cycles_3['rule_title']; ?></a><br /><?php endif; ?>
<?php if(isset($this -> vars['punishes'][$_cycles_3_i]['post']) && (bool)$this -> vars['punishes'][$_cycles_3_i]['post']): ?><a href="<?php if(isset($this -> vars['path']))echo $this -> vars['path']; ?>post<?php if(isset($_cycles_3['pid']))echo $_cycles_3['pid']; ?>/">პოსტი</a>: <?php if(isset($_cycles_3['post']))echo $_cycles_3['post']; ?><br /><?php endif; ?>
<?php if(isset($this -> vars['punishes'][$_cycles_3_i]['comment']) && (bool)$this -> vars['punishes'][$_cycles_3_i]['comment']): ?>კომენტარი: <?php if(isset($_cycles_3['comment']))echo $_cycles_3['comment']; ?><br /><?php endif; ?>
<?php if(isset($this -> vars['punishes'][$_cycles_3_i]['close_private']) && $this -> vars['punishes'][$_cycles_3_i]['close_private'] === true): ?>მომხმარებელს აკრძალული აქვს პირადი ფოსტის გამოყენება<br /><?php endif; ?>
<?php if(isset($this -> vars['punishes'][$_cycles_3_i]['manage']) && $this -> vars['punishes'][$_cycles_3_i]['manage'] === true): ?><a href="<?php if(isset($this -> vars['path']))echo $this -> vars['path']; ?>user<?php if(isset($this -> vars['user']['id']))echo $this -> vars['user']['id']; ?>/punishes/edit<?php if(isset($_cycles_3['id']))echo $_cycles_3['id']; ?>/">შეცვლა</a> <a href="<?php if(isset($this -> vars['path']))echo $this -> vars['path']; ?>user<?php if(isset($this -> vars['user']['id']))echo $this -> vars['user']['id']; ?>/punishes/del<?php if(isset($_cycles_3['id']))echo $_cycles_3['id']; ?>/">წაშლა</a><br /><?php endif; ?>
<?php if(isset($this -> vars['punishes'][$_cycles_3_i]['manage_info']) && $this -> vars['punishes'][$_cycles_3_i]['manage_info'] === true): ?><div class="manage"><?php if(isset($_cycles_3['ip']))echo $_cycles_3['ip']; ?> - <?php if(isset($_cycles_3['ua']))echo $_cycles_3['ua']; ?></div><?php endif; ?>
</div>		<?php endfor; ?>
<?php endif; ?>
<?php if(isset($this -> vars['pagebar']))echo $this -> vars['pagebar']; ?>
<?php if(!isset($this -> vars['punishes']) || !(bool)$this -> vars['punishes']): ?>
მომხმარებელს არ აქვს გაფრთხილებები.<br /><?php endif; ?>

<?php break; ?>


<?php case 'punish_edit': ?>

<form action="<?php if(isset($this -> vars['path']))echo $this -> vars['path']; ?>user<?php if(isset($this -> vars['user']['id']))echo $this -> vars['user']['id']; ?>/punishes/edit<?php if(isset($this -> vars['punish']['id']))echo $this -> vars['punish']['id']; ?>/<?php if(isset($this -> vars['rand']))echo $this -> vars['rand']; ?>/" method="post" class="unit"><input type="hidden" name="edit" value="1"/>
სასჯელი წესის მიხედვით: <br />
<select name="rule">
<option value="0">---</option>
<?php if (!empty($this -> vars['rules'])): ?>
		<?php for($_cycles_4_c = count($this -> vars['rules']), $_cycles_4_i = 0; $_cycles_4_i < $_cycles_4_c; $_cycles_4_i ++): ?>
	<?php $_cycles_4 = $this -> vars['rules'][$_cycles_4_i]; ?>

<option value="<?php if(isset($_cycles_4['id']))echo $_cycles_4['id']; ?>"<?php if(isset($_cycles_4['selected']))echo $_cycles_4['selected']; ?>><?php if(isset($_cycles_4['title']))echo $_cycles_4['title']; ?></option>		<?php endfor; ?>
<?php endif; ?>
</select><br />
ბლოკის ვადა: <br />
<input type="text" name="time1" value="<?php if(isset($this -> vars['punish']['time']))echo $this -> vars['punish']['time']; ?>" size="3" maxlength="3"/>
<select name="time2">
<option value="60"<?php if(isset($this -> vars['punish']['time_limit']) && $this -> vars['punish']['time_limit'] == 60): ?> selected="selected"<?php endif; ?>>წუთი</option>
<option value="3600"<?php if(isset($this -> vars['punish']['time_limit']) && $this -> vars['punish']['time_limit'] == 3600): ?> selected="selected"<?php endif; ?>>საათი</option>
<option value="86400"<?php if(isset($this -> vars['punish']['time_limit']) && $this -> vars['punish']['time_limit'] == 86400): ?> selected="selected"<?php endif; ?>>დღე</option>
<option value="604800"<?php if(isset($this -> vars['punish']['time_limit']) && $this -> vars['punish']['time_limit'] == 604800): ?> selected="selected"<?php endif; ?>>კვირა</option>
<option value="2592000"<?php if(isset($this -> vars['punish']['time_limit']) && $this -> vars['punish']['time_limit'] == 2592000): ?> selected="selected"<?php endif; ?>>თვე</option>
</select><br />
კომენტარი: <br />
<input type="text" name="comment" value="<?php if(isset($this -> vars['punish']['comment']))echo $this -> vars['punish']['comment']; ?>" maxlength="500"/><br />
<label><input type="checkbox" name="ban" value="1"<?php if(isset($this -> vars['punish']['ban']) && $this -> vars['punish']['ban'] === true): ?> checked="checked"<?php endif; ?>>პოსტების დაწერის და თემების შექმნის აკრძალვა</label><br />
<label><input type="checkbox" name="close_private" value="1"<?php if(isset($this -> vars['punish']['close_private']) && $this -> vars['punish']['close_private'] === true): ?> checked="checked"<?php endif; ?>>პირადი წერილების გაგზავნის და წაკითხვის აკრძალვა</label><br />
<?php if(isset($this -> vars['punish']['is_pid']) && $this -> vars['punish']['is_pid'] === true): ?><label><input type="checkbox" name="clean_pid" value="1">ბლოკირების პოსტის დამალვა პირადგვერძზე</label><br /><?php endif; ?>
<input type="submit" value="ბლოკირების შეცვლა"/>
</form>

<?php break; ?>


<?php case 'punish_del': ?>

<form action="<?php if(isset($this -> vars['path']))echo $this -> vars['path']; ?>user<?php if(isset($this -> vars['user']['id']))echo $this -> vars['user']['id']; ?>/punishes/del<?php if(isset($this -> vars['punish_id']))echo $this -> vars['punish_id']; ?>/<?php if(isset($this -> vars['rand']))echo $this -> vars['rand']; ?>/" method="post" class="unit"><input type="hidden" name="del" value="1"/>
თუ წაშლით სასჯელს<br />
მომხმარებლის რეპუტაცია აღდგება.<br />
<input type="submit" value="წაშლა"/>
</form>

<?php break; ?>


<?php case 'topics': ?>

<?php if (!empty($this -> vars['topics'])): ?>
		<?php for($_cycles_5_c = count($this -> vars['topics']), $_cycles_5_i = 0; $_cycles_5_i < $_cycles_5_c; $_cycles_5_i ++): ?>
	<?php $_cycles_5 = $this -> vars['topics'][$_cycles_5_i]; ?>

<div class="unit"><i>#<?php if(isset($_cycles_5['i']))echo $_cycles_5['i']; ?>.</i> <a href="<?php if(isset($this -> vars['path']))echo $this -> vars['path']; ?>topic<?php if(isset($_cycles_5['id']))echo $_cycles_5['id']; ?>/"><?php if(isset($_cycles_5['name']))echo $_cycles_5['name']; ?></a> (<?php if(isset($_cycles_5['count_posts']))echo $_cycles_5['count_posts']; ?>)<br />
<?php if(isset($_cycles_5['user']))echo $_cycles_5['user']; ?> / <?php if(isset($_cycles_5['date']))echo $_cycles_5['date']; ?>
</div>		<?php endfor; ?>
<?php endif; ?>
<?php if(isset($this -> vars['pagebar']))echo $this -> vars['pagebar']; ?>
<?php if(!isset($this -> vars['topics']) || !(bool)$this -> vars['topics']): ?>
მომხმარებელს არ აქვს შექმნილი არცერთი თემა.<br /><?php endif; ?>
<?php if(isset($this -> vars['topics']) && (bool)$this -> vars['topics']): ?>
<div class="menu">შექმნილი აქვს თემები: <?php if(isset($this -> vars['count_topics']))echo $this -> vars['count_topics']; ?></div><?php endif; ?>

<?php break; ?>


<?php case 'posts': ?>

<?php if (!empty($this -> vars['posts'])): ?>
		<?php for($_cycles_6_c = count($this -> vars['posts']), $_cycles_6_i = 0; $_cycles_6_i < $_cycles_6_c; $_cycles_6_i ++): ?>
	<?php $_cycles_6 = $this -> vars['posts'][$_cycles_6_i]; ?>

<div class="unit"><i>#<?php if(isset($_cycles_6['i']))echo $_cycles_6['i']; ?>.</i> <a href="<?php if(isset($this -> vars['path']))echo $this -> vars['path']; ?>topic<?php if(isset($_cycles_6['tid']))echo $_cycles_6['tid']; ?>/"><?php if(isset($_cycles_6['topic_name']))echo $_cycles_6['topic_name']; ?></a> (<?php if(isset($_cycles_6['topic_count_posts']))echo $_cycles_6['topic_count_posts']; ?>)<br />
<a href="<?php if(isset($this -> vars['path']))echo $this -> vars['path']; ?>post<?php if(isset($_cycles_6['id']))echo $_cycles_6['id']; ?>/"><?php if(isset($_cycles_6['date']))echo $_cycles_6['date']; ?></a> : <?php if(isset($_cycles_6['text']))echo $_cycles_6['text']; ?>
</div>		<?php endfor; ?>
<?php endif; ?>
<?php if(isset($this -> vars['pagebar']))echo $this -> vars['pagebar']; ?>
<?php if(!isset($this -> vars['posts']) || !(bool)$this -> vars['posts']): ?>
მომხმარებელს არ აქვს არცერთი დაწერილი პოსტი.<br /><?php endif; ?>
<?php if(isset($this -> vars['posts']) && (bool)$this -> vars['posts']): ?>
<div class="menu">დაწერილი აქვს გამოხმაურებები: <?php if(isset($this -> vars['count_posts']))echo $this -> vars['count_posts']; ?></div><?php endif; ?>

<?php break; ?>



<?php endswitch; ?>
<?php if($this -> vars['block'] != 'index'): ?>
<a href="<?php if(isset($this -> vars['path']))echo $this -> vars['path']; ?>user<?php if(isset($this -> vars['user']['id']))echo $this -> vars['user']['id']; ?>/">მომხმარებელი &quot;<?php if(isset($this -> vars['user']['nick']))echo $this -> vars['user']['nick']; ?>&quot;</a><br />
<?php endif; ?>
