<?php /* გენერირებულია 5:17:56 11.10.2020 ფაილიდან /home/f0474738/domains/forumi.eu.org/public_html/sys/tpl_compile/footer.tpl */ ?>
<?php if(!isset($this -> vars['index_page']) || $this -> vars['index_page'] !== true): ?><a href="<?php if(isset($this -> vars['path']))echo $this -> vars['path']; ?>index.php">ფორუმი</a><?php endif; ?>
<div class="foot">&copy; 2013 forumi.eu.org</div>
<?php if(isset($this -> vars['user_level']) && isset($this -> vars['user_moderator']) && $this -> vars['user_level'] >= $this -> vars['user_moderator']): ?><small>გენერაცია: <?php if(isset($this -> vars['microtime']))echo $this -> vars['microtime']; ?> წამში</small><br><?php endif; ?>
<center>
<!-- BOOM.GE COUNTER CODE START -->
<a href="http://top.boom.ge/index.php?id=61271" target="_blank"><img src="http://links.boom.ge/nojs.php?id=61271" border="0" alt="ინტერნეტთან კავშირი არაა"></a>
<!-- BOOM.GE COUNTER CODE END -->
</center>
</body>
</html>