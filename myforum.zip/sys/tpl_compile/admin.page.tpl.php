<?php /* გენერირებულია 5:57:21 11.10.2020 ფაილიდან /home/f0474738/domains/forumi.eu.org/public_html/sys/tpl_compile/admin.page.tpl */ ?>
<?php switch(isset($this -> vars['block']) ? $this -> vars['block'] : null): ?>
<?php case 'index': ?>

&raquo; <a href="<?php if(isset($this -> vars['path']))echo $this -> vars['path']; ?>admin.php?mode=set">სისტემის პარამეტრები</a><br />
&raquo; <a href="<?php if(isset($this -> vars['path']))echo $this -> vars['path']; ?>admin.php?mode=cache">მონაცემების განახლება</a><br />
&raquo; <a href="<?php if(isset($this -> vars['path']))echo $this -> vars['path']; ?>admin.php?mode=mysql">მონაცემთაბაზის მართვა</a><br />
&raquo; <a href="<?php if(isset($this -> vars['path']))echo $this -> vars['path']; ?>admin.php?mode=new_users">მომხმარებლების მოდერაცია</a> (<?php if(isset($this -> vars['count_deactive_users']))echo $this -> vars['count_deactive_users']; ?>)<br />
&raquo; <a href="<?php if(isset($this -> vars['path']))echo $this -> vars['path']; ?>admin_tpl.php">დიზაინის რედაქტირება</a><br />
&raquo; <a href="<?php if(isset($this -> vars['path']))echo $this -> vars['path']; ?>admin.php?mode=sitemap">საიტის რუკის განახლება</a><br />
<br />
რედაქტორი: მერაბი<br />
ელ. ფოსტა: admin@forumi.eu.org<br />
სკრიპტი დაწერილია სპეციალურად კოდერების კონკურსისთვის რუსეთში<br />
ჩვენი საიტი: <a href="http://forumi.eu.org">http://forumi.eu.org</a><br />

<?php break; ?>


<?php case 'set': ?>

<form action="<?php if(isset($this -> vars['path']))echo $this -> vars['path']; ?>admin.php?mode=set&save&<?php if(isset($this -> vars['rand']))echo $this -> vars['rand']; ?>" method="post"><input type="hidden" name="save" value="1"/>
ფორუმის სათაური მთავარზე: <br />
<input type="text" name="index_title" value="<?php if(isset($this -> vars['cfg']['index_title']))echo $this -> vars['cfg']['index_title']; ?>"/><br />
ფორუმის სკრიპტის მდებარეობა: <br />
<input type="text" name="path" value="<?php if(isset($this -> vars['cfg']['path']))echo $this -> vars['cfg']['path']; ?>"/><br />
დომენი (არ შეიყვანოთ არასწორი, არ გაიხსნება საიტი): <br />
<input type="text" name="domain" value="<?php if(isset($this -> vars['cfg']['domain']))echo $this -> vars['cfg']['domain']; ?>"/><br />
თემები თითო გვერძზე: <br />
<input type="text" name="onpage_topics" value="<?php if(isset($this -> vars['cfg']['onpage_topics']))echo $this -> vars['cfg']['onpage_topics']; ?>" maxlength="4" size="4"/><br />
შეტყობინებები თითო გვერძზე: <br />
<input type="text" name="onpage_posts" value="<?php if(isset($this -> vars['cfg']['onpage_posts']))echo $this -> vars['cfg']['onpage_posts']; ?>" maxlength="4" size="4"/><br />
ანტისპამი თემების შექმნისას (წამი): <br />
<input type="text" name="time_antispam_topics" value="<?php if(isset($this -> vars['cfg']['time_antispam_topics']))echo $this -> vars['cfg']['time_antispam_topics']; ?>" maxlength="6" size="6"/><br />
ანტისპამი გამოხმაურებების დაწერისას (წამი): <br />
<input type="text" name="time_antispam_posts" value="<?php if(isset($this -> vars['cfg']['time_antispam_posts']))echo $this -> vars['cfg']['time_antispam_posts']; ?>" maxlength="6" size="6"/><br />
ანტისპამი წერილების გაგზავნისას (წამი): <br />
<input type="text" name="time_antispam_private" value="<?php if(isset($this -> vars['cfg']['time_antispam_private']))echo $this -> vars['cfg']['time_antispam_private']; ?>" maxlength="6" size="6"/><br />
შეტყობინებების რედაქტირების დრო (წამი): <br />
<input type="text" name="time_edit_post" value="<?php if(isset($this -> vars['cfg']['time_edit_post']))echo $this -> vars['cfg']['time_edit_post']; ?>" size="6"/><br />
ახალი მომხმარებლების კომუნიკაციის დრო (წამი): <br />
<input type="text" name="time_silence" value="<?php if(isset($this -> vars['cfg']['time_silence']))echo $this -> vars['cfg']['time_silence']; ?>" size="6"/><br />
შეტყობინების მაქსიმალური სიგრძე: <br />
<input type="text" name="maxlen_post" value="<?php if(isset($this -> vars['cfg']['maxlen_post']))echo $this -> vars['cfg']['maxlen_post']; ?>" size="6"/><br />
შეტყობინების სავალდებულო სიგრძე: <br />
<input type="text" name="maxlen_short_post" value="<?php if(isset($this -> vars['cfg']['maxlen_short_post']))echo $this -> vars['cfg']['maxlen_short_post']; ?>" size="6"/><br />
მიმდინარე დრო: <br />
<select name="time_shift">
<?php if (!empty($this -> vars['times'])): ?>
		<?php for($_cycles_1_c = count($this -> vars['times']), $_cycles_1_i = 0; $_cycles_1_i < $_cycles_1_c; $_cycles_1_i ++): ?>
	<?php $_cycles_1 = $this -> vars['times'][$_cycles_1_i]; ?>

<option value="<?php if(isset($_cycles_1['shift']))echo $_cycles_1['shift']; ?>"<?php if(isset($_cycles_1['selected']))echo $_cycles_1['selected']; ?>><?php if(isset($_cycles_1['time']))echo $_cycles_1['time']; ?> (<?php if(isset($_cycles_1['shift']))echo $_cycles_1['shift']; ?>)</option>		<?php endfor; ?>
<?php endif; ?>
</select><br />
<br />
<label><input type="checkbox" name="users_active" value="1"<?php if(isset($this -> vars['cfg']['users_active']) && $this -> vars['cfg']['users_active'] === true): ?> checked="checked"<?php endif; ?>/>მომხმარებლების მოდერაცია</label><br />
<label><input type="checkbox" name="mod_reply_to" value="1"<?php if(isset($this -> vars['cfg']['mod_reply_to']) && $this -> vars['cfg']['mod_reply_to'] === true): ?> checked="checked"<?php endif; ?>/>გამოჩდეს "უპასუხა" პასუხზე</label><br />
<label><input type="checkbox" name="open_reg" value="1"<?php if(isset($this -> vars['cfg']['open_reg']) && $this -> vars['cfg']['open_reg'] === true): ?> checked="checked"<?php endif; ?>/>რეგისტრაცია</label><br />
<input type="submit" value="შენახვა"/>
</form>

<?php break; ?>


<?php case 'new_users': ?>

<?php if (!empty($this -> vars['users'])): ?>
		<?php for($_cycles_2_c = count($this -> vars['users']), $_cycles_2_i = 0; $_cycles_2_i < $_cycles_2_c; $_cycles_2_i ++): ?>
	<?php $_cycles_2 = $this -> vars['users'][$_cycles_2_i]; ?>

<div class="unit"><i>#<?php if(isset($_cycles_2['i']))echo $_cycles_2['i']; ?>.</i> <b><?php if(isset($_cycles_2['nick']))echo $_cycles_2['nick']; ?></b> / <?php if(isset($_cycles_2['date_reg']))echo $_cycles_2['date_reg']; ?><br />
<a href="<?php if(isset($this -> vars['path']))echo $this -> vars['path']; ?>admin.php?mode=new_users&uid=<?php if(isset($_cycles_2['id']))echo $_cycles_2['id']; ?>&act=active">აქტივაცია</a> / <a href="<?php if(isset($this -> vars['path']))echo $this -> vars['path']; ?>admin.php?mode=new_users&uid=<?php if(isset($_cycles_2['id']))echo $_cycles_2['id']; ?>&act=deactive">დეაქტივაცია</a><br />
<span class="manage"><?php if(isset($_cycles_2['ip']))echo $_cycles_2['ip']; ?> - <?php if(isset($_cycles_2['ua']))echo $_cycles_2['ua']; ?></span>
</div>		<?php endfor; ?>
<?php endif; ?>
<?php if(isset($this -> vars['pagebar']))echo $this -> vars['pagebar']; ?>
<?php if(!isset($this -> vars['users']) || !(bool)$this -> vars['users']): ?>
მომხმარებლები მოდერაციის მოლოდინში არაა.<br /><?php endif; ?>

<?php break; ?>


<?php case 'mysql': ?>

<?php if(isset($this -> vars['view_result']) && $this -> vars['view_result'] === true): ?>
<div class="code"><?php if(isset($this -> vars['view_sql']))echo $this -> vars['view_sql']; ?></div>
<?php if(isset($this -> vars['error']) && $this -> vars['error'] === true): ?>
<span class="err">შეცდომა მონაცემთაბაზაში ჩამატების შესრულებისას</span>
<div class="quote"><b>სერვერის პასუხი:</b><br /><?php if(isset($this -> vars['error_string']))echo $this -> vars['error_string']; ?></div><?php endif; ?>
<?php if(!isset($this -> vars['error']) || $this -> vars['error'] !== true): ?>
<span class="msg">წარმატებით დასრულდა მონაცემთაბაზაში ჩამატება</span><br />
<div class="quote"><b>შედეგი:</b><br /><?php if(isset($this -> vars['result']))echo $this -> vars['result']; ?></div><?php endif; ?>
<br /><?php endif; ?>
<form action="<?php if(isset($this -> vars['path']))echo $this -> vars['path']; ?>admin.php?mode=mysql&execut&<?php if(isset($this -> vars['rand']))echo $this -> vars['rand']; ?>" method="post"><input type="hidden" name="execut" value="1"/>
მონაცემთაბაზაში ჩამატება: <br />
<textarea name="query" cols="40" rows="8" wrap="off"><?php if(isset($this -> vars['sql']))echo $this -> vars['sql']; ?></textarea><br />
<label><input type="checkbox" name="view_result" value="1" checked="checked"/>შედეგების ჩვენება</label><br />
<label><input type="checkbox" name="input_query" value="1" checked="checked"/>კოდები თითო ხაზზე</label><br />
<input type="submit" name="გაშვება"/>
</form>

<?php break; ?>


<?php case 'cache': ?>

<form action="<?php if(isset($this -> vars['path']))echo $this -> vars['path']; ?>admin.php?mode=cache&update&<?php if(isset($this -> vars['rand']))echo $this -> vars['rand']; ?>" method="post"><input type="hidden" name="update" value="1"/>
<label><input type="checkbox" name="forums" value="1"/>ფორუმი (თემების რაოდენობა / პოსტები)</label><br />
<label><input type="checkbox" name="topics" value="1"/>თემები (პოსტების რაოდენობა, არასწორი ჩანაწერების წაშლა)</label><br />
<label><input type="checkbox" name="posts" value="1"/>პოსტები (არასწორი ჩანაწერების შეტყობინებები)</label><br />
<!-- <label><input type="checkbox" name="" value="1"/></label><br /> -->
<input type="submit" value="განახლება"/>
</form>

<?php break; ?>


<?php endswitch; ?>
<?php if($this -> vars['block'] != 'index'): ?>

<a href="<?php if(isset($this -> vars['path']))echo $this -> vars['path']; ?>admin.php">სამართავი პანელი</a><br />

<?php endif; ?>
