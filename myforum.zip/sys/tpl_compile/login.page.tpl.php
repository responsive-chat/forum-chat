<?php /* გენერირებულია 5:27:36 11.10.2020 ფაილიდან /home/f0474738/domains/forumi.eu.org/public_html/sys/tpl_compile/login.page.tpl */ ?>
<?php switch(isset($this -> vars['block']) ? $this -> vars['block'] : null): ?>
<?php case 'enter': ?>

<form action="<?php if(isset($this -> vars['path']))echo $this -> vars['path']; ?>login.php?mode=enter&amp;<?php if(isset($this -> vars['rand']))echo $this -> vars['rand']; ?>&amp;to=<?php if(isset($this -> vars['referer']))echo $this -> vars['referer']; ?>" method="post" class="unit"><input type="hidden" name="auth" value="1">
მეტსახელი (A-zА-яა-ჰ0-9_-): <br />
<input type="text" name="login" maxlength="40"/><br />
თქვენი პაროლი: <br />
<input type="password" name="password" maxlength="40"/><br />
თუ ჯერ არ ხართ რეგისტრირებული შეიყვანეთ სურათზე ნაჩვენები დამცავი კოდიც, რეგისტრაცია ავტომატურია.<br />
<img src="<?php if(isset($this -> vars['path']))echo $this -> vars['path']; ?>captcha.php?<?php if(isset($this -> vars['rand']))echo $this -> vars['rand']; ?>" id="captcha" alt="..."/><br />
<script>function captcha_reload(){document.getElementById('captcha').src = "<?php if(isset($this -> vars['path']))echo $this -> vars['path']; ?>captcha.php?" + Math.random();}</script>
<a href="#" onClick="javascript:captcha_reload();">განახლება</a><br />
<input type="text" name="captcha" size="4" maxlength="4"/><br />
<input type="submit" value="შესვლა"/>
</form>

<?php break; ?>
<?php endswitch; ?>