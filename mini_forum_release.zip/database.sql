-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Хост: 10.0.2.30
-- Время создания: Ноя 08 2020 г., 08:53
-- Версия сервера: 5.7.31-34
-- Версия PHP: 7.1.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `f0474738_base`
--

-- --------------------------------------------------------

--
-- Структура таблицы `mf_config`
--

CREATE TABLE `mf_config` (
  `name` varchar(100) NOT NULL,
  `value` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `mf_config`
--

INSERT INTO `mf_config` (`name`, `value`) VALUES
('path', '/'),
('salt', 'some salt 5.6.38 42 78'),
('salt_int', '7'),
('onpage_topics', '15'),
('onpage_posts', '20'),
('time_antispam_topics', '10'),
('time_antispam_posts', '3'),
('maxlen_post', '50000000000'),
('time_edit_post', '600'),
('time_shift', '0'),
('index_title', 'ფორუმი'),
('users_active', '1'),
('mod_reply_to', '1'),
('time_antispam_private', '15'),
('open_reg', '1'),
('maxlen_short_post', '40'),
('time_silence', '0'),
('domain', ''),
('date_start_forum', '1542056400');

-- --------------------------------------------------------

--
-- Структура таблицы `mf_forums`
--

CREATE TABLE `mf_forums` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `description` varchar(250) NOT NULL,
  `position` int(11) NOT NULL,
  `level` enum('0','1','2','3') NOT NULL,
  `level_topics` enum('0','1','2','3') NOT NULL,
  `count_topics` int(11) NOT NULL,
  `count_posts` int(11) NOT NULL,
  `counter_posts` tinyint(1) NOT NULL,
  `counter_topics` tinyint(1) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `mf_forums`
--

INSERT INTO `mf_forums` (`id`, `name`, `description`, `position`, `level`, `level_topics`, `count_topics`, `count_posts`, `counter_posts`, `counter_topics`) VALUES
(109, 'პოლიტიკა', 'ქართული და საერთაშორისო პოლიტიკა', 4, '0', '1', 0, 0, 1, 1),
(110, 'მეცნიერება', 'მეცნიერების განყოფილება', 3, '0', '1', 0, 0, 1, 1),
(111, 'სპორტი', 'სპორტის სხვადასხვა სახეობა', 5, '0', '1', 0, 0, 1, 1),
(113, 'უსათაურო', 'დისკუსიები ყველაფერზე', 6, '0', '1', 0, 0, 1, 1),
(114, 'ინტერნეტი', 'ყველაფერი ინტერნეტთან დაკავშირებით', 2, '0', '1', 2, 2, 1, 1),
(115, 'ადმინისტრაცია', 'ჩვენი ფორუმის შესახებ', 1, '0', '1', 1, 1, 1, 1);

-- --------------------------------------------------------

--
-- Структура таблицы `mf_posts`
--

CREATE TABLE `mf_posts` (
  `id` int(11) NOT NULL,
  `tid` int(11) NOT NULL,
  `fid` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `date` int(11) NOT NULL,
  `ip` bigint(20) NOT NULL,
  `ua` varchar(250) NOT NULL,
  `edit_count` tinyint(4) NOT NULL,
  `edit_date` int(11) NOT NULL,
  `edit_user_id` int(11) NOT NULL,
  `answer_to` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `mf_posts`
--

INSERT INTO `mf_posts` (`id`, `tid`, `fid`, `user_id`, `date`, `ip`, `ua`, `edit_count`, `edit_date`, `edit_user_id`, `answer_to`) VALUES
(54, 34, 115, 1, 1604380019, 3161614319, 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/85.0.4183.121 Safari/537.36 OPR/71.0.3770.284 (Edition Yx)', 0, 0, 0, 0),
(56, 36, 114, 1, 1604380535, 3161614320, 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/85.0.4183.121 Safari/537.36 OPR/71.0.3770.284 (Edition Yx)', 0, 0, 0, 0),
(57, 37, 114, 1, 1604380708, 3161614320, 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/85.0.4183.121 Safari/537.36 OPR/71.0.3770.284 (Edition Yx)', 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Структура таблицы `mf_posts_answers`
--

CREATE TABLE `mf_posts_answers` (
  `pid` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `answer_pid` int(11) NOT NULL,
  `answer_user` int(11) NOT NULL,
  `tid` int(11) NOT NULL,
  `date` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `mf_posts_text`
--

CREATE TABLE `mf_posts_text` (
  `pid` int(11) NOT NULL,
  `text` longtext NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `mf_posts_text`
--

INSERT INTO `mf_posts_text` (`pid`, `text`) VALUES
(54, 'ხართ ახალი, მოგესალმებით, ამ თემაში მივესალმოთ ფორუმს თუ ხართ ახალი :)'),
(56, '[url]http://radikal.ru[/url] არის საუკეთესო ფოტო ჰოსტინგი, შეგიძლიათ ატვირთოთ ნეისმიერი ზომის სურათი და დადოთ აქ ფორუმის პოსტში ან ბმულით პროფილის სურათად.'),
(57, '[url]http://mediafire.com[/url] არის საუკეთოსო ფაილ ჰოსტინგი, შეგიძლიათ ატვირთოთ ფაილები და ბმული დადოთ აქ ფორუმში თქვენი ფაილის, ფაილები ინახება სამუდამოდ და არ იშლება, ფაილის ასატვირთად ჯერ დარეგისტრირდით და შემდეგ ატვირთეთ თქვენს საქაღალდეში.');

-- --------------------------------------------------------

--
-- Структура таблицы `mf_private_contacts`
--

CREATE TABLE `mf_private_contacts` (
  `user_id` int(11) NOT NULL,
  `contact_user_id` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `mf_private_messages`
--

CREATE TABLE `mf_private_messages` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `to_user_id` int(11) NOT NULL,
  `new` enum('0','1') NOT NULL,
  `date` int(11) NOT NULL,
  `text` text NOT NULL,
  `ip` bigint(20) NOT NULL,
  `ua` varchar(250) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `mf_rules`
--

CREATE TABLE `mf_rules` (
  `id` int(11) NOT NULL,
  `cid` int(11) NOT NULL,
  `title` varchar(70) NOT NULL,
  `text` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `mf_rules`
--

INSERT INTO `mf_rules` (`id`, `cid`, `title`, `text`) VALUES
(1, 2, '#1 წესი', '1. საიტზე აკრძალულია უცენზურო სიტყვების გამოყენება და უცენზურო მეტსახელით რეგისტრაცია.'),
(2, 2, '#2 წესი', '2. აკრძალულია ღიად მომხმარებელთან ჩხუბი და დამცირება, პირადული გაარკვიეთ პირადი ფოსტით, ასევე აკრძალულია რელიგიური და რასობრივი უმცირესობების წარმომადგენლების შეურაწყოფა.'),
(3, 2, '#3 წესი', '3. დაუშვებელია პირადი საიტების ნებისმიერი ფორმით რეკლამირება ჩვენს საიტზე.'),
(4, 2, '#4 წესი', '4. აკრძალულია ერთზე მეტი მეტსახელის რეგისტრაცია და გამოყენება სხვადასხვა მიზნით.'),
(5, 2, '#5 წესი', '5. აკრძალულია ერთი და იგივე გზავნილების მრავლობითად დაგზავნა ანუ სპამი.'),
(6, 2, '#6 წესი', '6. აკრძალულია დახურული თემის ხელმეორედ გახსნა, ასევე აკრძალულია ბლოკირების შემთხვევაში ხელმეორედ რეგისტრაცია.'),
(7, 2, '#7 წესი', '7. საიტზე იკრძალება პორნოგრაფიული მასალის გამოქვეყნება ნებისმიერი ფორმით.'),
(8, 2, '#8 წესი', '8. დაუშვებელია ცრუ ინფორმაციის გავცელება, ინფორმაციას აუცილებელია დაურთოთ ინფორმაციის წყაროც.'),
(9, 2, '#9 წესი', '9. აკრძალულია სიცილაკების ჭარბი გამოყენება და უაზრო პოსტების წერა.');

-- --------------------------------------------------------

--
-- Структура таблицы `mf_rules_cats`
--

CREATE TABLE `mf_rules_cats` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `position` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `mf_rules_cats`
--

INSERT INTO `mf_rules_cats` (`id`, `name`, `position`) VALUES
(2, 'საიტის წესები', 1);

-- --------------------------------------------------------

--
-- Структура таблицы `mf_topics`
--

CREATE TABLE `mf_topics` (
  `id` int(11) NOT NULL,
  `fid` int(11) NOT NULL,
  `name` varchar(100) NOT NULL DEFAULT '',
  `user_id` int(11) NOT NULL,
  `date` int(11) NOT NULL,
  `last_user_id` int(11) NOT NULL,
  `last_date` int(11) NOT NULL,
  `first_post` int(11) NOT NULL,
  `first_post_on_pages` enum('0','1') NOT NULL COMMENT '0',
  `not_edit_author` enum('0','1') NOT NULL COMMENT '0',
  `answer_to` int(11) NOT NULL,
  `count_posts` int(11) NOT NULL,
  `open` int(11) NOT NULL,
  `top` enum('0','1') NOT NULL,
  `level` enum('0','1','2','3') NOT NULL,
  `level_posts` enum('0','1','2','3') NOT NULL,
  `count_all_views` int(11) NOT NULL,
  `count_views` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `mf_topics`
--

INSERT INTO `mf_topics` (`id`, `fid`, `name`, `user_id`, `date`, `last_user_id`, `last_date`, `first_post`, `first_post_on_pages`, `not_edit_author`, `answer_to`, `count_posts`, `open`, `top`, `level`, `level_posts`, `count_all_views`, `count_views`) VALUES
(34, 115, 'გამარჯობათ', 1, 1604380019, 0, 0, 54, '0', '0', 0, 0, 1, '1', '0', '1', 21, 12),
(36, 114, 'radikal.ru სურათების ატვირთვა', 1, 1604380535, 0, 0, 56, '0', '0', 0, 0, 1, '0', '0', '1', 9, 3),
(37, 114, 'mediafire.com ფაილების ატვირთვა', 1, 1604380708, 0, 0, 57, '0', '0', 0, 0, 1, '0', '0', '1', 10, 3);

-- --------------------------------------------------------

--
-- Структура таблицы `mf_topics_bookmarks`
--

CREATE TABLE `mf_topics_bookmarks` (
  `tid` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `date` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `mf_topics_logs`
--

CREATE TABLE `mf_topics_logs` (
  `tid` int(11) NOT NULL,
  `date` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `text` text NOT NULL,
  `ip` bigint(20) NOT NULL,
  `ua` varchar(250) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `mf_topics_logs`
--

INSERT INTO `mf_topics_logs` (`tid`, `date`, `user_id`, `text`, `ip`, `ua`) VALUES
(34, 1604380033, 1, 'მიმაგრებულია თემა', 3161614320, 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/85.0.4183.121 Safari/537.36 OPR/71.0.3770.284 (Edition Yx)');

-- --------------------------------------------------------

--
-- Структура таблицы `mf_topics_views`
--

CREATE TABLE `mf_topics_views` (
  `tid` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `date` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `mf_topics_views`
--

INSERT INTO `mf_topics_views` (`tid`, `user_id`, `date`) VALUES
(34, 1, 1604380019),
(36, 1, 1604380535),
(37, 1, 1604380708);

-- --------------------------------------------------------

--
-- Структура таблицы `mf_users`
--

CREATE TABLE `mf_users` (
  `id` int(11) NOT NULL,
  `login` varchar(40) NOT NULL,
  `nick` varchar(40) NOT NULL,
  `password` varchar(32) NOT NULL,
  `active` enum('0','1') NOT NULL DEFAULT '0',
  `level` enum('1','2','3') NOT NULL DEFAULT '1',
  `date_reg` int(11) NOT NULL,
  `date_last_visit` int(11) NOT NULL,
  `set_onpage_topics` tinyint(4) NOT NULL,
  `set_onpage_posts` tinyint(4) NOT NULL,
  `set_fast_post` enum('0','1') NOT NULL,
  `set_time_shift` tinyint(2) NOT NULL,
  `ip` bigint(20) NOT NULL,
  `ua` varchar(250) NOT NULL,
  `page` varchar(250) NOT NULL,
  `info_name` varchar(50) NOT NULL,
  `info_birthday` varchar(50) NOT NULL,
  `info_city` varchar(70) NOT NULL,
  `info_email` varchar(100) NOT NULL,
  `info_tel` varchar(50) NOT NULL,
  `info_site` varchar(50) NOT NULL,
  `info_interest` varchar(500) NOT NULL,
  `info_about` varchar(500) NOT NULL,
  `info_sex` enum('0','1') NOT NULL,
  `info_avatar` varchar(5000) NOT NULL,
  `punish_ban` enum('0','1') NOT NULL,
  `punish_pid` int(11) NOT NULL,
  `punish_to_date` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `mf_users`
--

INSERT INTO `mf_users` (`id`, `login`, `nick`, `password`, `active`, `level`, `date_reg`, `date_last_visit`, `set_onpage_topics`, `set_onpage_posts`, `set_fast_post`, `set_time_shift`, `ip`, `ua`, `page`, `info_name`, `info_birthday`, `info_city`, `info_email`, `info_tel`, `info_site`, `info_interest`, `info_about`, `info_sex`, `info_avatar`, `punish_ban`, `punish_pid`, `punish_to_date`) VALUES
(1, 'admin', 'merabi', 'f695b5bef246ee8eddf950f4ff4e755b', '1', '3', 1542090081, 1604814179, 15, 20, '0', 0, 3161613887, 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.111 Safari/537.36 OPR/72.0.3815.186 (Edition Yx)', '/index.php', 'მერაბი', '26 ივნისი 1990', 'საქართველო', '', '', 'http://forumi.eu.org', '', 'ფორუმის მფლობელი', '1', '', '0', 0, 0),
(16, 'ლაბარნა', 'ლაბარნა', '4070a61b425acc521cca7c32e33ae517', '1', '1', 1602239284, 1602240302, 15, 20, '0', 0, 2728290233, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/85.0.4183.121 Safari/537.36', '/forum84/newtopic/', '', '', '', '', '', '', '', '', '1', '', '0', 0, 0),
(17, 'teo', 'teo', '1a5113d990c099a867a53eaa2ca646f4', '1', '1', 1604082924, 1604083034, 15, 20, '0', 0, 2728302471, 'Mozilla/5.0 (iPhone; CPU iPhone OS 12_4_8 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/12.1.2 Mobile/15E148 Safari/604.1', '/umenu.php', '', '', '', '', '', '', '', '', '1', '', '0', 0, 0),
(18, 'koka9', 'koka9', 'c9530f1ff744da2d62ca62b6e291b40e', '1', '1', 1604309799, 1604310080, 15, 20, '0', 0, 2728302467, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.111 Safari/537.36', '/forum115/newtopic/', '', '', '', '', '', '', '', '', '1', '', '0', 0, 0),
(19, 'nini14', 'nini14', '2126c9a9641d8596ba9645af77067d79', '1', '1', 1604379372, 1604379397, 15, 20, '0', 0, 3161613841, 'Mozilla/5.0 (Linux; Android 7.0; SM-A710F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.106 Mobile Safari/537.36', '/index.php?mode=last_posts', '', '', '', '', '', '', '', '', '1', '', '0', 0, 0);

-- --------------------------------------------------------

--
-- Структура таблицы `mf_users_punishes`
--

CREATE TABLE `mf_users_punishes` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `punished_user_id` int(11) NOT NULL,
  `rule` int(11) NOT NULL,
  `date` int(11) NOT NULL,
  `to_date` int(11) NOT NULL,
  `comment` tinytext NOT NULL,
  `pid` int(11) NOT NULL,
  `ban` enum('0','1') NOT NULL,
  `close_private` enum('0','1') NOT NULL,
  `ip` bigint(20) NOT NULL,
  `ua` varchar(250) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `mf_config`
--
ALTER TABLE `mf_config`
  ADD PRIMARY KEY (`name`);

--
-- Индексы таблицы `mf_forums`
--
ALTER TABLE `mf_forums`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Индексы таблицы `mf_posts`
--
ALTER TABLE `mf_posts`
  ADD PRIMARY KEY (`id`),
  ADD KEY `author_id` (`user_id`),
  ADD KEY `ip` (`ip`),
  ADD KEY `date` (`date`);

--
-- Индексы таблицы `mf_posts_answers`
--
ALTER TABLE `mf_posts_answers`
  ADD PRIMARY KEY (`pid`,`answer_pid`),
  ADD KEY `pid` (`pid`);

--
-- Индексы таблицы `mf_posts_text`
--
ALTER TABLE `mf_posts_text`
  ADD PRIMARY KEY (`pid`);

--
-- Индексы таблицы `mf_private_contacts`
--
ALTER TABLE `mf_private_contacts`
  ADD PRIMARY KEY (`user_id`,`contact_user_id`);

--
-- Индексы таблицы `mf_private_messages`
--
ALTER TABLE `mf_private_messages`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `to_user_id` (`to_user_id`);

--
-- Индексы таблицы `mf_rules`
--
ALTER TABLE `mf_rules`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `mf_rules_cats`
--
ALTER TABLE `mf_rules_cats`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `mf_topics`
--
ALTER TABLE `mf_topics`
  ADD PRIMARY KEY (`id`),
  ADD KEY `author_id` (`user_id`),
  ADD KEY `fid` (`fid`);

--
-- Индексы таблицы `mf_topics_bookmarks`
--
ALTER TABLE `mf_topics_bookmarks`
  ADD PRIMARY KEY (`tid`,`user_id`);

--
-- Индексы таблицы `mf_topics_logs`
--
ALTER TABLE `mf_topics_logs`
  ADD KEY `tid` (`tid`);

--
-- Индексы таблицы `mf_topics_views`
--
ALTER TABLE `mf_topics_views`
  ADD PRIMARY KEY (`tid`,`user_id`);

--
-- Индексы таблицы `mf_users`
--
ALTER TABLE `mf_users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `login` (`login`),
  ADD UNIQUE KEY `nick` (`nick`);

--
-- Индексы таблицы `mf_users_punishes`
--
ALTER TABLE `mf_users_punishes`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `mf_forums`
--
ALTER TABLE `mf_forums`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=117;

--
-- AUTO_INCREMENT для таблицы `mf_posts`
--
ALTER TABLE `mf_posts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=81;

--
-- AUTO_INCREMENT для таблицы `mf_private_messages`
--
ALTER TABLE `mf_private_messages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT для таблицы `mf_rules`
--
ALTER TABLE `mf_rules`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT для таблицы `mf_rules_cats`
--
ALTER TABLE `mf_rules_cats`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT для таблицы `mf_topics`
--
ALTER TABLE `mf_topics`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=40;

--
-- AUTO_INCREMENT для таблицы `mf_users`
--
ALTER TABLE `mf_users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT для таблицы `mf_users_punishes`
--
ALTER TABLE `mf_users_punishes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
