<?php


	require 'sys/inc/core.php';

		switch(MODE)
	{
	default:
	case 'enter':
	
	{

	only_unreg();

	show_title('ავტორიზაცია', 'შესვლა');

	if(isset($_GET['referer']))
		{
		$to = rawurlencode($_GET['referer']);
		}

	if(isset($_POST['auth']))
		{
		check_fields(PATH.'login.php?mode=enter'.(!empty($to) ? '&referer='.rawurlencode($to) : null), array(array('login', 'not null', 'maxlen' => 40, 'minlen' => 3), array('password', 'not null', 'minlen' => 3)));

		$login = str($_POST['login'], 40);
		if(!preg_match('~^[[:space:]a-zA-Zа-яА-ЯЁёა-ჰ0-9-._]+$~u', $login))err('შეიყვანეთ მეტსახელი სწორად', PATH.'login.php?mode=enter'.(!empty($to) ? '&referer='.rawurlencode($to) : null));
		
		$password = trim($_POST['password']);
		$password_hash = get_hash($password);

		if($db -> one("SELECT COUNT(*) FROM `users` WHERE `login` = '$login'") > 0)
			{
			$user_data = $db -> fetch("SELECT `login`, `nick`, `password` FROM `users` WHERE `login` = '$login'");
			if($user_data['login'] == $login && $user_data['password'] == $password_hash)
				{
				$_SESSION['userdata'] = array('login' => $login, 'password' => $password_hash);
				xcookie('user_login', $login);
				xcookie('user_password', base64_encode(get_int_hash($password_hash)));
				msg($user_data['nick'].', თქვენ წარმატებით შემოხვედით', (isset($to) ? $to : PATH.'index.php'));
				}
			else
				{
				err('შეცდომა', PATH.'login.php?mode=enter'.(!empty($to) ? '&referer='.rawurlencode($to) : null));
				}
			}
		else
			{

			if($cfg['open_reg'] == 0)err('რეგისტრაცია შეჩერებულია', PATH.'login.php?mode=enter');

			check_captcha(PATH.'login.php?mode=enter'.(!empty($to) ? '&referer='.rawurlencode($to) : null));

			if($db -> sql("INSERT INTO `users` SET `login` = '$login', `nick` = '$login', `password` = '$password_hash', `date_reg` = '".TIME."', `level` = '1', `set_onpage_topics` = '{$cfg['onpage_topics']}', `set_onpage_posts` = '{$cfg['onpage_posts']}', `active` = '{$cfg['users_active']}', `ip` = '".MY_INT_IP."', `ua` = '".MY_UA."', `info_sex` = '1'"))
				{
				$_SESSION['userdata'] = array('login' => $login, 'password' => $password_hash);
				$user_id = $db -> last_id();
				if($user_id == 1)
					{
					$db -> sql("UPDATE `users` SET `level` = '3' WHERE `id` = '1'");
					}
				
				xcookie('user_login', $login);
				xcookie('user_password', base64_encode(get_int_hash($password_hash)));
				msg('თქვენ წარმატებით დარეგისტრირდით<br />თქვენი მონაცემები: '.$login.' - '.str($password, null, true, false), (isset($to) ? $to : PATH.'index.php'));
				}
			else
				{
				err('შეცდომა', PATH.'login.php?mode=enter'.(!empty($to) ? '&referer='.rawurlencode($to) : null));
				}

			}

		}

	$template -> block = 'enter';

	if(!empty($to))$template -> referer = rawurlencode($to);

	$_SESSION['captcha'] = rand(10,99);

	$template -> display('login.page');

	}
	break;
	
	case 'exit':
	
	{

	only_reg();

	xcookie('user_login');
	xcookie('user_password');
	unset($_SESSION['userdata']);

	msg('მალე დაგვიბრუნდით, '.(!empty($userdata['info_name']) ? $userdata['info_name'] : $userdata['nick']), PATH.'index.php');

	}
	break;
	}

show_foot();


?>