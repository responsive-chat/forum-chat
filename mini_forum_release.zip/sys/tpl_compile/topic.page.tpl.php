<?php /* გენერირებულია 4:01:23 20.12.2018 ფაილიდან /home/forumix5/public_html/sys/tpl_compile/topic.page.tpl */ ?>
<?php if(isset($this -> vars['page_zag']) && (bool)$this -> vars['page_zag']): ?><div class="menu"><?php if(isset($this -> vars['page_zag']))echo $this -> vars['page_zag']; ?></div><?php endif; ?>
<?php switch(isset($this -> vars['block']) ? $this -> vars['block'] : null): ?>
<?php case 'index': ?>

<?php if(isset($this -> vars['first_post']) && (bool)$this -> vars['first_post']): ?><div class="<?php if(isset($this -> vars['first_post']['divclass']))echo $this -> vars['first_post']['divclass']; ?>" id="post-<?php if(isset($this -> vars['first_post']['id']))echo $this -> vars['first_post']['id']; ?>"><a href="<?php if(isset($this -> vars['path']))echo $this -> vars['path']; ?>user<?php if(isset($this -> vars['first_post']['user_id']))echo $this -> vars['first_post']['user_id']; ?>/"><b><?php if(isset($this -> vars['first_post']['user']))echo $this -> vars['first_post']['user']; ?></b></a> / <?php if(isset($this -> vars['first_post']['date']))echo $this -> vars['first_post']['date']; ?><br />
<?php if(isset($this -> vars['first_post']['text']))echo $this -> vars['first_post']['text']; ?><br />
<?php if(isset($this -> vars['first_post']['answer']) && $this -> vars['first_post']['answer'] === true): ?><a href="<?php if(isset($this -> vars['path']))echo $this -> vars['path']; ?>post<?php if(isset($this -> vars['first_post']['id']))echo $this -> vars['first_post']['id']; ?>/answer/">პასუხი</a><?php endif; ?><?php if(isset($this -> vars['first_post']['manage_punish']) && $this -> vars['first_post']['manage_punish'] === true): ?> <a href="<?php if(isset($this -> vars['path']))echo $this -> vars['path']; ?>post<?php if(isset($this -> vars['first_post']['id']))echo $this -> vars['first_post']['id']; ?>/punish/">დაბლოკვა</a><?php endif; ?>
<?php if(isset($this -> vars['first_post']['manage_info']) && $this -> vars['first_post']['manage_info'] === true): ?><div class="manage"><?php if(isset($this -> vars['first_post']['ip']))echo $this -> vars['first_post']['ip']; ?> - <?php if(isset($this -> vars['first_post']['ua']))echo $this -> vars['first_post']['ua']; ?></div><?php endif; ?></div><?php endif; ?>
<?php if(isset($this -> vars['user_level']) && isset($this -> vars['user_admin']) && $this -> vars['user_level'] >= $this -> vars['user_admin']): ?><form action="<?php if(isset($this -> vars['path']))echo $this -> vars['path']; ?>topic<?php if(isset($this -> vars['topic_id']))echo $this -> vars['topic_id']; ?>/list/<?php if(isset($this -> vars['rand']))echo $this -> vars['rand']; ?>/" method="post" name="posts_form"><input type="hidden" name="list" value="1"/><?php endif; ?>
<?php if (!empty($this -> vars['posts'])): ?>
		<?php for($_cycles_1_c = count($this -> vars['posts']), $_cycles_1_i = 0; $_cycles_1_i < $_cycles_1_c; $_cycles_1_i ++): ?>
	<?php $_cycles_1 = $this -> vars['posts'][$_cycles_1_i]; ?>

<div class="<?php if(isset($_cycles_1['divclass']))echo $_cycles_1['divclass']; ?>" id="post-<?php if(isset($_cycles_1['id']))echo $_cycles_1['id']; ?>"><?php if(isset($this -> vars['user_level']) && isset($this -> vars['user_admin']) && $this -> vars['user_level'] >= $this -> vars['user_admin']): ?><label><input type="checkbox" name="posts[]" value="<?php if(isset($_cycles_1['id']))echo $_cycles_1['id']; ?>"/><?php endif; ?><i>#<?php if(isset($_cycles_1['i']))echo $_cycles_1['i']; ?>.</i><?php if(isset($this -> vars['user_level']) && isset($this -> vars['user_admin']) && $this -> vars['user_level'] >= $this -> vars['user_admin']): ?></label><?php endif; ?> <?php if(isset($_cycles_1['user']))echo $_cycles_1['user']; ?> <?php if(isset($this -> vars['posts'][$_cycles_1_i]['answer_to']) && (bool)$this -> vars['posts'][$_cycles_1_i]['answer_to']): ?><span class="sml"> / უპასუხა: <a href="<?php if(isset($this -> vars['path']))echo $this -> vars['path']; ?>post<?php if(isset($_cycles_1['answer_to']))echo $_cycles_1['answer_to']; ?>/">#<?php if(isset($_cycles_1['answer_to_post']))echo $_cycles_1['answer_to_post']; ?></a></span><?php endif; ?><br />
<?php if(isset($_cycles_1['date']))echo $_cycles_1['date']; ?><?php if(isset($this -> vars['posts'][$_cycles_1_i]['manage_edit']) && $this -> vars['posts'][$_cycles_1_i]['manage_edit'] === true): ?> <a href="<?php if(isset($this -> vars['path']))echo $this -> vars['path']; ?>post<?php if(isset($_cycles_1['id']))echo $_cycles_1['id']; ?>/edit/">შეცვლა</a><?php endif; ?><?php if(isset($this -> vars['posts'][$_cycles_1_i]['manage_punish']) && $this -> vars['posts'][$_cycles_1_i]['manage_punish'] === true): ?> <a href="<?php if(isset($this -> vars['path']))echo $this -> vars['path']; ?>post<?php if(isset($_cycles_1['id']))echo $_cycles_1['id']; ?>/punish/">დაბლოკვა</a><?php endif; ?><?php if(isset($this -> vars['posts'][$_cycles_1_i]['manage_del']) && $this -> vars['posts'][$_cycles_1_i]['manage_del'] === true): ?> <a href="<?php if(isset($this -> vars['path']))echo $this -> vars['path']; ?>post<?php if(isset($_cycles_1['id']))echo $_cycles_1['id']; ?>/del/">წაშლა</a><?php endif; ?><?php if(isset($this -> vars['posts'][$_cycles_1_i]['answer']) && $this -> vars['posts'][$_cycles_1_i]['answer'] === true): ?> <a href="<?php if(isset($this -> vars['path']))echo $this -> vars['path']; ?>post<?php if(isset($_cycles_1['id']))echo $_cycles_1['id']; ?>/answer/">პასუხი</a><?php endif; ?><br />
<?php if(isset($_cycles_1['text']))echo $_cycles_1['text']; ?><br />
<?php if(isset($this -> vars['posts'][$_cycles_1_i]['edited']) && $this -> vars['posts'][$_cycles_1_i]['edited'] === true): ?><span class="sml">რედაქტირებულია <?php if(isset($_cycles_1['edited_count']))echo $_cycles_1['edited_count']; ?>; <?php if(isset($_cycles_1['edited_user']))echo $_cycles_1['edited_user']; ?> : <?php if(isset($_cycles_1['edited_date']))echo $_cycles_1['edited_date']; ?></span><br /><?php endif; ?>
<?php if(isset($this -> vars['posts'][$_cycles_1_i]['manage_info']) && $this -> vars['posts'][$_cycles_1_i]['manage_info'] === true): ?><div class="manage"><?php if(isset($_cycles_1['ip']))echo $_cycles_1['ip']; ?> - <?php if(isset($_cycles_1['ua']))echo $_cycles_1['ua']; ?></div><?php endif; ?></div>		<?php endfor; ?>
<?php endif; ?>
<?php if(isset($this -> vars['user_level']) && isset($this -> vars['user_admin']) && $this -> vars['user_level'] >= $this -> vars['user_admin']): ?><?php if(isset($this -> vars['posts']) && (bool)$this -> vars['posts']): ?><script type="text/javascript">function allcheck(checked){for(var i=0;i<document.forms['posts_form'].elements['posts[]'].length;i++){document.forms['posts_form'].elements['posts[]'][i].checked = checked;}}</script>
<input type="submit" name="delete" value="წაშლა"/> <input type="submit" name="trans" value="გადატანა"/><?php endif; ?>
</form><?php endif; ?>
<?php if(isset($this -> vars['pagebar']))echo $this -> vars['pagebar']; ?>
<div class="menu"><?php if(isset($this -> vars['user_level']) && isset($this -> vars['user_admin']) && $this -> vars['user_level'] >= $this -> vars['user_admin']): ?><?php if(isset($this -> vars['posts']) && (bool)$this -> vars['posts']): ?><input type="checkbox" onclick="javascript:allcheck(this.checked);"/><?php endif; ?><?php endif; ?>გამოხმაურებები: <?php if(isset($this -> vars['count_posts']))echo $this -> vars['count_posts']; ?></div>
<?php if(isset($this -> vars['topic_level']) && $this -> vars['topic_level'] != 0): ?><div class="menu">თემაზე წვდომა ნებადართულია: <?php if(isset($this -> vars['topic_level']) && $this -> vars['topic_level'] == 1): ?>მომხმარებლებისთვის<?php endif; ?><?php if(isset($this -> vars['topic_level']) && $this -> vars['topic_level'] == 2): ?>მოდერატორებისთვის<?php endif; ?><?php if(isset($this -> vars['topic_level']) && $this -> vars['topic_level'] == 3): ?>ადმინისტრატორებისთვის<?php endif; ?></div><?php endif; ?>
<?php if(isset($this -> vars['topic_level_posts']) && $this -> vars['topic_level_posts'] != 0): ?><div class="menu">გამოხმაურების დაწერა შეუძლიათ: <?php if(isset($this -> vars['topic_level_posts']) && $this -> vars['topic_level_posts'] == 1): ?>მომხმარებლებს<?php endif; ?><?php if(isset($this -> vars['topic_level_posts']) && $this -> vars['topic_level_posts'] == 2): ?>მოდერატორებს<?php endif; ?><?php if(isset($this -> vars['topic_level_posts']) && $this -> vars['topic_level_posts'] == 3): ?>ადმინისტრატორებს<?php endif; ?></div><?php endif; ?>

<?php if(!isset($this -> vars['topic_open']) || $this -> vars['topic_open'] !== true): ?><span class="err">თემა დახურულია</span><br /><?php endif; ?>
<?php if(isset($this -> vars['ban']) && $this -> vars['ban'] === true): ?><span class="err">თქვენ დაბლოკილი ხართ და არ შეგიძლიათ გამოხმაურების დაწერა.</span><br /><?php endif; ?>
<?php if(isset($this -> vars['cannot_post']) && $this -> vars['cannot_post'] === true): ?><span class="err">თქვენ არ შეგიძლიათ გამოხმაურების დაწერა ამ თემაში.</span><br /><?php endif; ?>
<?php if(isset($this -> vars['fast_post']) && $this -> vars['fast_post'] === true): ?><form action="<?php if(isset($this -> vars['path']))echo $this -> vars['path']; ?>topic<?php if(isset($this -> vars['topic_id']))echo $this -> vars['topic_id']; ?>/newpost/<?php if(isset($this -> vars['rand']))echo $this -> vars['rand']; ?>/" method="post" class="unit"><input type="hidden" name="create" value="1"/>
გამოხმაურება: <br />
<textarea name="post" cols="30" rows="10" onkeypress="return makeGeo(this,event);"></textarea><br />
<input type="submit" value="დამატება"/>
<input checked="checked" id="geoKeys" type="checkbox" /><b>ქართული კლავიატურა</b><br>
</form><?php endif; ?>
<?php if(!isset($this -> vars['fast_post']) || $this -> vars['fast_post'] !== true): ?>
&raquo; <a href="<?php if(isset($this -> vars['path']))echo $this -> vars['path']; ?>topic<?php if(isset($this -> vars['topic_id']))echo $this -> vars['topic_id']; ?>/newpost/<?php if(isset($this -> vars['rand']))echo $this -> vars['rand']; ?>/"><b>პასუხის დაწერა</b></a><br /><?php endif; ?>
<?php if(isset($this -> vars['user_auth']) && $this -> vars['user_auth'] === true): ?>&raquo; <a href="<?php if(isset($this -> vars['path']))echo $this -> vars['path']; ?>topic<?php if(isset($this -> vars['topic_id']))echo $this -> vars['topic_id']; ?>/bookmark/<?php if(isset($this -> vars['rand']))echo $this -> vars['rand']; ?>/"><?php if(isset($this -> vars['topic_bookmark']) && $this -> vars['topic_bookmark'] === true): ?>ჩანიშნულიდან წაშლა<?php endif; ?><?php if(!isset($this -> vars['topic_bookmark']) || $this -> vars['topic_bookmark'] !== true): ?>ჩანიშვნა<?php endif; ?></a><br /><?php endif; ?>
<?php if(isset($this -> vars['manage_topic']['info']) && $this -> vars['manage_topic']['info'] === true): ?>&raquo; <a href="<?php if(isset($this -> vars['path']))echo $this -> vars['path']; ?>topic<?php if(isset($this -> vars['topic_id']))echo $this -> vars['topic_id']; ?>/info/">ინფორმაცია</a><br /><?php endif; ?>
<?php if(isset($this -> vars['manage_topic']['edit']) && $this -> vars['manage_topic']['edit'] === true): ?>&raquo; <a href="<?php if(isset($this -> vars['path']))echo $this -> vars['path']; ?>topic<?php if(isset($this -> vars['topic_id']))echo $this -> vars['topic_id']; ?>/edit/">თემის რედაქტირება</a><br /><?php endif; ?>
<?php if(isset($this -> vars['manage_topic']['logs']) && $this -> vars['manage_topic']['logs'] === true): ?>&raquo; <a href="<?php if(isset($this -> vars['path']))echo $this -> vars['path']; ?>topic<?php if(isset($this -> vars['topic_id']))echo $this -> vars['topic_id']; ?>/logs/">თემის ისტორია</a> (<?php if(isset($this -> vars['manage_topic']['count_logs']))echo $this -> vars['manage_topic']['count_logs']; ?>)<br /><?php endif; ?>
<?php if(isset($this -> vars['manage_topic']['trans']) && $this -> vars['manage_topic']['trans'] === true): ?>&raquo; <a href="<?php if(isset($this -> vars['path']))echo $this -> vars['path']; ?>topic<?php if(isset($this -> vars['topic_id']))echo $this -> vars['topic_id']; ?>/trans/">თემის გადატანა</a><br /><?php endif; ?>
<?php if(isset($this -> vars['manage_topic']['del']) && $this -> vars['manage_topic']['del'] === true): ?>&raquo; <a href="<?php if(isset($this -> vars['path']))echo $this -> vars['path']; ?>topic<?php if(isset($this -> vars['topic_id']))echo $this -> vars['topic_id']; ?>/del/">თემის წაშლა</a><br /><?php endif; ?>

<?php break; ?>


<?php case 'newpost': ?>

<form action="<?php if(isset($this -> vars['path']))echo $this -> vars['path']; ?>topic<?php if(isset($this -> vars['topic_id']))echo $this -> vars['topic_id']; ?>/newpost/<?php if(isset($this -> vars['rand']))echo $this -> vars['rand']; ?>/" method="post" class="unit"><input type="hidden" name="create" value="1"/>
გამოხმაურება: <br />
<textarea name="post" cols="40" rows="8" wrap="off "onkeypress="return makeGeo(this,event);"></textarea><br />
<?php if(isset($this -> vars['recycled']) && $this -> vars['recycled'] === true): ?>
<label><input type="checkbox" name="recycled" value="1"/>თემის დახურვა და სანაგვეში გადატანა</label><br /><?php endif; ?>
<input type="submit" value="დამატება"/>
<input checked="checked" id="geoKeys" type="checkbox" /><b>ქართული კლავიატურა</b><br>
</form>
&raquo; <a href="<?php if(isset($this -> vars['path']))echo $this -> vars['path']; ?>index.php?mode=bbcodes">BB კოდები</a><br />
&raquo; <a href="<?php if(isset($this -> vars['path']))echo $this -> vars['path']; ?>index.php?mode=smiles">სიცილაკები</a><br />

<?php break; ?>


<?php case 'list_delete': ?>

<form action="<?php if(isset($this -> vars['path']))echo $this -> vars['path']; ?>topic<?php if(isset($this -> vars['topic_id']))echo $this -> vars['topic_id']; ?>/list/<?php if(isset($this -> vars['rand']))echo $this -> vars['rand']; ?>/" method="post"><input type="hidden" name="list" value="1"/><input type="hidden" name="yes" value="1"/>
<?php if (!empty($this -> vars['posts'])): ?>
		<?php for($_cycles_2_c = count($this -> vars['posts']), $_cycles_2_i = 0; $_cycles_2_i < $_cycles_2_c; $_cycles_2_i ++): ?>
	<?php $_cycles_2 = $this -> vars['posts'][$_cycles_2_i]; ?>

<input type="hidden" name="posts[]" value="<?php if(isset($_cycles_2['id']))echo $_cycles_2['id']; ?>"/>		<?php endfor; ?>
<?php endif; ?>
წაშლა <?php if(isset($this -> vars['count_posts']))echo $this -> vars['count_posts']; ?> <?php if(isset($this -> vars['postfix']))echo $this -> vars['postfix']; ?><br />
<input type="submit" name="delete" value="წაშლა"/>
</form>

<?php break; ?>


<?php case 'list_trans': ?>

<form action="<?php if(isset($this -> vars['path']))echo $this -> vars['path']; ?>topic<?php if(isset($this -> vars['topic_id']))echo $this -> vars['topic_id']; ?>/list/<?php if(isset($this -> vars['rand']))echo $this -> vars['rand']; ?>/" method="post"><input type="hidden" name="list" value="1"/><input type="hidden" name="yes" value="1"/>
<?php if (!empty($this -> vars['posts'])): ?>
		<?php for($_cycles_3_c = count($this -> vars['posts']), $_cycles_3_i = 0; $_cycles_3_i < $_cycles_3_c; $_cycles_3_i ++): ?>
	<?php $_cycles_3 = $this -> vars['posts'][$_cycles_3_i]; ?>

<input type="hidden" name="posts[]" value="<?php if(isset($_cycles_3['id']))echo $_cycles_3['id']; ?>"/>		<?php endfor; ?>
<?php endif; ?>
გადატანა <?php if(isset($this -> vars['count_posts']))echo $this -> vars['count_posts']; ?> <?php if(isset($this -> vars['postfix']))echo $this -> vars['postfix']; ?><br />
<label><input type="radio" name="create" value="1" checked="checked"/>ახალი თემის გახსნა</label><br />
განყოფილება: <br />
<select name="into_forum">
<?php if (!empty($this -> vars['forums'])): ?>
		<?php for($_cycles_4_c = count($this -> vars['forums']), $_cycles_4_i = 0; $_cycles_4_i < $_cycles_4_c; $_cycles_4_i ++): ?>
	<?php $_cycles_4 = $this -> vars['forums'][$_cycles_4_i]; ?>

<option value="<?php if(isset($_cycles_4['id']))echo $_cycles_4['id']; ?>"><?php if(isset($_cycles_4['name']))echo $_cycles_4['name']; ?></option>		<?php endfor; ?>
<?php endif; ?>
</select><br />
თემის სათაური: <br />
<input type="text" name="topic_name" maxlength="100"><br />
<label><input type="radio" name="create" value="0"/>გადატანა უკვე არსებულ თემაში</label><br />
თემის ნომერი: <br />
<input type="text" name="into_topic" size="11"/><br />
<input type="submit" name="trans" value="გადატანა"/>
</form>

<?php break; ?>


<?php case 'edit': ?>

<form action="<?php if(isset($this -> vars['path']))echo $this -> vars['path']; ?>topic<?php if(isset($this -> vars['topic_id']))echo $this -> vars['topic_id']; ?>/edit/<?php if(isset($this -> vars['rand']))echo $this -> vars['rand']; ?>/" method="post" class="unit"><input type="hidden" name="edit" value="1"/>
თემა: <br />
<input type="text" name="topic_name" value="<?php if(isset($this -> vars['topic_name']))echo $this -> vars['topic_name']; ?>" maxlength="100"><br />
<?php if(!isset($this -> vars['first_post']) || !(bool)$this -> vars['first_post']): ?>პირველი გამოხმაურება არ არის დაყენებული, ის ავტომატურად შეიქმნება.<br /><?php endif; ?>
გამოხმაურება: <br />
<textarea name="topic_post" cols="20" rows="5"><?php if(isset($this -> vars['first_post']))echo $this -> vars['first_post']; ?></textarea><br />
<label><input type="checkbox" name="first_post_on_pages" value="1"<?php if(isset($this -> vars['first_post_on_pages']) && $this -> vars['first_post_on_pages'] === true): ?> checked="checked"<?php endif; ?>/>გამოხმაურების ყველა გვერძზე ჩვენება</label><br />
<?php if(isset($this -> vars['manage']) && $this -> vars['manage'] === true): ?>
თემაზე წვდომის უფლება აქვთ: <br />
<select name="level">
<option value="0"<?php if(isset($this -> vars['level']) && $this -> vars['level'] == 0): ?> selected="selected"<?php endif; ?>>ყველას</option>
<option value="1"<?php if(isset($this -> vars['level']) && $this -> vars['level'] == 1): ?> selected="selected"<?php endif; ?>>მომხმარებლებს</option>
<option value="2"<?php if(isset($this -> vars['level']) && $this -> vars['level'] == 2): ?> selected="selected"<?php endif; ?>>მოდერატორებს</option>
<option value="3"<?php if(isset($this -> vars['level']) && $this -> vars['level'] == 3): ?> selected="selected"<?php endif; ?>>ადმინისტრატორებს</option>
</select><br />
გამოხმაურების დაწერა შეუძლიათ: <br />
<select name="level_posts">
<option value="0"<?php if(isset($this -> vars['level_posts']) && $this -> vars['level_posts'] == 0): ?> selected="selected"<?php endif; ?>>ყველას</option>
<option value="1"<?php if(isset($this -> vars['level_posts']) && $this -> vars['level_posts'] == 1): ?> selected="selected"<?php endif; ?>>მომხმარებლებს</option>
<option value="2"<?php if(isset($this -> vars['level_posts']) && $this -> vars['level_posts'] == 2): ?> selected="selected"<?php endif; ?>>მოდერატორებს</option>
<option value="3"<?php if(isset($this -> vars['level_posts']) && $this -> vars['level_posts'] == 3): ?> selected="selected"<?php endif; ?>>ადმინისტრატორებს</option>
</select><br />
<?php if(isset($this -> vars['user_id']) && isset($this -> vars['author_id']) && $this -> vars['user_id'] != $this -> vars['author_id']): ?><label><input type="checkbox" name="not_edit_author" value="1"<?php if(isset($this -> vars['not_edit_author']) && $this -> vars['not_edit_author'] === true): ?> checked="checked"<?php endif; ?>/>აეკრძალოს ავტორს თემის რედაქტირება</label><br /><?php endif; ?>
<label><input type="checkbox" name="open" value="1"<?php if(isset($this -> vars['open']) && $this -> vars['open'] === true): ?> checked="checked"<?php endif; ?>/>თემა გახსნილია</label><br />
<label><input type="checkbox" name="top" value="1"<?php if(isset($this -> vars['top']) && $this -> vars['top'] === true): ?> checked="checked"<?php endif; ?>/>თემა მნიშვნელოვანია</label><br /><?php endif; ?>
<input type="submit" value="შეცვლა"/>
</form>

<?php break; ?>


<?php case 'del': ?>

<form action="<?php if(isset($this -> vars['path']))echo $this -> vars['path']; ?>topic<?php if(isset($this -> vars['topic_id']))echo $this -> vars['topic_id']; ?>/del/<?php if(isset($this -> vars['rand']))echo $this -> vars['rand']; ?>/" method="post" class="unit"><input type="hidden" name="del" value="1">
ყველა გამოხმაურება წაიშლება.<br />
<input type="submit" value="თემის წაშლა"/>
</form>

<?php break; ?>


<?php case 'trans': ?>

<form action="<?php if(isset($this -> vars['path']))echo $this -> vars['path']; ?>topic<?php if(isset($this -> vars['topic_id']))echo $this -> vars['topic_id']; ?>/trans/<?php if(isset($this -> vars['rand']))echo $this -> vars['rand']; ?>/" method="post"><input type="hidden" name="yes" value="1"/>
გადატანა განყოფილებაში: <br />
<select name="into_forum">
<?php if (!empty($this -> vars['forums'])): ?>
		<?php for($_cycles_5_c = count($this -> vars['forums']), $_cycles_5_i = 0; $_cycles_5_i < $_cycles_5_c; $_cycles_5_i ++): ?>
	<?php $_cycles_5 = $this -> vars['forums'][$_cycles_5_i]; ?>

<option value="<?php if(isset($_cycles_5['id']))echo $_cycles_5['id']; ?>"><?php if(isset($_cycles_5['name']))echo $_cycles_5['name']; ?></option>		<?php endfor; ?>
<?php endif; ?>
</select><br />
<input type="submit" name="trans" value="გადატანა"/>
</form>

<?php break; ?>


<?php case 'logs': ?>

<?php if (!empty($this -> vars['logs'])): ?>
		<?php for($_cycles_6_c = count($this -> vars['logs']), $_cycles_6_i = 0; $_cycles_6_i < $_cycles_6_c; $_cycles_6_i ++): ?>
	<?php $_cycles_6 = $this -> vars['logs'][$_cycles_6_i]; ?>

<div class="unit"><i>#<?php if(isset($_cycles_6['i']))echo $_cycles_6['i']; ?>.</i> <a href="<?php if(isset($this -> vars['path']))echo $this -> vars['path']; ?>user<?php if(isset($_cycles_6['user_id']))echo $_cycles_6['user_id']; ?>/"><?php if(isset($_cycles_6['user']))echo $_cycles_6['user']; ?></a> / <?php if(isset($_cycles_6['date']))echo $_cycles_6['date']; ?><br />
<?php if(isset($_cycles_6['text']))echo $_cycles_6['text']; ?><br />
<span class="manage"><?php if(isset($_cycles_6['ip']))echo $_cycles_6['ip']; ?> - <?php if(isset($_cycles_6['ua']))echo $_cycles_6['ua']; ?></span></div>		<?php endfor; ?>
<?php endif; ?>
<?php if(!isset($this -> vars['logs']) || !(bool)$this -> vars['logs']): ?>ისტორია არაა<br /><?php endif; ?>
<?php if(isset($this -> vars['pagebar']))echo $this -> vars['pagebar']; ?>

<?php break; ?>


<?php case 'info': ?>

ნანახია თემა სულ: <?php if(isset($this -> vars['count_all_views']))echo $this -> vars['count_all_views']; ?>, მხოლოდ ავტორიზებულებმა: <?php if(isset($this -> vars['count_views']))echo $this -> vars['count_views']; ?> (<?php if(isset($this -> vars['count_views_percent']))echo $this -> vars['count_views_percent']; ?>%)<br />
თემის უნიკალური მკითხველი: <?php if(isset($this -> vars['count_uniq_views']))echo $this -> vars['count_uniq_views']; ?>, მთლიანად წაიკითხეს თემა: <?php if(isset($this -> vars['count_uniq_all_views']))echo $this -> vars['count_uniq_all_views']; ?> (<?php if(isset($this -> vars['count_uniq_percent']))echo $this -> vars['count_uniq_percent']; ?>%)<br />
<?php if(isset($this -> vars['count_bookmarks']) && (bool)$this -> vars['count_bookmarks']): ?>თემა ჩაინიშნა <?php if(isset($this -> vars['count_bookmarks']))echo $this -> vars['count_bookmarks']; ?><?php endif; ?><br />
&raquo; <a href="<?php if(isset($this -> vars['path']))echo $this -> vars['path']; ?>topic<?php if(isset($this -> vars['topic_id']))echo $this -> vars['topic_id']; ?>/rss/">თემის RSS ლენტა</a><br />
<input type="text" value="http://<?php if(isset($this -> vars['domain']))echo $this -> vars['domain']; ?><?php if(isset($this -> vars['path']))echo $this -> vars['path']; ?>topic<?php if(isset($this -> vars['topic_id']))echo $this -> vars['topic_id']; ?>/rss/"/><br />
&raquo; <a href="<?php if(isset($this -> vars['path']))echo $this -> vars['path']; ?>topic<?php if(isset($this -> vars['topic_id']))echo $this -> vars['topic_id']; ?>/txt/">თემის შენახვა TXT ფორმატში</a><br />
<input type="text" value="http://<?php if(isset($this -> vars['domain']))echo $this -> vars['domain']; ?><?php if(isset($this -> vars['path']))echo $this -> vars['path']; ?>topic<?php if(isset($this -> vars['topic_id']))echo $this -> vars['topic_id']; ?>/txt/"/><br />
<br />

<?php break; ?>


<?php endswitch; ?>
<?php if($this -> vars['block'] != 'index'): ?>
<a href="<?php if(isset($this -> vars['path']))echo $this -> vars['path']; ?>topic<?php if(isset($this -> vars['topic_id']))echo $this -> vars['topic_id']; ?>/">თემა &quot;<?php if(isset($this -> vars['topic_name']))echo $this -> vars['topic_name']; ?>&quot;</a><br />
<?php endif; ?>
<a href="<?php if(isset($this -> vars['path']))echo $this -> vars['path']; ?>forum<?php if(isset($this -> vars['forum_id']))echo $this -> vars['forum_id']; ?>/">განყოფილება &quot;<?php if(isset($this -> vars['forum_name']))echo $this -> vars['forum_name']; ?>&quot;</a><br />