<?php /* გენერირებულია 9:26:20 08.11.2020 ფაილიდან /home/f0474738/domains/forumi.eu.org/public_html/sys/tpl_compile/index.page.tpl */ ?>
<?php switch(isset($this -> vars['block']) ? $this -> vars['block'] : null): ?>
<?php case 'index': ?>

<?php if (!empty($this -> vars['forums'])): ?>
		<?php for($_cycles_1_c = count($this -> vars['forums']), $_cycles_1_i = 0; $_cycles_1_i < $_cycles_1_c; $_cycles_1_i ++): ?>
	<?php $_cycles_1 = $this -> vars['forums'][$_cycles_1_i]; ?>

<div class="unit">&raquo; <a href="<?php if(isset($this -> vars['path']))echo $this -> vars['path']; ?>forum<?php if(isset($_cycles_1['id']))echo $_cycles_1['id']; ?>/"><?php if(isset($_cycles_1['name']))echo $_cycles_1['name']; ?></a>(<?php if(isset($_cycles_1['count_topics']))echo $_cycles_1['count_topics']; ?> / <?php if(isset($_cycles_1['count_posts']))echo $_cycles_1['count_posts']; ?>)<?php if(isset($this -> vars['forums'][$_cycles_1_i]['managment_up']) && $this -> vars['forums'][$_cycles_1_i]['managment_up'] === true): ?> <a href="<?php if(isset($this -> vars['path']))echo $this -> vars['path']; ?>index.php?position_forum=<?php if(isset($_cycles_1['id']))echo $_cycles_1['id']; ?>&mode=up">მაღლა</a><?php endif; ?><?php if(isset($this -> vars['forums'][$_cycles_1_i]['managment_down']) && $this -> vars['forums'][$_cycles_1_i]['managment_down'] === true): ?> <a href="<?php if(isset($this -> vars['path']))echo $this -> vars['path']; ?>index.php?position_forum=<?php if(isset($_cycles_1['id']))echo $_cycles_1['id']; ?>&mode=down">დაბლა</a><?php endif; ?><br />
<?php if(isset($_cycles_1['description']))echo $_cycles_1['description']; ?></div>		<?php endfor; ?>
<?php endif; ?>
<?php if(isset($this -> vars['need_re_position']) && $this -> vars['need_re_position'] === true): ?>
<span class="err">საჭიროა განყოფილებების პოზიციების განახლება.<br /> <a href="<?php if(isset($this -> vars['path']))echo $this -> vars['path']; ?>index.php?re_position&<?php if(isset($this -> vars['rand']))echo $this -> vars['rand']; ?>">გააკეთეთ ეს</a></span><br /><?php endif; ?>
<?php if(!isset($this -> vars['forums']) || !(bool)$this -> vars['forums']): ?>
განყოფილებები არაა შექმნილი<br /><?php endif; ?>
<?php if(isset($this -> vars['user_level']) && isset($this -> vars['user_admin']) && $this -> vars['user_level'] >= $this -> vars['user_admin']): ?>
<form action="<?php if(isset($this -> vars['path']))echo $this -> vars['path']; ?>index.php?addforum&amp;<?php if(isset($this -> vars['rand']))echo $this -> vars['rand']; ?>" method="post" class="unit">
განყოფილება: <br />
<input type="text" name="forum_name" maxlength="50"/><br /><input type="submit" value="განყოფილების შექმნა"/>
</form><?php endif; ?>
<hr class="delimiter">
<a href="<?php if(isset($this -> vars['path']))echo $this -> vars['path']; ?>index.php?mode=rules">წესები</a> / <a href="<?php if(isset($this -> vars['path']))echo $this -> vars['path']; ?>index.php?mode=search">ძებნა</a><br />
ბოლო <a href="<?php if(isset($this -> vars['path']))echo $this -> vars['path']; ?>index.php?mode=last_topics">თემები</a> / <a href="<?php if(isset($this -> vars['path']))echo $this -> vars['path']; ?>index.php?mode=last_posts">პოსტები</a><br />
<?php if(!isset($this -> vars['user_auth']) || $this -> vars['user_auth'] !== true): ?>
&bull; <a href="<?php if(isset($this -> vars['path']))echo $this -> vars['path']; ?>login.php?mode=enter">შესვლა / რეგისტრაცია</a><br /><?php endif; ?>
<?php if(isset($this -> vars['user_auth']) && $this -> vars['user_auth'] === true): ?>
&bull; <a href="<?php if(isset($this -> vars['path']))echo $this -> vars['path']; ?>login.php?mode=exit">გასვლა</a><br /><?php endif; ?>
&bull; ამჟამად საიტზეა: <?php if(isset($this -> vars['count_online_users']))echo $this -> vars['count_online_users']; ?><br />
&bull; სულ გამოხმაურებები: <a href="<?php if(isset($this -> vars['path']))echo $this -> vars['path']; ?>index.php?mode=stat"><?php if(isset($this -> vars['count_all_posts']))echo $this -> vars['count_all_posts']; ?></a><br />
&bull; სულ წევრები: <a href="<?php if(isset($this -> vars['path']))echo $this -> vars['path']; ?>index.php?mode=users"><?php if(isset($this -> vars['count_all_users']))echo $this -> vars['count_all_users']; ?></a><br />
</div>

<?php break; ?>


<?php case 'stat': ?>

სულ გამოხმაურებები: <b><?php if(isset($this -> vars['all_posts']))echo $this -> vars['all_posts']; ?></b>, დღეს: <b><?php if(isset($this -> vars['today_posts']))echo $this -> vars['today_posts']; ?></b><br />
პოსტები დღეს: <b><?php if(isset($this -> vars['posts_on_day']))echo $this -> vars['posts_on_day']; ?></b><br />
სულ თემატური პოსტები: <b><?php if(isset($this -> vars['usefull_posts']))echo $this -> vars['usefull_posts']; ?></b>, საერთო ჯამში: <b><?php if(isset($this -> vars['all_usefull_posts']))echo $this -> vars['all_usefull_posts']; ?>%</b><br />
სულ თემები: <b><?php if(isset($this -> vars['all_topics']))echo $this -> vars['all_topics']; ?></b>, თემები დღეს: <b><?php if(isset($this -> vars['today_topics']))echo $this -> vars['today_topics']; ?></b><br />
სულ წევრები: <b><?php if(isset($this -> vars['all_users']))echo $this -> vars['all_users']; ?></b>, დღეს ახალი: <b><?php if(isset($this -> vars['today_users_reg']))echo $this -> vars['today_users_reg']; ?></b><br />
დღეს შემოვიდნენ ფორუმში: <b><?php if(isset($this -> vars['today_users_visit']))echo $this -> vars['today_users_visit']; ?></b><br />
საშუალოდ წევრებმა შექმნეს თემები: <b><?php if(isset($this -> vars['users_topics']))echo $this -> vars['users_topics']; ?></b>, დაწერეს პოსტები: <b><?php if(isset($this -> vars['users_posts']))echo $this -> vars['users_posts']; ?></b><br />

<?php break; ?>


<?php case 'deactive': ?>

თქვენი ანგარიში გამორთულია.<br />
<?php if(isset($this -> vars['user_new']) && $this -> vars['user_new'] === true): ?>თქვენ წარმატებით დარეგისტრირდით, ადმინისტრაცია შეამოწმებს თქვენს მეტსახელს და გაგიაქტიურებთ პროფილს.<br /><?php endif; ?>
<a href="<?php if(isset($this -> vars['path']))echo $this -> vars['path']; ?>login.php?mode=exit">გასვლა</a><br />

<?php break; ?>


<?php case 'users': ?>

<?php if(isset($this -> vars['count_users']) && (bool)$this -> vars['count_users']): ?>
<form action="<?php if(isset($this -> vars['path']))echo $this -> vars['path']; ?>index.php" method="get"><input type="hidden" name="mode" value="users"/><input type="hidden" name="rand" value="<?php if(isset($this -> vars['rand']))echo $this -> vars['rand']; ?>"/>
ჩამონათვალის დალაგება: <br />
<select name="sort">
<option value="nick"<?php if(isset($this -> vars['sort_field']) && $this -> vars['sort_field'] == 'nick'): ?> selected="selected"<?php endif; ?>>მეტსახელის მიხედვით</option>
<option value="level"<?php if(isset($this -> vars['sort_field']) && $this -> vars['sort_field'] == 'level'): ?> selected="selected"<?php endif; ?>>სტატუსის მიხედვით</option>
<option value="date_reg"<?php if(isset($this -> vars['sort_field']) && $this -> vars['sort_field'] == 'date_reg'): ?> selected="selected"<?php endif; ?>>რეგისტრაციის თარიღის მიხედვით</option>
<option value="date_last_visit"<?php if(isset($this -> vars['sort_field']) && $this -> vars['sort_field'] == 'date_last_visit'): ?> selected="selected"<?php endif; ?>>ავტორიზაციის თარიღის მიხედვით</option>
<option value="info_name"<?php if(isset($this -> vars['sort_field']) && $this -> vars['sort_field'] == 'info_name'): ?> selected="selected"<?php endif; ?>>ნამდვილი სახელის მიხედვით</option>
<option value="info_city"<?php if(isset($this -> vars['sort_field']) && $this -> vars['sort_field'] == 'info_city'): ?> selected="selected"<?php endif; ?>>მდებარეობის მიხედვით</option>
<option value="info_sex"<?php if(isset($this -> vars['sort_field']) && $this -> vars['sort_field'] == 'info_sex'): ?> selected="selected"<?php endif; ?>>სქესის მიხედვით დალაგება</option>
</select><br />
<label><input type="checkbox" name="desc" value="1"<?php if(isset($this -> vars['sort_order']) && $this -> vars['sort_order'] == 'DESC'): ?> checked="checked"<?php endif; ?>/>საპირისპიროდ დალაგება</label><br />
<input type="submit" value="დალაგება"/><br />
</form>
<hr/>
<?php if (!empty($this -> vars['users'])): ?>
		<?php for($_cycles_2_c = count($this -> vars['users']), $_cycles_2_i = 0; $_cycles_2_i < $_cycles_2_c; $_cycles_2_i ++): ?>
	<?php $_cycles_2 = $this -> vars['users'][$_cycles_2_i]; ?>

<div class="unit"><i>#<?php if(isset($_cycles_2['i']))echo $_cycles_2['i']; ?>.</i> <b><?php if(isset($_cycles_2['nick']))echo $_cycles_2['nick']; ?></b> <?php if(isset($_cycles_2['online']))echo $_cycles_2['online']; ?> <?php if(isset($_cycles_2['sex']))echo $_cycles_2['sex']; ?><br />
<?php if(isset($this -> vars['users'][$_cycles_2_i]['level']) && (bool)$this -> vars['users'][$_cycles_2_i]['level']): ?>სტატუსი ფორუმში: <?php if(isset($_cycles_2['level']))echo $_cycles_2['level']; ?><br /><?php endif; ?>
<?php if(isset($this -> vars['users'][$_cycles_2_i]['date_reg']) && (bool)$this -> vars['users'][$_cycles_2_i]['date_reg']): ?>დარეგისტრირდა: <?php if(isset($_cycles_2['date_reg']))echo $_cycles_2['date_reg']; ?><br /><?php endif; ?><?php if(isset($this -> vars['users'][$_cycles_2_i]['date_last_visit']) && (bool)$this -> vars['users'][$_cycles_2_i]['date_last_visit']): ?>ბოლო ვიზიტი: <?php if(isset($_cycles_2['date_last_visit']))echo $_cycles_2['date_last_visit']; ?><br /><?php endif; ?>
<?php if(isset($this -> vars['users'][$_cycles_2_i]['info_name']) && (bool)$this -> vars['users'][$_cycles_2_i]['info_name']): ?>ნამდვილი სახელი: <?php if(isset($_cycles_2['info_name']))echo $_cycles_2['info_name']; ?><br /><?php endif; ?><?php if(isset($this -> vars['users'][$_cycles_2_i]['info_city']) && (bool)$this -> vars['users'][$_cycles_2_i]['info_city']): ?>მდებარეობა: <?php if(isset($_cycles_2['info_city']))echo $_cycles_2['info_city']; ?><br /><?php endif; ?>
<a href="<?php if(isset($this -> vars['path']))echo $this -> vars['path']; ?>user<?php if(isset($_cycles_2['id']))echo $_cycles_2['id']; ?>/">პროფილის ნახვა</a>
</div>		<?php endfor; ?>
<?php endif; ?>
<?php if(isset($this -> vars['pagebar']))echo $this -> vars['pagebar']; ?><?php endif; ?>
<?php if(!isset($this -> vars['count_users']) || !(bool)$this -> vars['count_users']): ?>
არავინ არაა რეგისტრირებული.<br /><?php endif; ?>
<?php if(isset($this -> vars['count_users']) && (bool)$this -> vars['count_users']): ?>მოიძებნა წევრები: <b><?php if(isset($this -> vars['count_users']))echo $this -> vars['count_users']; ?></b><br /><?php endif; ?>

<?php break; ?>


<?php case 'bbcodes': ?>

თქვენთვის ხელმისაწვდომია შემდეგი BB-კოდები: <br />
<br />
[b]სქელი ტექსტი[/b] - <b>სქელი ტექსტი</b><br />
[i]დახრილი ტექსტი[/i] - <i>დახრილი ტექსტი</i><br />
[u]ხაზგასმული ტექსტი[/u] - <u>ხაზგასმული ტექსტი</u><br />
[del]გადახაზული ტექსტი[/del] - <strike>გადახაზული ტექსტი</strike><br />
[url]http://<?php if(isset($this -> vars['domain']))echo $this -> vars['domain']; ?>[/url] - <a href="http://<?php if(isset($this -> vars['domain']))echo $this -> vars['domain']; ?>">http://<?php if(isset($this -> vars['domain']))echo $this -> vars['domain']; ?></a><br />
[url=http://<?php if(isset($this -> vars['domain']))echo $this -> vars['domain']; ?>]ბმულის სახელი[/url] - <a href="http://<?php if(isset($this -> vars['domain']))echo $this -> vars['domain']; ?>">ბმულის სახელი</a><br />
[geo]teqsti qarTulad[/geo] - ტექსტი ქართულად (<a href="<?php if(isset($this -> vars['path']))echo $this -> vars['path']; ?>index.php?mode=translit">ტრანსლიტის წესები</a>)<br />
[offtop]დარღვევა[/offtop] - <span class="offtop">დარღვევა</span><br/>
[img]http://<?php if(isset($this -> vars['domain']))echo $this -> vars['domain']; ?>/logo.png[/img] - <img src="http://<?php if(isset($this -> vars['domain']))echo $this -> vars['domain']; ?>/logo.png" height="20" width="60"><br />
[youtube]Y1_VsyLAGuk[/youtube] ჩასვით ბმულიდან: https://www.youtube.com/watch?v=<font color="red">Y1_VsyLAGuk</font><br />
<br />
[hide]ფორუმის სტუმრებისთვის დაფარული ტექსტი[/hide] - <div class="hide"><?php if(isset($this -> vars['user_auth']) && $this -> vars['user_auth'] === true): ?>ფორუმის სტუმრებისთვის დაფარული ტექსტი<?php endif; ?><?php if(!isset($this -> vars['user_auth']) || $this -> vars['user_auth'] !== true): ?>დაფარული ტექსტი.<br />ტექსტის სანახავად საჭიროა <a href="<?php if(isset($this -> vars['path']))echo $this -> vars['path']; ?>login.php?mode=enter">შესვლა</a> თქვენი ანგარიშით.<?php endif; ?></div><br />
[quote]ციტატის ტექსტი[/quote] - <div class="quote"><span class="quote_text">ციტატის ტექსტი</span></div><br />
[quote=მეტსახელი]ციტატის ტექსტი[/quote] - <div class="quote"><b>მეტსახელი</b>: <br /><span class="quote_text">ციტატის ტექსტი</div></div><br />
[code]&lt;?php<br />
// რაიმე კომენტარი<br />
echo 'მოგესალმებით http://<?php if(isset($this -> vars['domain']))echo $this -> vars['domain']; ?><?php if(isset($this -> vars['path']))echo $this -> vars['path']; ?>';<br />
?&gt;[/code]  <div class="code"><span style="color: #000000"><span style="color: #0000BB">&lt;?php<br /></span><span style="color: #FF8000">//&nbsp;რაიმე&nbsp;კომენტარი<br /></span><span style="color: #007700">echo&nbsp;</span><span style="color: #DD0000">'მოგესალმებით http://<?php if(isset($this -> vars['domain']))echo $this -> vars['domain']; ?><?php if(isset($this -> vars['path']))echo $this -> vars['path']; ?>'</span><span style="color: #007700">;<br /></span><span style="color: #0000BB">?&gt;</span></span></div>
<br />
[red]წითელი ტექსტი[/red] - <font color="red">წითელი ტექსტი</font><br />
[blue]ლურჯი ტექსტი[/blue] - <font color="blue">ლურჯი ტექსტი</font><br />
[green]მწვანე ტექსტი[/green] - <font color="green">მწვანე ტექსტი</font><br />
[yellow]ყვითელი ტექსტი[/yellow] - <font color="yellow">ყვითელი ტექსტი</font><br />
[black]შავი ტექსტი[/black] - <font color="black">შავი ტექსტი</font><br />
<br />
[user:id] - <?php if(isset($this -> vars['user_id']))echo $this -> vars['user_id']; ?><br />
[user:name] - <?php if(isset($this -> vars['user_name']))echo $this -> vars['user_name']; ?><br />
[user:nick] - <?php if(isset($this -> vars['user_nick']))echo $this -> vars['user_nick']; ?><br />

<?php break; ?>


<?php case 'translit': ?>

ტრანსლიტის წესები BB კოდით სარგებლობისას "[geo][/geo]"<br />
a -> ა<br />
b -> ბ<br />
g -> გ<br />
d -> დ<br />
e -> ე<br />
v -> ვ<br />
z -> ზ<br />
T -> თ<br />
i -> ი<br />
k -> კ<br />
l -> ლ<br />
m -> მ<br />
n -> ნ<br />
o -> ო<br />
p -> პ<br />
J -> ჟ<br />
r -> რ<br />
s -> ს<br />
t -> ტ<br />
u -> უ<br />
f -> ფ<br />
q -> ქ<br />
R -> ღ<br />
y -> ყ<br />
S -> შ<br />
C -> ჩ<br />
c -> ც<br />
Z -> ძ<br />
w -> წ<br />
W -> ჭ<br />
x -> ხ<br />
j -> ჯ<br />
h -> ჰ<br />

<?php break; ?>


<?php case 'smiles': ?>

შეგიძლიათ გამოიყენოთ შემდეგი სიცილაკები შეტყობინებებში: <br />
<br />
<?php if (!empty($this -> vars['smiles'])): ?>
		<?php for($_cycles_3_c = count($this -> vars['smiles']), $_cycles_3_i = 0; $_cycles_3_i < $_cycles_3_c; $_cycles_3_i ++): ?>
	<?php $_cycles_3 = $this -> vars['smiles'][$_cycles_3_i]; ?>

<img src="<?php if(isset($this -> vars['path']))echo $this -> vars['path']; ?>images/smiles/<?php if(isset($_cycles_3['image']))echo $_cycles_3['image']; ?>" alt="<?php if(isset($_cycles_3['smile']))echo $_cycles_3['smile']; ?>" title="<?php if(isset($_cycles_3['smile']))echo $_cycles_3['smile']; ?>"/> - <?php if(isset($_cycles_3['smile']))echo $_cycles_3['smile']; ?><br />		<?php endfor; ?>
<?php endif; ?>

<?php break; ?>


<?php case 'rules_cats': ?>

<?php if (!empty($this -> vars['rules_cats'])): ?>
		<?php for($_cycles_4_c = count($this -> vars['rules_cats']), $_cycles_4_i = 0; $_cycles_4_i < $_cycles_4_c; $_cycles_4_i ++): ?>
	<?php $_cycles_4 = $this -> vars['rules_cats'][$_cycles_4_i]; ?>

<div class="unit"><a href="<?php if(isset($this -> vars['path']))echo $this -> vars['path']; ?>index.php?mode=rules&id=<?php if(isset($_cycles_4['id']))echo $_cycles_4['id']; ?>"><?php if(isset($_cycles_4['name']))echo $_cycles_4['name']; ?></a> (<?php if(isset($_cycles_4['count_rules']))echo $_cycles_4['count_rules']; ?>)<?php if(isset($this -> vars['rules_cats'][$_cycles_4_i]['managment_up']) && $this -> vars['rules_cats'][$_cycles_4_i]['managment_up'] === true): ?> <a href="<?php if(isset($this -> vars['path']))echo $this -> vars['path']; ?>index.php?mode=rules&position_cat=<?php if(isset($_cycles_4['id']))echo $_cycles_4['id']; ?>&act=up">მაღლა</a><?php endif; ?><?php if(isset($this -> vars['rules_cats'][$_cycles_4_i]['managment_down']) && $this -> vars['rules_cats'][$_cycles_4_i]['managment_down'] === true): ?> <a href="<?php if(isset($this -> vars['path']))echo $this -> vars['path']; ?>index.php?mode=rules&position_cat=<?php if(isset($_cycles_4['id']))echo $_cycles_4['id']; ?>&act=down">დაბლა</a><?php endif; ?></div>		<?php endfor; ?>
<?php endif; ?>
<?php if(isset($this -> vars['need_re_position']) && $this -> vars['need_re_position'] === true): ?>
<span class="err">საჭიროა კატეგორიების პოზიციების განახლება.<br /> <a href="<?php if(isset($this -> vars['path']))echo $this -> vars['path']; ?>index.php?mode=rules&re_position&<?php if(isset($this -> vars['rand']))echo $this -> vars['rand']; ?>">გააკეთეთ ეს</a></span><br /><?php endif; ?>
<?php if(!isset($this -> vars['rules_cats']) || !(bool)$this -> vars['rules_cats']): ?>
წესები არაა შექმნილი.<br /><?php endif; ?>
<?php if(isset($this -> vars['user_level']) && isset($this -> vars['user_admin']) && $this -> vars['user_level'] >= $this -> vars['user_admin']): ?>
<form action="<?php if(isset($this -> vars['path']))echo $this -> vars['path']; ?>index.php?mode=rules&id=<?php if(isset($this -> vars['rules_cat_id']))echo $this -> vars['rules_cat_id']; ?>&addcat&<?php if(isset($this -> vars['rand']))echo $this -> vars['rand']; ?>" method="post"><input type="hidden" name="add" value="1"/>
კატეგორია: <br />
<input type="text" name="name" maxlength="50"/><br />
<input type="submit" value="დამატება"/>
</form><?php endif; ?>

<?php break; ?>


<?php case 'rules_cat_edit': ?>

<form action="<?php if(isset($this -> vars['path']))echo $this -> vars['path']; ?>index.php?mode=rules&id=<?php if(isset($this -> vars['rules_cat_id']))echo $this -> vars['rules_cat_id']; ?>&act=edit&edit&<?php if(isset($this -> vars['rand']))echo $this -> vars['rand']; ?>" method="post"><input type="hidden" name="edit" value="1"/>
სათაური: <br />
<input type="text" name="name" value="<?php if(isset($this -> vars['rules_cat_name']))echo $this -> vars['rules_cat_name']; ?>" maxlength="50"/><br />
<input type="submit" value="შენახვა"/>
</form>
<a href="<?php if(isset($this -> vars['path']))echo $this -> vars['path']; ?>index.php?mode=rules&id=<?php if(isset($this -> vars['rules_cat_id']))echo $this -> vars['rules_cat_id']; ?>">კატეგორია &quot;<?php if(isset($this -> vars['rules_cat_name']))echo $this -> vars['rules_cat_name']; ?>&quot;</a><br />
<a href="<?php if(isset($this -> vars['path']))echo $this -> vars['path']; ?>index.php?mode=rules">წესების კატეგორიები</a><br />

<?php break; ?>


<?php case 'rules_cat_del': ?>

<form action="<?php if(isset($this -> vars['path']))echo $this -> vars['path']; ?>index.php?mode=rules&id=<?php if(isset($this -> vars['rules_cat_id']))echo $this -> vars['rules_cat_id']; ?>&act=del&del&<?php if(isset($this -> vars['rand']))echo $this -> vars['rand']; ?>" method="post"><input type="hidden" name="del" value="1"/>
ყველა წესი წაიშლება კატეგორიაში.<br />
<input type="submit" value="კატეგორიის წაშლა"/>
</form>
<a href="<?php if(isset($this -> vars['path']))echo $this -> vars['path']; ?>index.php?mode=rules&id=<?php if(isset($this -> vars['rules_cat_id']))echo $this -> vars['rules_cat_id']; ?>">კატეგორია &quot;<?php if(isset($this -> vars['rules_cat_name']))echo $this -> vars['rules_cat_name']; ?>&quot;</a><br />
<a href="<?php if(isset($this -> vars['path']))echo $this -> vars['path']; ?>index.php?mode=rules">წესების კატეგორიები</a><br />

<?php break; ?>


<?php case 'rules': ?>

<?php if (!empty($this -> vars['rules'])): ?>
		<?php for($_cycles_5_c = count($this -> vars['rules']), $_cycles_5_i = 0; $_cycles_5_i < $_cycles_5_c; $_cycles_5_i ++): ?>
	<?php $_cycles_5 = $this -> vars['rules'][$_cycles_5_i]; ?>

<div class="<?php if(isset($_cycles_5['divclass']))echo $_cycles_5['divclass']; ?>" id="rule-<?php if(isset($_cycles_5['id']))echo $_cycles_5['id']; ?>"><?php if(isset($this -> vars['rules'][$_cycles_5_i]['title']) && (bool)$this -> vars['rules'][$_cycles_5_i]['title']): ?><b><?php if(isset($_cycles_5['title']))echo $_cycles_5['title']; ?></b><br /><?php endif; ?>
<?php if(isset($_cycles_5['text']))echo $_cycles_5['text']; ?><br />
<?php if(isset($this -> vars['user_level']) && isset($this -> vars['user_admin']) && $this -> vars['user_level'] >= $this -> vars['user_admin']): ?><a href="<?php if(isset($this -> vars['path']))echo $this -> vars['path']; ?>index.php?mode=rules&id=<?php if(isset($this -> vars['rules_cat_id']))echo $this -> vars['rules_cat_id']; ?>&rid=<?php if(isset($_cycles_5['id']))echo $_cycles_5['id']; ?>&sact=edit">რედაქტირება</a> <a href="<?php if(isset($this -> vars['path']))echo $this -> vars['path']; ?>index.php?mode=rules&id=<?php if(isset($this -> vars['rules_cat_id']))echo $this -> vars['rules_cat_id']; ?>&rid=<?php if(isset($_cycles_5['id']))echo $_cycles_5['id']; ?>&sact=del">წაშლა</a><?php endif; ?>
</div>		<?php endfor; ?>
<?php endif; ?>
<?php if(!isset($this -> vars['rules']) || !(bool)$this -> vars['rules']): ?>
წესები არაა შექმნილი.<br /><?php endif; ?>
<?php if(isset($this -> vars['user_level']) && isset($this -> vars['user_admin']) && $this -> vars['user_level'] >= $this -> vars['user_admin']): ?>
<form action="<?php if(isset($this -> vars['path']))echo $this -> vars['path']; ?>index.php?mode=rules&id=<?php if(isset($this -> vars['rules_cat_id']))echo $this -> vars['rules_cat_id']; ?>&add&<?php if(isset($this -> vars['rand']))echo $this -> vars['rand']; ?>" method="post" class="unit"><input type="hidden" name="add" value="1"/>
წესების სათაური: <br />
<input type="text" name="title" maxlength="70"/><br />
შინაარსი: <br />
<textarea name="text" cols="40" rows="8" wrap="off"></textarea><br />
<input type="submit" value="დამატება"/>
</form>
&raquo; <a href="<?php if(isset($this -> vars['path']))echo $this -> vars['path']; ?>index.php?mode=rules&id=<?php if(isset($this -> vars['rules_cat_id']))echo $this -> vars['rules_cat_id']; ?>&act=edit">კატეგორიის შეცვლა</a><br />
&raquo; <a href="<?php if(isset($this -> vars['path']))echo $this -> vars['path']; ?>index.php?mode=rules&id=<?php if(isset($this -> vars['rules_cat_id']))echo $this -> vars['rules_cat_id']; ?>&act=del">კატეგორიის წაშლა</a><br /><?php endif; ?>
<a href="<?php if(isset($this -> vars['path']))echo $this -> vars['path']; ?>index.php?mode=rules">წესების კატეგორიები</a><br />

<?php break; ?>


<?php case 'rule_edit': ?>

<form action="<?php if(isset($this -> vars['path']))echo $this -> vars['path']; ?>index.php?mode=rules&id=<?php if(isset($this -> vars['rules_cat_id']))echo $this -> vars['rules_cat_id']; ?>&rid=<?php if(isset($this -> vars['rule_id']))echo $this -> vars['rule_id']; ?>&sact=edit&edit&<?php if(isset($this -> vars['rand']))echo $this -> vars['rand']; ?>" method="post"><input type="hidden" name="edit" value="1"/>
წესების სათაური: <br />
<input type="text" name="title" value="<?php if(isset($this -> vars['rule_title']))echo $this -> vars['rule_title']; ?>" maxlength="70"/><br />
შინაარსი: <br />
<textarea name="text" cols="40" rows="8" wrap="off"><?php if(isset($this -> vars['rule_text']))echo $this -> vars['rule_text']; ?></textarea><br />
<input type="submit" value="შენახვა"/>
</form>
<a href="<?php if(isset($this -> vars['path']))echo $this -> vars['path']; ?>index.php?mode=rules&id=<?php if(isset($this -> vars['rules_cat_id']))echo $this -> vars['rules_cat_id']; ?>">კატეგორია &quot;<?php if(isset($this -> vars['rules_cat_name']))echo $this -> vars['rules_cat_name']; ?>&quot;</a><br />
<a href="<?php if(isset($this -> vars['path']))echo $this -> vars['path']; ?>index.php?mode=rules">წესების კატეგორიები</a><br />

<?php break; ?>


<?php case 'rule_del': ?>

<form action="<?php if(isset($this -> vars['path']))echo $this -> vars['path']; ?>index.php?mode=rules&id=<?php if(isset($this -> vars['rules_cat_id']))echo $this -> vars['rules_cat_id']; ?>&rid=<?php if(isset($this -> vars['rule_id']))echo $this -> vars['rule_id']; ?>&sact=del&del&<?php if(isset($this -> vars['rand']))echo $this -> vars['rand']; ?>" method="post"><input type="hidden" name="del" value="1"/>
<div class="quote"><span class="quote_text"><?php if(isset($this -> vars['rule_text']))echo $this -> vars['rule_text']; ?></span></div>
<input type="submit" value="წესების წაშლა"/>
</form>
<a href="<?php if(isset($this -> vars['path']))echo $this -> vars['path']; ?>index.php?mode=rules&id=<?php if(isset($this -> vars['rules_cat_id']))echo $this -> vars['rules_cat_id']; ?>">კატეგორია &quot;<?php if(isset($this -> vars['rules_cat_name']))echo $this -> vars['rules_cat_name']; ?>&quot;</a><br />
<a href="<?php if(isset($this -> vars['path']))echo $this -> vars['path']; ?>index.php?mode=rules">წესების კატეგორიები</a><br />

<?php break; ?>


<?php case 'search': ?>

<form action="<?php if(isset($this -> vars['path']))echo $this -> vars['path']; ?>index.php" method="get" class="unit"><input type="hidden" name="mode" value="search"/>
საძიებო ფრაზა: <br />
<input type="text" name="q" value="<?php if(isset($this -> vars['search']['q']))echo $this -> vars['search']['q']; ?>"/><br />

მოვძებნოთ: <br />
<select name="what">
<option value="topics"<?php if(isset($this -> vars['search']['type']) && $this -> vars['search']['type'] == 'topics'): ?> selected="selected"<?php endif; ?>>თემები</option>
<option value="posts"<?php if(isset($this -> vars['search']['what']) && $this -> vars['search']['what'] == 'posts'): ?> selected="selected"<?php endif; ?>>გამოხმაურებები</option>
</select><br />
<input type="submit" value="ძებნა"/>
</form>
<?php if(isset($this -> vars['search']['q']) && (bool)$this -> vars['search']['q']): ?>
<hr/>
<?php if(isset($this -> vars['search']['what']) && $this -> vars['search']['what'] == 'topics'): ?>
<?php if (!empty($this -> vars['topics'])): ?>
		<?php for($_cycles_6_c = count($this -> vars['topics']), $_cycles_6_i = 0; $_cycles_6_i < $_cycles_6_c; $_cycles_6_i ++): ?>
	<?php $_cycles_6 = $this -> vars['topics'][$_cycles_6_i]; ?>

<div class="unit"><i>#<?php if(isset($_cycles_6['i']))echo $_cycles_6['i']; ?>.</i> <a href="<?php if(isset($this -> vars['path']))echo $this -> vars['path']; ?>topic<?php if(isset($_cycles_6['id']))echo $_cycles_6['id']; ?>/"><?php if(isset($_cycles_6['name']))echo $_cycles_6['name']; ?></a> (<?php if(isset($_cycles_6['count_posts']))echo $_cycles_6['count_posts']; ?>)<br />
<?php if(isset($_cycles_6['user']))echo $_cycles_6['user']; ?> / <?php if(isset($_cycles_6['date']))echo $_cycles_6['date']; ?>
</div>		<?php endfor; ?>
<?php endif; ?>
<?php if(isset($this -> vars['pagebar']))echo $this -> vars['pagebar']; ?>
<?php if(!isset($this -> vars['topics']) || !(bool)$this -> vars['topics']): ?>
თემები ვერ მოიძებნა.<br /><?php endif; ?><?php endif; ?>
<?php if(isset($this -> vars['search']['what']) && $this -> vars['search']['what'] == 'posts'): ?>
<?php if (!empty($this -> vars['posts'])): ?>
		<?php for($_cycles_7_c = count($this -> vars['posts']), $_cycles_7_i = 0; $_cycles_7_i < $_cycles_7_c; $_cycles_7_i ++): ?>
	<?php $_cycles_7 = $this -> vars['posts'][$_cycles_7_i]; ?>

<div class="unit"><i>#<?php if(isset($_cycles_7['i']))echo $_cycles_7['i']; ?>.</i> <a href="<?php if(isset($this -> vars['path']))echo $this -> vars['path']; ?>topic<?php if(isset($_cycles_7['tid']))echo $_cycles_7['tid']; ?>/"><?php if(isset($_cycles_7['topic_name']))echo $_cycles_7['topic_name']; ?></a> (<?php if(isset($_cycles_7['topic_count_posts']))echo $_cycles_7['topic_count_posts']; ?>)<br />
<a href="<?php if(isset($this -> vars['path']))echo $this -> vars['path']; ?>post<?php if(isset($_cycles_7['id']))echo $_cycles_7['id']; ?>/"><?php if(isset($_cycles_7['date']))echo $_cycles_7['date']; ?></a> : <?php if(isset($_cycles_7['text']))echo $_cycles_7['text']; ?>
</div>		<?php endfor; ?>
<?php endif; ?>
<?php if(isset($this -> vars['pagebar']))echo $this -> vars['pagebar']; ?>
<?php if(!isset($this -> vars['posts']) || !(bool)$this -> vars['posts']): ?>
პოსტები ვერ მოიძებნა.<br /><?php endif; ?><?php endif; ?><?php endif; ?>

<?php break; ?>


<?php case 'last_topics': ?>

გამოჩდეს: <?php if(!isset($this -> vars['only_new']) || $this -> vars['only_new'] !== true): ?>ყველა / <a href="<?php if(isset($this -> vars['path']))echo $this -> vars['path']; ?>index.php?mode=last_topics&only_new">ახალი ჩემთვის</a><?php endif; ?><?php if(isset($this -> vars['only_new']) && $this -> vars['only_new'] === true): ?><a href="<?php if(isset($this -> vars['path']))echo $this -> vars['path']; ?>index.php?mode=last_topics">ყველა</a> / ახალი ჩემთვის<?php endif; ?><br />
ბოლოს შექმნილი 15 თემა.<br />
<?php if (!empty($this -> vars['topics'])): ?>
		<?php for($_cycles_8_c = count($this -> vars['topics']), $_cycles_8_i = 0; $_cycles_8_i < $_cycles_8_c; $_cycles_8_i ++): ?>
	<?php $_cycles_8 = $this -> vars['topics'][$_cycles_8_i]; ?>

<div class="unit"><i>#<?php if(isset($_cycles_8['i']))echo $_cycles_8['i']; ?>.</i> <a href="<?php if(isset($this -> vars['path']))echo $this -> vars['path']; ?>topic<?php if(isset($_cycles_8['id']))echo $_cycles_8['id']; ?>/"><?php if(isset($_cycles_8['name']))echo $_cycles_8['name']; ?></a> (<?php if(isset($_cycles_8['count_posts']))echo $_cycles_8['count_posts']; ?>)<br />
<?php if(isset($_cycles_8['user']))echo $_cycles_8['user']; ?> / <?php if(isset($_cycles_8['date']))echo $_cycles_8['date']; ?>
</div>		<?php endfor; ?>
<?php endif; ?>
<?php if(!isset($this -> vars['topics']) || !(bool)$this -> vars['topics']): ?>
თემა არაა.<br /><?php endif; ?>

<?php break; ?>


<?php case 'last_posts': ?>

გამოჩდეს: <?php if(!isset($this -> vars['only_new']) || $this -> vars['only_new'] !== true): ?>ყველა / <a href="<?php if(isset($this -> vars['path']))echo $this -> vars['path']; ?>index.php?mode=last_posts&only_new">ახალი ჩემთვის</a><?php endif; ?><?php if(isset($this -> vars['only_new']) && $this -> vars['only_new'] === true): ?><a href="<?php if(isset($this -> vars['path']))echo $this -> vars['path']; ?>index.php?mode=last_posts">ყველა</a> / ახალი ჩემთვის<?php endif; ?><br />
ბოლო 20 დაწერილი პოსტი.<br />
<?php if (!empty($this -> vars['posts'])): ?>
		<?php for($_cycles_9_c = count($this -> vars['posts']), $_cycles_9_i = 0; $_cycles_9_i < $_cycles_9_c; $_cycles_9_i ++): ?>
	<?php $_cycles_9 = $this -> vars['posts'][$_cycles_9_i]; ?>

<div class="unit"><i>#<?php if(isset($_cycles_9['i']))echo $_cycles_9['i']; ?>.</i> <a href="<?php if(isset($this -> vars['path']))echo $this -> vars['path']; ?>topic<?php if(isset($_cycles_9['tid']))echo $_cycles_9['tid']; ?>/"><?php if(isset($_cycles_9['topic_name']))echo $_cycles_9['topic_name']; ?></a> (<?php if(isset($_cycles_9['topic_count_posts']))echo $_cycles_9['topic_count_posts']; ?>)<br />
<a href="<?php if(isset($this -> vars['path']))echo $this -> vars['path']; ?>post<?php if(isset($_cycles_9['id']))echo $_cycles_9['id']; ?>/"><?php if(isset($_cycles_9['date']))echo $_cycles_9['date']; ?></a> : <?php if(isset($_cycles_9['text']))echo $_cycles_9['text']; ?>
</div>		<?php endfor; ?>
<?php endif; ?>
<?php if(!isset($this -> vars['posts']) || !(bool)$this -> vars['posts']): ?>
პოსტი არაა.<br /><?php endif; ?>

<?php break; ?>


<?php case 'test': ?>

ტესტი<br />
<?php if (!empty($this -> vars['a'])): ?>
		<?php for($_cycles_10_c = count($this -> vars['a']), $_cycles_10_i = 0; $_cycles_10_i < $_cycles_10_c; $_cycles_10_i ++): ?>
	<?php $_cycles_10 = $this -> vars['a'][$_cycles_10_i]; ?>

- <?php if(isset($_cycles_10['test']))echo $_cycles_10['test']; ?><br />
<?php if(isset($this -> vars['a'][$_cycles_10_i]['bool']) && $this -> vars['a'][$_cycles_10_i]['bool'] === true): ?>BOOL<?php endif; ?><br />		<?php endfor; ?>
<?php endif; ?>

<?php break; ?>
<?php endswitch; ?>