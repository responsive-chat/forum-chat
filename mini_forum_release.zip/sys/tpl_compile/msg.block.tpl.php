<?php /* გენერირებულია 19:03:30 01.12.2018 ფაილიდან /home/forumix5/public_html/sys/tpl_compile/msg.block.tpl */ ?>
<?php if (!empty($this -> vars['messages'])): ?>
		<?php for($_cycles_1_c = count($this -> vars['messages']), $_cycles_1_i = 0; $_cycles_1_i < $_cycles_1_c; $_cycles_1_i ++): ?>
	<?php $_cycles_1 = $this -> vars['messages'][$_cycles_1_i]; ?>

<div class="msg"><small><?php if(isset($_cycles_1['line']))echo $_cycles_1['line']; ?></small> <?php if(isset($_cycles_1['info']))echo $_cycles_1['info']; ?></div>		<?php endfor; ?>
<?php endif; ?>