<?php /* გენერირებულია 17:41:41 03.12.2018 ფაილიდან /home/forumix5/public_html/sys/tpl_compile/err.block.tpl */ ?>
<?php if (!empty($this -> vars['errors'])): ?>
		<?php for($_cycles_1_c = count($this -> vars['errors']), $_cycles_1_i = 0; $_cycles_1_i < $_cycles_1_c; $_cycles_1_i ++): ?>
	<?php $_cycles_1 = $this -> vars['errors'][$_cycles_1_i]; ?>

<div class="err"><small><?php if(isset($_cycles_1['line']))echo $_cycles_1['line']; ?></small> <?php if(isset($_cycles_1['info']))echo $_cycles_1['info']; ?></div>		<?php endfor; ?>
<?php endif; ?>