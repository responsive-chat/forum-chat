<?php /* გენერირებულია 9:25:46 08.11.2020 ფაილიდან /home/f0474738/domains/forumi.eu.org/public_html/sys/tpl_compile/forum.page.tpl */ ?>
<?php if(isset($this -> vars['page_zag']) && (bool)$this -> vars['page_zag']): ?><div class="menu"><?php if(isset($this -> vars['page_zag']))echo $this -> vars['page_zag']; ?></div><?php endif; ?>
<?php switch(isset($this -> vars['block']) ? $this -> vars['block'] : null): ?>
<?php case 'index': ?>

<?php if (!empty($this -> vars['topics'])): ?>
		<?php for($_cycles_1_c = count($this -> vars['topics']), $_cycles_1_i = 0; $_cycles_1_i < $_cycles_1_c; $_cycles_1_i ++): ?>
	<?php $_cycles_1 = $this -> vars['topics'][$_cycles_1_i]; ?>

<div class="unit">
<i><?php if(isset($_cycles_1['i']))echo $_cycles_1['i']; ?></i>. <?php if(isset($_cycles_1['icons']))echo $_cycles_1['icons']; ?><a href="<?php if(isset($this -> vars['path']))echo $this -> vars['path']; ?>topic<?php if(isset($_cycles_1['id']))echo $_cycles_1['id']; ?>/"><?php if(isset($_cycles_1['name']))echo $_cycles_1['name']; ?></a> (<?php if(isset($_cycles_1['count_posts']))echo $_cycles_1['count_posts']; ?>)<br />
<?php if(isset($_cycles_1['user']))echo $_cycles_1['user']; ?> / <?php if(isset($_cycles_1['date']))echo $_cycles_1['date']; ?>
</div>		<?php endfor; ?>
<?php endif; ?>
<?php if(isset($this -> vars['pagebar']))echo $this -> vars['pagebar']; ?>
<?php if(!isset($this -> vars['topics']) || !(bool)$this -> vars['topics']): ?>
თემები არაა<br /><?php endif; ?>
<?php if(isset($this -> vars['forum_level_topics']) && isset($this -> vars['user_level']) && $this -> vars['forum_level_topics'] > $this -> vars['user_level']): ?><span class="err">თქვენ არ შეგიძლიათ გახსნათ ახალი თემა ამ განყოფილებაში.</span><br /><?php endif; ?>
<?php if(isset($this -> vars['forum_level_topics']) && isset($this -> vars['user_level']) && $this -> vars['forum_level_topics'] <= $this -> vars['user_level']): ?><a href="<?php if(isset($this -> vars['path']))echo $this -> vars['path']; ?>forum<?php if(isset($this -> vars['forum_id']))echo $this -> vars['forum_id']; ?>/newtopic/">ახალი თემის გახსნა</a><br /><?php endif; ?>

<?php if(isset($this -> vars['forum_level']) && $this -> vars['forum_level'] != 0): ?><div class="menu">განყოფილება ხელმისაწვდომია: <?php if(isset($this -> vars['forum_level']) && $this -> vars['forum_level'] == 1): ?>მომხმარებლებისთვის<?php endif; ?><?php if(isset($this -> vars['forum_level']) && $this -> vars['forum_level'] == 2): ?>მოდერატორებისთვის<?php endif; ?><?php if(isset($this -> vars['forum_level']) && $this -> vars['forum_level'] == 3): ?>ადმინისტრატორებისთვის<?php endif; ?></div><?php endif; ?>
<?php if(isset($this -> vars['forum_level_topics']) && $this -> vars['forum_level_topics'] != 1): ?><div class="menu">ახალი თემის გახსნა შეუძლიათ: <?php if(isset($this -> vars['forum_level_topics']) && $this -> vars['forum_level_topics'] == 0): ?>ყველას<?php endif; ?><?php if(isset($this -> vars['forum_level_topics']) && $this -> vars['forum_level_topics'] == 2): ?>მოდერატორებს<?php endif; ?><?php if(isset($this -> vars['forum_level_topics']) && $this -> vars['forum_level_topics'] == 3): ?>ადმინისტრატორებს<?php endif; ?></div><?php endif; ?>
<?php if(!isset($this -> vars['forum_counter_posts']) || $this -> vars['forum_counter_posts'] !== true): ?><div class="menu">პოსტების მთვლელი გამორთულია</div><?php endif; ?>
<?php if(!isset($this -> vars['forum_counter_topics']) || $this -> vars['forum_counter_topics'] !== true): ?><div class="menu">თემების მთვლელი გამორთულია</div><?php endif; ?>

<?php if(isset($this -> vars['user_level']) && isset($this -> vars['user_admin']) && $this -> vars['user_level'] >= $this -> vars['user_admin']): ?>
&raquo; <a href="<?php if(isset($this -> vars['path']))echo $this -> vars['path']; ?>forum<?php if(isset($this -> vars['forum_id']))echo $this -> vars['forum_id']; ?>/edit/">განყოფილების რედაქტირება</a><br />
&raquo; <a href="<?php if(isset($this -> vars['path']))echo $this -> vars['path']; ?>forum<?php if(isset($this -> vars['forum_id']))echo $this -> vars['forum_id']; ?>/del/">განყოფილების წაშლა</a><br /><?php endif; ?>

<?php break; ?>


<?php case 'newtopic': ?>

<form action="<?php if(isset($this -> vars['path']))echo $this -> vars['path']; ?>forum<?php if(isset($this -> vars['forum_id']))echo $this -> vars['forum_id']; ?>/newtopic/<?php if(isset($this -> vars['rand']))echo $this -> vars['rand']; ?>/" method="post" class="unit"><input type="hidden" name="create" value="1"/>
თემა: <br />
<input type="text" onkeypress="return makeGeo(this,event);" name="topic_name" size="20" maxlength="200"><br />
გამოხმაურება: <br />
<textarea name="topic_post" cols="40" rows="8" onkeypress="return makeGeo(this,event);"></textarea><br />
<label><input type="checkbox" name="post_on_pages" value="1"/>გამოხმაურების ჩვენება ყველა გვერძზე</label><br />
<input type="submit" value="თემის გახსნა"/>
<input checked="checked" id="geoKeys" type="checkbox" /><b>ქართული კლავიატურა</b><br>
</form>
&raquo; <a href="<?php if(isset($this -> vars['path']))echo $this -> vars['path']; ?>index.php?mode=bbcodes">BB კოდები</a><br />
&raquo; <a href="<?php if(isset($this -> vars['path']))echo $this -> vars['path']; ?>index.php?mode=smiles">სიცილაკები</a><br />

<?php break; ?>


<?php case 'edit': ?>

<form action="<?php if(isset($this -> vars['path']))echo $this -> vars['path']; ?>forum<?php if(isset($this -> vars['forum_id']))echo $this -> vars['forum_id']; ?>/edit/<?php if(isset($this -> vars['rand']))echo $this -> vars['rand']; ?>/" method="post" class="unit"><input type="hidden" name="edit" value="1">
განყოფილება: <br />
<input type="text" name="forum_name" value="<?php if(isset($this -> vars['forum_name']))echo $this -> vars['forum_name']; ?>" maxlength="50"/><br />
განყოფილების აღწერა: <br />
<input type="text" name="forum_description" value="<?php if(isset($this -> vars['forum_description']))echo $this -> vars['forum_description']; ?>" maxlength="250"/><br />
განყოფილებაზე წვდომის უფლება აქვთ: <br />
<select name="level">
<option value="0"<?php if(isset($this -> vars['level']) && $this -> vars['level'] == 0): ?> selected="selected"<?php endif; ?>>ყველას</option>
<option value="1"<?php if(isset($this -> vars['level']) && $this -> vars['level'] == 1): ?> selected="selected"<?php endif; ?>>მომხმარებელს</option>
<option value="2"<?php if(isset($this -> vars['level']) && $this -> vars['level'] == 2): ?> selected="selected"<?php endif; ?>>მოდერატორს</option>
<option value="3"<?php if(isset($this -> vars['level']) && $this -> vars['level'] == 3): ?> selected="selected"<?php endif; ?>>ადმინისტრატორს</option>
</select><br />
ახალი თემის გახსნა შეუძლიათ: <br />
<select name="level_topics">
<option value="0"<?php if(isset($this -> vars['level_topics']) && $this -> vars['level_topics'] == 0): ?> selected="selected"<?php endif; ?>>ყველას</option>
<option value="1"<?php if(isset($this -> vars['level_topics']) && $this -> vars['level_topics'] == 1): ?> selected="selected"<?php endif; ?>>მომხმარებელს</option>
<option value="2"<?php if(isset($this -> vars['level_topics']) && $this -> vars['level_topics'] == 2): ?> selected="selected"<?php endif; ?>>მოდერატორს</option>
<option value="3"<?php if(isset($this -> vars['level_topics']) && $this -> vars['level_topics'] == 3): ?> selected="selected"<?php endif; ?>>ადმინისტრატორს</option>
</select><br />
<label><input type="checkbox" name="counter_posts" value="1"<?php if(isset($this -> vars['counter_posts']) && $this -> vars['counter_posts'] === true): ?> checked="checked"<?php endif; ?>/>პოსტების მთვლელი</label><br />
<label><input type="checkbox" name="counter_topics" value="1"<?php if(isset($this -> vars['counter_topics']) && $this -> vars['counter_topics'] === true): ?> checked="checked"<?php endif; ?>/>თემების მთვლელი</label><br />
<input type="submit" value="შეცვლა"/>
</form>

<?php break; ?>


<?php case 'del': ?>

<form action="<?php if(isset($this -> vars['path']))echo $this -> vars['path']; ?>forum<?php if(isset($this -> vars['forum_id']))echo $this -> vars['forum_id']; ?>/del/<?php if(isset($this -> vars['rand']))echo $this -> vars['rand']; ?>/" method="post" class="unit"><input type="hidden" name="del" value="1">
თემების და პოსტების გადატანა განყოფილებაში: <br />
<select name="into_forum">
<?php if (!empty($this -> vars['forums'])): ?>
		<?php for($_cycles_2_c = count($this -> vars['forums']), $_cycles_2_i = 0; $_cycles_2_i < $_cycles_2_c; $_cycles_2_i ++): ?>
	<?php $_cycles_2 = $this -> vars['forums'][$_cycles_2_i]; ?>

<option value="<?php if(isset($_cycles_2['id']))echo $_cycles_2['id']; ?>"><?php if(isset($_cycles_2['name']))echo $_cycles_2['name']; ?></option>		<?php endfor; ?>
<?php endif; ?>
<option value="delete">- შიგთავსის წაშლა</option>
</select><br />
<input type="submit" value="განყოფილების წაშლა"/>
</form>

<?php break; ?>
<?php endswitch; ?>