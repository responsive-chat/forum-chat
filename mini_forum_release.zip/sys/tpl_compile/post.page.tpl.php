<?php /* გენერირებულია 3:53:01 20.12.2018 ფაილიდან /home/forumix5/public_html/sys/tpl_compile/post.page.tpl */ ?>
<?php if(isset($this -> vars['page_zag']) && (bool)$this -> vars['page_zag']): ?><div class="menu"><?php if(isset($this -> vars['page_zag']))echo $this -> vars['page_zag']; ?></div><?php endif; ?>
<?php switch(isset($this -> vars['block']) ? $this -> vars['block'] : null): ?>
<?php case 'edit': ?>

<form action="<?php if(isset($this -> vars['path']))echo $this -> vars['path']; ?>post<?php if(isset($this -> vars['post_id']))echo $this -> vars['post_id']; ?>/edit/<?php if(isset($this -> vars['rand']))echo $this -> vars['rand']; ?>/" method="post" class="unit"><input type="hidden" name="edit" value="1"/>
გამოხმაურება: <br />
<textarea name="post" cols="40" rows="8" wrap="off"><?php if(isset($this -> vars['post_text']))echo $this -> vars['post_text']; ?></textarea><br />
<?php if(isset($this -> vars['user_level']) && isset($this -> vars['user_admin']) && $this -> vars['user_level'] >= $this -> vars['user_admin']): ?><label><input type="checkbox" name="not_view_edit" value="1"/>რედაქტირების დამალვა</label><br /><?php endif; ?>
<input type="submit" value="შეცვლა"/>
</form>
<?php if(isset($this -> vars['post_manage']) && $this -> vars['post_manage'] === true): ?>&raquo; <a href="<?php if(isset($this -> vars['path']))echo $this -> vars['path']; ?>post<?php if(isset($this -> vars['post_id']))echo $this -> vars['post_id']; ?>/trans/<?php if(isset($this -> vars['rand']))echo $this -> vars['rand']; ?>/">გადატანა</a><br />
&raquo; <a href="<?php if(isset($this -> vars['path']))echo $this -> vars['path']; ?>post<?php if(isset($this -> vars['post_id']))echo $this -> vars['post_id']; ?>/del/<?php if(isset($this -> vars['rand']))echo $this -> vars['rand']; ?>/">წაშლა</a><br />
<br /><?php endif; ?>
&raquo; <a href="<?php if(isset($this -> vars['path']))echo $this -> vars['path']; ?>index.php?mode=bbcodes">BB კოდები</a><br />
&raquo; <a href="<?php if(isset($this -> vars['path']))echo $this -> vars['path']; ?>index.php?mode=smiles">სიცილაკები</a><br />

<?php break; ?>


<?php case 'del': ?>

<form action="<?php if(isset($this -> vars['path']))echo $this -> vars['path']; ?>post<?php if(isset($this -> vars['post_id']))echo $this -> vars['post_id']; ?>/del/<?php if(isset($this -> vars['rand']))echo $this -> vars['rand']; ?>/" method="post" class="unit"><input type="hidden" name="del" value="1">
<input type="submit" value="გამოხმაურების წაშლა"/>
</form>

<?php break; ?>


<?php case 'trans': ?>

<form action="<?php if(isset($this -> vars['path']))echo $this -> vars['path']; ?>post<?php if(isset($this -> vars['post_id']))echo $this -> vars['post_id']; ?>/trans/<?php if(isset($this -> vars['rand']))echo $this -> vars['rand']; ?>/" method="post"><input type="hidden" name="yes" value="1"/>
<label><input type="radio" name="create" value="1" checked="checked"/>ახალი თემის გახსნა</label><br />
განყოფილება: <br />
<select name="into_forum">
<?php if (!empty($this -> vars['forums'])): ?>
		<?php for($_cycles_1_c = count($this -> vars['forums']), $_cycles_1_i = 0; $_cycles_1_i < $_cycles_1_c; $_cycles_1_i ++): ?>
	<?php $_cycles_1 = $this -> vars['forums'][$_cycles_1_i]; ?>

<option value="<?php if(isset($_cycles_1['id']))echo $_cycles_1['id']; ?>"><?php if(isset($_cycles_1['name']))echo $_cycles_1['name']; ?></option>		<?php endfor; ?>
<?php endif; ?>
</select><br />
თემის სათაური: <br />
<input type="text" name="topic_name" maxlength="100"><br />
<label><input type="checkbox" name="as_first_post" value="1"/>როგორც პირველი პოსტი</label><br />
<label><input type="radio" name="create" value="0"/>გადატანა უკვე არსებულ თემაში</label><br />
თემის ნომერი: <br />
<input type="text" name="into_topic" size="11"/><br />
<input type="submit" name="trans" value="გადატანა"/>
</form>

<?php break; ?>


<?php case 'answer': ?>

<form action="<?php if(isset($this -> vars['path']))echo $this -> vars['path']; ?>post<?php if(isset($this -> vars['post_id']))echo $this -> vars['post_id']; ?>/<?php if(isset($this -> vars['mode']))echo $this -> vars['mode']; ?>/<?php if(isset($this -> vars['rand']))echo $this -> vars['rand']; ?>/" method="post" class="unit"><input type="hidden" name="add" value="1"/>
<?php if(isset($this -> vars['mode']) && $this -> vars['mode'] == 'answer'): ?>თქვენ პასუხობთ პოსტს "<i><?php if(isset($this -> vars['short_post_text']))echo $this -> vars['short_post_text']; ?></i>"<br /><?php endif; ?>
<?php if(isset($this -> vars['mode']) && $this -> vars['mode'] == 'answer'): ?>თქვენი პასუხი<?php endif; ?><?php if(isset($this -> vars['mode']) && $this -> vars['mode'] == 'quote'): ?>თქვენი გამოხმაურება<?php endif; ?>: <br />
<textarea name="post" cols="40" rows="8" wrap="off" onkeypress="return makeGeo(this,event);"><?php if(isset($this -> vars['answer_text']))echo $this -> vars['answer_text']; ?></textarea><br />
<input type="submit" value="პასუხი"/>
<input checked="checked" id="geoKeys" type="checkbox" /><b>ქართული კლავიატურა</b><br>
</form>
<?php if(isset($this -> vars['mode']) && $this -> vars['mode'] != 'quote'): ?>&raquo; <a href="<?php if(isset($this -> vars['path']))echo $this -> vars['path']; ?>post<?php if(isset($this -> vars['post_id']))echo $this -> vars['post_id']; ?>/quote/<?php if(isset($this -> vars['rand']))echo $this -> vars['rand']; ?>/">ციტატის ჩასმა პოსტში</a><br />
<br /><?php endif; ?>
&raquo; <a href="<?php if(isset($this -> vars['path']))echo $this -> vars['path']; ?>index.php?mode=bbcodes">BB კოდები</a><br />
&raquo; <a href="<?php if(isset($this -> vars['path']))echo $this -> vars['path']; ?>index.php?mode=smiles">სიცილაკები</a><br />

<?php break; ?>


<?php case 'punish': ?>

<form action="<?php if(isset($this -> vars['path']))echo $this -> vars['path']; ?>post<?php if(isset($this -> vars['post_id']))echo $this -> vars['post_id']; ?>/punish/<?php if(isset($this -> vars['rand']))echo $this -> vars['rand']; ?>/" method="post" class="unit"><input type="hidden" name="punish" value="1"/>
სასჯელი წესის მიხედვით: <br />
<select name="rule">
<option value="0">---</option>
<?php if (!empty($this -> vars['rules'])): ?>
		<?php for($_cycles_2_c = count($this -> vars['rules']), $_cycles_2_i = 0; $_cycles_2_i < $_cycles_2_c; $_cycles_2_i ++): ?>
	<?php $_cycles_2 = $this -> vars['rules'][$_cycles_2_i]; ?>

<option value="<?php if(isset($_cycles_2['id']))echo $_cycles_2['id']; ?>"><?php if(isset($_cycles_2['title']))echo $_cycles_2['title']; ?></option>		<?php endfor; ?>
<?php endif; ?>
</select><br />
ბლოკის ვადა: <br />
<input type="text" name="time1" value="1" size="3" maxlength="3"/>
<select name="time2">
<option value="60">წუთი</option>
<option value="3600">საათი</option>
<option value="86400">დღე</option>
<option value="604800">კვირა</option>
<option value="2592000">თვე</option>
</select><br />
კომენტარი: <br />
<input type="text" name="comment" maxlength="500"/><br />
<label><input type="checkbox" name="ban" value="1">პოსტების დაწერის და თემების შექმნის აკრძალვა</label><br />
<label><input type="checkbox" name="close_private" value="1">პირადი წერილების გაგზავნის და წაკითხვის აკრძალვა</label><br />
<input type="submit" value="Наказать"/>
</form>

<?php break; ?>
<?php endswitch; ?>
<a href="<?php if(isset($this -> vars['path']))echo $this -> vars['path']; ?>post<?php if(isset($this -> vars['post_id']))echo $this -> vars['post_id']; ?>/">გამოხმაურება</a><br />
<a href="<?php if(isset($this -> vars['path']))echo $this -> vars['path']; ?>topic<?php if(isset($this -> vars['topic_id']))echo $this -> vars['topic_id']; ?>/">თემა &quot;<?php if(isset($this -> vars['topic_name']))echo $this -> vars['topic_name']; ?>&quot;</a><br />
<a href="<?php if(isset($this -> vars['path']))echo $this -> vars['path']; ?>forum<?php if(isset($this -> vars['forum_id']))echo $this -> vars['forum_id']; ?>/">განყოფილება &quot;<?php if(isset($this -> vars['forum_name']))echo $this -> vars['forum_name']; ?>&quot;</a><br />