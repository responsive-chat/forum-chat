<?php /* გენერირებულია 13:37:19 11.10.2020 ფაილიდან /home/f0474738/domains/forumi.eu.org/public_html/sys/tpl_compile/umenu.page.tpl */ ?>
<?php switch(isset($this -> vars['block']) ? $this -> vars['block'] : null): ?>
<?php case 'index': ?>

<?php if(isset($this -> vars['phase_day']))echo $this -> vars['phase_day']; ?>, <?php if(isset($this -> vars['user_name']) && (bool)$this -> vars['user_name']): ?><?php if(isset($this -> vars['user_name']))echo $this -> vars['user_name']; ?><?php endif; ?><?php if(!isset($this -> vars['user_name']) || !(bool)$this -> vars['user_name']): ?><?php if(isset($this -> vars['user_nick']))echo $this -> vars['user_nick']; ?><?php endif; ?><br />
<br />
&raquo; ჩემი <a href="<?php if(isset($this -> vars['path']))echo $this -> vars['path']; ?>user<?php if(isset($this -> vars['user_id']))echo $this -> vars['user_id']; ?>/topics/">თემები</a> / <a href="<?php if(isset($this -> vars['path']))echo $this -> vars['path']; ?>user<?php if(isset($this -> vars['user_id']))echo $this -> vars['user_id']; ?>/posts/">პოსტები</a> / <a href="<?php if(isset($this -> vars['path']))echo $this -> vars['path']; ?>umenu.php?mode=bookmarks">ჩანიშნული</a> (<?php if(isset($this -> vars['count_bookmarks']))echo $this -> vars['count_bookmarks']; ?>)<br />
&raquo; <a href="<?php if(isset($this -> vars['path']))echo $this -> vars['path']; ?>umenu.php?mode=info">ანკეტა</a><br />
&raquo; <a href="<?php if(isset($this -> vars['path']))echo $this -> vars['path']; ?>umenu.php?mode=set">პარამეტრები</a><br />
&raquo; <a href="<?php if(isset($this -> vars['path']))echo $this -> vars['path']; ?>umenu.php?mode=private">პირადი ფოსტა</a><br />
&raquo; <a href="<?php if(isset($this -> vars['path']))echo $this -> vars['path']; ?>umenu.php?mode=profile">პაროლის შეცვლა</a><br />
<br />
<i><?php if(isset($this -> vars['rand_expression']))echo $this -> vars['rand_expression']; ?></i><br />
<br />
&raquo; <a href="<?php if(isset($this -> vars['path']))echo $this -> vars['path']; ?>login.php?mode=exit">გასვლა</a><br />

<?php break; ?>


<?php case 'answers_posts': ?>

<?php if (!empty($this -> vars['answers'])): ?>
		<?php for($_cycles_1_c = count($this -> vars['answers']), $_cycles_1_i = 0; $_cycles_1_i < $_cycles_1_c; $_cycles_1_i ++): ?>
	<?php $_cycles_1 = $this -> vars['answers'][$_cycles_1_i]; ?>

<div class="unit"><i><?php if(isset($_cycles_1['i']))echo $_cycles_1['i']; ?>.</i> <b><?php if(isset($_cycles_1['answer_user']))echo $_cycles_1['answer_user']; ?></b> პასუხი თემაში "<a href="<?php if(isset($this -> vars['path']))echo $this -> vars['path']; ?>topic<?php if(isset($_cycles_1['tid']))echo $_cycles_1['tid']; ?>/"><i><?php if(isset($_cycles_1['topic_name']))echo $_cycles_1['topic_name']; ?></i></a>" <?php if(isset($_cycles_1['date']))echo $_cycles_1['date']; ?><br />
<a href="<?php if(isset($this -> vars['path']))echo $this -> vars['path']; ?>post<?php if(isset($_cycles_1['answer_pid']))echo $_cycles_1['answer_pid']; ?>/">იხილეთ პასუხი</a></div>		<?php endfor; ?>
<?php endif; ?>
<?php if(!isset($this -> vars['answers']) || !(bool)$this -> vars['answers']): ?>
პასუხი არ არის.<br /><?php endif; ?>

<?php break; ?>


<?php case 'set': ?>

<form action="<?php if(isset($this -> vars['path']))echo $this -> vars['path']; ?>umenu.php?mode=set&<?php if(isset($this -> vars['rand']))echo $this -> vars['rand']; ?>" method="post"><input type="hidden" name="save" value="1"/>
თემები თითო გვერძზე: <br />
<input type="text" name="onpage_topics" value="<?php if(isset($this -> vars['set_onpage_topics']))echo $this -> vars['set_onpage_topics']; ?>" size="4" maxlength="4"/><br />
შეტყობინებები თითო გვერძზე: <br />
<input type="text" name="onpage_posts" value="<?php if(isset($this -> vars['set_onpage_posts']))echo $this -> vars['set_onpage_posts']; ?>" size="4" maxlength="4"/><br />
მიმდინარე დრო: <br />
<select name="time_shift">
<?php if (!empty($this -> vars['times'])): ?>
		<?php for($_cycles_2_c = count($this -> vars['times']), $_cycles_2_i = 0; $_cycles_2_i < $_cycles_2_c; $_cycles_2_i ++): ?>
	<?php $_cycles_2 = $this -> vars['times'][$_cycles_2_i]; ?>

<option value="<?php if(isset($_cycles_2['shift']))echo $_cycles_2['shift']; ?>"<?php if(isset($_cycles_2['selected']))echo $_cycles_2['selected']; ?>><?php if(isset($_cycles_2['time']))echo $_cycles_2['time']; ?> (<?php if(isset($_cycles_2['shift']))echo $_cycles_2['shift']; ?>)</option>		<?php endfor; ?>
<?php endif; ?>
</select><br />
<label><input type="checkbox" name="fast_post" value="1"<?php if(isset($this -> vars['set_fast_post']) && $this -> vars['set_fast_post'] === true): ?> checked="checked"<?php endif; ?>/>სწრაფი პასუხის ველის ჩვენება</label><br />
<input type="submit" value="შენახვა"/><br />
</form>

<?php break; ?>


<?php case 'profile': ?>

<form action="<?php if(isset($this -> vars['path']))echo $this -> vars['path']; ?>umenu.php?mode=profile&<?php if(isset($this -> vars['rand']))echo $this -> vars['rand']; ?>" method="post"><input type="hidden" name="save" value="1"/>
მიმდინარე პაროლი: <br />
<input type="password" name="pass"/><br />
შეიყვანეთ ახალი პაროლი: <br />
<input type="password" name="npass"/><br />
გაიმეორეთ ახალი პაროლი: <br />
<input type="password" name="npass2"/><br />
<input type="submit" value="შენახვა"/><br />
</form>

<?php break; ?>


<?php case 'info': ?>

<form action="<?php if(isset($this -> vars['path']))echo $this -> vars['path']; ?>umenu.php?mode=info&<?php if(isset($this -> vars['rand']))echo $this -> vars['rand']; ?>" method="post"><input type="hidden" name="save" value="1"/>
ნამდვილი სახელი: <br />
<input type="text" name="name" value="<?php if(isset($this -> vars['user_info_name']))echo $this -> vars['user_info_name']; ?>"/><br />
დაბადების თარიღი: <br />
<input type="text" name="birthday" value="<?php if(isset($this -> vars['user_info_birthday']))echo $this -> vars['user_info_birthday']; ?>"/><br />
მდებარეობა: <br />
<input type="text" name="city" value="<?php if(isset($this -> vars['user_info_city']))echo $this -> vars['user_info_city']; ?>"/><br />
ელ. ფოსტა: <br />
<input type="text" name="email" value="<?php if(isset($this -> vars['user_info_email']))echo $this -> vars['user_info_email']; ?>"/><br />
ტელ. ნომერი: <br />
<input type="text" name="tel" value="<?php if(isset($this -> vars['user_info_tel']))echo $this -> vars['user_info_tel']; ?>"/><br />
ვებსაიტის ბმული: <br />
<input type="text" name="site" value="<?php if(isset($this -> vars['user_info_site']))echo $this -> vars['user_info_site']; ?>"/><br />
ფოტო ავატარის ბმული: <br />
<input type="text" name="avatar" value="<?php if(isset($this -> vars['user_info_avatar']))echo $this -> vars['user_info_avatar']; ?>"/><br />
ინტერესები: <br />
<input type="text" name="interest" value="<?php if(isset($this -> vars['user_info_interest']))echo $this -> vars['user_info_interest']; ?>"/><br />
ჩემს შესახებ: <br />
<input type="text" name="about" value="<?php if(isset($this -> vars['user_info_about']))echo $this -> vars['user_info_about']; ?>"/><br />
ჩემი სქესი: <br />
<select name="sex">
<option value="0"<?php if(isset($this -> vars['user_info_sex']) && $this -> vars['user_info_sex'] == 0): ?> selected="selected"<?php endif; ?>>მდედრობითი</option>
<option value="1"<?php if(isset($this -> vars['user_info_sex']) && $this -> vars['user_info_sex'] == 1): ?> selected="selected"<?php endif; ?>>მამრობითი</option>
</select><br />
<input type="submit" value="შენახვა"/><br />
</form>

<?php break; ?>


<?php case 'private': ?>

<?php if (!empty($this -> vars['contacts'])): ?>
		<?php for($_cycles_3_c = count($this -> vars['contacts']), $_cycles_3_i = 0; $_cycles_3_i < $_cycles_3_c; $_cycles_3_i ++): ?>
	<?php $_cycles_3 = $this -> vars['contacts'][$_cycles_3_i]; ?>

<div class="unit"><i>#<?php if(isset($_cycles_3['i']))echo $_cycles_3['i']; ?>.</i> <a href="<?php if(isset($this -> vars['path']))echo $this -> vars['path']; ?>umenu.php?mode=private&act=user&id=<?php if(isset($_cycles_3['user_id']))echo $_cycles_3['user_id']; ?>"><?php if(isset($_cycles_3['user_nick']))echo $_cycles_3['user_nick']; ?></a> (<?php if(isset($_cycles_3['count_messages']))echo $_cycles_3['count_messages']; ?><?php if(isset($_cycles_3['count_new_messages']))echo $_cycles_3['count_new_messages']; ?>)<br />
<?php if(isset($_cycles_3['date']))echo $_cycles_3['date']; ?></div>		<?php endfor; ?>
<?php endif; ?>
<?php if(isset($this -> vars['pagebar']))echo $this -> vars['pagebar']; ?>
<?php if(!isset($this -> vars['contacts']) || !(bool)$this -> vars['contacts']): ?>
კონტაქტები არაა.<br /><?php endif; ?>
<form action="<?php if(isset($this -> vars['path']))echo $this -> vars['path']; ?>umenu.php?mode=private&adduser&<?php if(isset($this -> vars['rand']))echo $this -> vars['rand']; ?>" method="post" class="unit"><input type="hidden" name="add" value="1"/>
მეტსახელი: <br />
<input type="text" name="nick" maxlength="40"/><br />
<input type="submit" value="წერილის მიწერა">
</form>
<form action="<?php if(isset($this -> vars['path']))echo $this -> vars['path']; ?>umenu.php?mode=private&act=remove" method="post" class="unit">
<input type="submit" value="კონტაქტების ამოშლა"/>
</form>

<?php break; ?>


<?php case 'private_user': ?>

მიმოწერის ისტორია <a href="<?php if(isset($this -> vars['path']))echo $this -> vars['path']; ?>user<?php if(isset($this -> vars['user']['id']))echo $this -> vars['user']['id']; ?>/"><?php if(isset($this -> vars['user']['nick']))echo $this -> vars['user']['nick']; ?></a><br />
<?php if (!empty($this -> vars['messages'])): ?>
		<?php for($_cycles_4_c = count($this -> vars['messages']), $_cycles_4_i = 0; $_cycles_4_i < $_cycles_4_c; $_cycles_4_i ++): ?>
	<?php $_cycles_4 = $this -> vars['messages'][$_cycles_4_i]; ?>

<div class="unit" id="message-<?php if(isset($_cycles_4['id']))echo $_cycles_4['id']; ?>"><i>#<?php if(isset($_cycles_4['i']))echo $_cycles_4['i']; ?>.</i> <b><?php if(isset($_cycles_4['who']))echo $_cycles_4['who']; ?></b> / <?php if(isset($_cycles_4['date']))echo $_cycles_4['date']; ?><br />
<?php if(isset($_cycles_4['text']))echo $_cycles_4['text']; ?><br />
<?php if(isset($this -> vars['user_level']) && isset($this -> vars['user_moderator']) && $this -> vars['user_level'] >= $this -> vars['user_moderator']): ?><span class="manage"><?php if(isset($_cycles_4['ip']))echo $_cycles_4['ip']; ?> - <?php if(isset($_cycles_4['ua']))echo $_cycles_4['ua']; ?></span><?php endif; ?></div>		<?php endfor; ?>
<?php endif; ?>
<?php if(isset($this -> vars['pagebar']))echo $this -> vars['pagebar']; ?>
<?php if(!isset($this -> vars['messages']) || !(bool)$this -> vars['messages']): ?>
წერილები არაა.<br /><?php endif; ?>
<form action="<?php if(isset($this -> vars['path']))echo $this -> vars['path']; ?>umenu.php?mode=private&act=user&id=<?php if(isset($this -> vars['user']['id']))echo $this -> vars['user']['id']; ?>&add&<?php if(isset($this -> vars['rand']))echo $this -> vars['rand']; ?>" method="post" class="unit"><input type="hidden" name="add" value="1"/>
შეტყობინება: <br />
<textarea name="post" cols="40" rows="8" onkeypress="return makeGeo(this,event);"></textarea><br />
<input type="submit" value="დამატება"/>
<input checked="checked" id="geoKeys" type="checkbox" /><b>ქართული კლავიატურა</b><br>
</form>
<form action="<?php if(isset($this -> vars['path']))echo $this -> vars['path']; ?>umenu.php?mode=private&act=delete" method="post" class="unit">
<input type="submit" value="გასუფთავება"/>
</form>
&raquo; <a href="<?php if(isset($this -> vars['path']))echo $this -> vars['path']; ?>index.php?mode=bbcodes">BB კოდები</a> / <a href="<?php if(isset($this -> vars['path']))echo $this -> vars['path']; ?>index.php?mode=smiles">სიცილაკები</a><br />
<a href="<?php if(isset($this -> vars['path']))echo $this -> vars['path']; ?>umenu.php?mode=private">პირადი ფოსტა</a><br />

<?php break; ?>


<?php case 'bookmarks': ?>

გამოჩდეს: <?php if(isset($this -> vars['type']) && $this -> vars['type'] == 'new'): ?><a href="<?php if(isset($this -> vars['path']))echo $this -> vars['path']; ?>umenu.php?mode=bookmarks&type=all">ყველა</a> / ახალი შეტყობინებები<?php endif; ?><?php if(isset($this -> vars['type']) && $this -> vars['type'] == 'all'): ?>ყველა / <a href="<?php if(isset($this -> vars['path']))echo $this -> vars['path']; ?>umenu.php?mode=bookmarks&type=new">ახალი შეტყობინებები</a><?php endif; ?><br />
<?php if (!empty($this -> vars['topics'])): ?>
		<?php for($_cycles_5_c = count($this -> vars['topics']), $_cycles_5_i = 0; $_cycles_5_i < $_cycles_5_c; $_cycles_5_i ++): ?>
	<?php $_cycles_5 = $this -> vars['topics'][$_cycles_5_i]; ?>

<div class="unit"><i>#<?php if(isset($_cycles_5['i']))echo $_cycles_5['i']; ?>.</i> <a href="<?php if(isset($this -> vars['path']))echo $this -> vars['path']; ?>topic<?php if(isset($_cycles_5['id']))echo $_cycles_5['id']; ?>/"><?php if(isset($_cycles_5['name']))echo $_cycles_5['name']; ?></a> (<?php if(isset($_cycles_5['count_posts']))echo $_cycles_5['count_posts']; ?>)<br />
<?php if(isset($_cycles_5['user']))echo $_cycles_5['user']; ?> / <?php if(isset($_cycles_5['date']))echo $_cycles_5['date']; ?><br />
<a href="<?php if(isset($this -> vars['path']))echo $this -> vars['path']; ?>umenu.php?mode=bookmarks&id=<?php if(isset($_cycles_5['id']))echo $_cycles_5['id']; ?>">სანიშნიდან წაშლა</a>
</div>		<?php endfor; ?>
<?php endif; ?>
<?php if(isset($this -> vars['pagebar']))echo $this -> vars['pagebar']; ?>
<?php if(!isset($this -> vars['topics']) || !(bool)$this -> vars['topics']): ?>
თემები არ მოიძებნა.<br /><?php endif; ?>

<?php break; ?>
<?php endswitch; ?>