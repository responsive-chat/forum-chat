<?php /* გენერირებულია 13:35:07 02.11.2020 ფაილიდან /home/f0474738/domains/forumi.eu.org/public_html/sys/tpl_compile/header.tpl */ ?>
<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="ru">
<head>
 <meta http-equiv="Content-Type" content="application/xhtml+xml; charset=utf-8" />
 <link rel="stylesheet" href="<?php if(isset($this -> vars['path']))echo $this -> vars['path']; ?>style/style.css" type="text/css" />
 <link rel="icon" href="/favicon.ico" type="image/x-icon" />
 <title><?php if(isset($this -> vars['page_title']))echo $this -> vars['page_title']; ?></title>
 <meta name="description" content="ქართული მაღალინტელექტუალური ინტერნეტ ფორუმი.">
 <meta name="viewport" content="width=device-width, initial-scale=1.0">
 <script src="http://forumi.eu.org/GeoKBD.js" mce_src="GeoKBD.js" type="text/javascript"></script>
</head>
<body>
<a href="/index.php"><img src="/logo.png"></a>
<br>
<div class="head"><?php if(isset($this -> vars['page_sec']))echo $this -> vars['page_sec']; ?></div>