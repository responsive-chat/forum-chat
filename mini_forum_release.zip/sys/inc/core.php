<?php


define('MT', microtime(true));

ini_set('session.use_trans_sid', true);
ini_set('register_globals', false);
ini_set('magic_quotes_gpc', false);
ini_set('magic_quotes_runtime', false);
ini_set('magic_quotes_sybase', false);
date_default_timezone_set('Asia/Tbilisi');
setlocale(LC_ALL, 'ru_RU.utf8');

session_name('SESSION');
if(!preg_match('~^[a-z0-9]{32}$~', $_COOKIE[session_name()]))
	{
	$new_sess_id = md5(rand(1000, 999999).MT);
	setcookie(session_name(), $new_sess_id);
	$_COOKIE[session_name] = $new_sess_id;
	session_id($new_sess_id);

	unset($new_sess_id);
	}
session_start();





{

if(!file_exists('sys/cfg/allcfg.ini'))die('კონფიგურაციის ფაილი არ მოიძებნა');
if(filesize('sys/cfg/allcfg.ini') == 0)die('სკრიპტი არ არის დაინსტალირებული');
$allcfg = parse_ini_file('sys/cfg/allcfg.ini', true);

}



define('ROOT_DIR', $allcfg['other']['root']);

	define('SYSTEM_DIR', ROOT_DIR.'sys/');
		define('INCLUDES_DIR', SYSTEM_DIR.'inc/');
		define('CONFIG_DIR', SYSTEM_DIR.'cfg/');
		define('TEMPLATES_DIR', SYSTEM_DIR.'tpl/');
		define('TEMPLATES_COMPILED_DIR', SYSTEM_DIR.'tpl_compile/');


if($_SERVER['REMOTE_ADDR'] == '127.0.0.1')
	{
	define('LOCALHOST', true);
	error_reporting(E_ALL);
	set_time_limit(30);
	}
else
	{
	define('LOCALHOST', false);
	error_reporting(0);
	@set_time_limit(10);
	}





{
		function fatal_error($msg = 'უცნობი შეცდომა')
	{
	endclean();
	header('Content-Type: text/html;charset=utf-8');
	echo '<html><head><title>სისტემური შეცდომა</title></head><body>';
	echo '<b>'.date('G:i:s d.m.Y').'</b> : '.$msg;
	echo '</body></html>';
	exit;
	}

		function d($var, $exit = true, $return = false)
	{
	if(!$return)
		{
		Dumphper::dump($var);

		if($exit)exit;
		}

	ob_start();
	Dumphper::dump($var);
	$result = ob_get_contents();
	ob_end_clean();

	return $result;
	}

		function endclean()
	{
			while(ob_get_level())
		{
		ob_end_clean();
		}
	header('Content-Encoding: none', true);
	}

		function ad()
	{
	echo '<b>GET('.count($_GET, COUNT_RECURSIVE).')</b><br />';
	d($_GET, false);
	echo '<b>POST('.count($_POST, COUNT_RECURSIVE).')</b><br />';
	d($_POST, false);
	echo '<b>COOKIE('.count($_COOKIE, COUNT_RECURSIVE).')</b><br />';
	d($_COOKIE, false);
	echo '<b>SESSION('.count($_SESSION, COUNT_RECURSIVE).')</b><br />';
	d($_SESSION, false);
	echo '<b>FILES('.count($_FILES, COUNT_RECURSIVE).')</b><br />';
	d($_FILES, false);
	exit;
	}

		function myErrorHandler($errno, $errstr, $errfile, $errline)
	{
	if(LOCALHOST)err('<b>'.$errstr.'</b><br />ფაილში <i>'.$errfile.'</i> ხაზზე <i>'.$errline.'</i>');
	}

		function __autoload($class_name)
	{
	if(!file_exists(INCLUDES_DIR.$class_name.'.class.php'))fatal_error('კლასი არ არის ნაპოვნი '.$class_name);
	require_once INCLUDES_DIR.$class_name.'.class.php';
	}


require INCLUDES_DIR.'functions.php';

set_error_handler('myErrorHandler');







}



{

if(LOCALHOST)
	{
	$db = new SW($allcfg['db_localhost']['user'], $allcfg['db_localhost']['password'], $allcfg['db_localhost']['host'], $allcfg['db_localhost']['database'], $allcfg['db_localhost']['prefix'], true);
	define('PREF', $allcfg['db_localhost']['prefix']);
	}
else
	{
	$db = new SW($allcfg['db']['user'], $allcfg['db']['password'], $allcfg['db']['host'], $allcfg['db']['database'], $allcfg['db']['prefix']);
	define('PREF', $allcfg['db']['prefix']);
	}

}





{


$cfg = $cfg_modules = array();
		while($param = $db -> fetch('SELECT * FROM `config`'))
	{
	$cfg[$param['name']] = $param['value'];
	}

unset($param);



define('PATH', $cfg['path']);
define('DOMAIN', (!empty($cfg['domain']) ? $cfg['domain'] : $_SERVER['HTTP_HOST']));
if(DOMAIN != $_SERVER['HTTP_HOST'])locate('http://'.DOMAIN);



if(isset($_SERVER['HTTP_X_FORWARDED_FOR']) && preg_match('|^[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}$|', $_SERVER['HTTP_X_FORWARDED_FOR']))define('MY_IP', str($_SERVER['HTTP_X_FORWARDED_FOR']));
elseif(isset($_SERVER['HTTP_CLIENT_IP']) && preg_match('|^[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}$|', $_SERVER['HTTP_CLIENT_IP']))define('MY_IP', str($_SERVER['HTTP_CLIENT_IP']));
else define('MY_IP', preg_replace('|[^0-9.]|','', $_SERVER['REMOTE_ADDR']));

define('MY_INT_IP', ip2int(MY_IP));

if (isset($_SERVER['HTTP_X_OPERAMINI_PHONE_UA']))define('MY_UA', 'Opera Mini :'.str($_SERVER['HTTP_X_OPERAMINI_PHONE_UA']));
elseif(isset($_SERVER['HTTP_USER_AGENT']))define('MY_UA', str($_SERVER['HTTP_USER_AGENT']));
else define('MY_UA', 'Unknow');

define('MY_SHORT_UA', strtok(MY_UA,' '));

define('MY_URI', (!empty($_SERVER['REQUEST_URI']) ? str($_SERVER['REQUEST_URI']) : null));
define('MY_REFERER', (!empty($_SERVER['HTTP_REFERER']) ? str($_SERVER['HTTP_REFERER']) : null));

define('TIME', time());
define('TIME_TODAY', strtotime(date('j F Y')));

if(stripos(MY_UA,'windows') !== false || stripos(MY_UA,'linux') !== false || stripos(MY_UA,'bsd') !== false || stripos(MY_UA,'x11') !== false || stripos(MY_UA,'unix') !== false || stripos(MY_UA,'macos') !== false || stripos(MY_UA,'macintosh') !== false)define('MY_WEB', true);
else define('MY_WEB', false);

define('MY_ACCEPT', (!empty($_SERVER['HTTP_ACCEPT']) ? str($_SERVER['HTTP_ACCEPT']) : null));

if(!empty($_SERVER['HTTP_ACCEPT_ENCODING']))define('MY_ACCEPT_ENCODING', strtolower($_SERVER['HTTP_ACCEPT_ENCODING']));
elseif(!empty($_SERVER['HTTP_TE']))define('MY_ACCEPT_ENCODING', strtolower($_SERVER['HTTP_TE']));
else define('MY_ACCEPT_ENCODING', null);

define('SCRIPT_NAME',$_SERVER['SCRIPT_NAME']);

define('ID', !empty($_GET['id']) ? int($_GET['id']) : 0);
define('MODE', !empty($_GET['mode']) ? str($_GET['mode']) : null);
define('ACT', !empty($_GET['act']) ? str($_GET['act']) : null);
define('SACT', !empty($_GET['sact']) ? str($_GET['sact']) : null);
define('RAND', rand(100000,999999));
define('EOL', "\r\n");


}







require_once INCLUDES_DIR.'usr.php';


require_once INCLUDES_DIR.'my_functions.php';


?>