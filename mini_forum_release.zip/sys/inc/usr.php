<?php



define('SOMETEMPLATE_DEFAULT_DIR', TEMPLATES_DIR);
define('SOMETEMPLATE_DEFAULT_COMPILED_DIR', TEMPLATES_COMPILED_DIR);
define('SOMETEMPLATE_DEFAULT_EXT', 'tpl');

$template = new SomeTemplate;






$template -> path = PATH;
$template -> rand = RAND;
$template -> domain = DOMAIN;

$template -> user_level = 0;


		function show_title($title = 'უბრალოდ ფორუმი', $sec = null)
	{
	global $template, $count_answer_to_my_posts, $db, $userdata;
	$page_title = $title;
	$page_sec = (!empty($sec)) ? $sec : $title;

	
	

	require_once INCLUDES_DIR.'head.php';

	}



		function show_foot()
	{
	global $template, $count_answer_to_my_posts, $db, $userdata;
	
	

	

	require_once INCLUDES_DIR.'foot.php';
	}


$userdata = array('id' => 0, 'level' => 0, 'name' => null, 'nick' => null, 'info_name' => null, 'set_fast_post' => 0);


if(!isset($_SESSION['userdata']) && !empty($_COOKIE['user_login']) && !empty($_COOKIE['user_password']))
	{

	$password = get_int_hash(base64_decode($_COOKIE['user_password']));
	$login = str($_COOKIE['user_login']);

	if($db -> one("SELECT COUNT(*) FROM `users` WHERE `login` = '$login' AND `password` = '$password'"))
		{
		$_SESSION['userdata'] = array('login' => $_COOKIE['user_login'], 'password' => $password);
		$userdata = $db -> fetch("SELECT * FROM `users` WHERE `login` = '{$_COOKIE['user_login']}' AND `password` = '$password'");
		define('USER_AUTH', true);
		
		xcookie('user_login', $_COOKIE['user_login']);
		xcookie('user_password', $_COOKIE['user_password']);
		msg('თქვენ წარმატებით გაიარეთ ავტორიზაცია');
		}
	else
		{
		xcookie('user_login');
		xcookie('user_password');
		}

	}
elseif(isset($_SESSION['userdata']['login']) && isset($_SESSION['userdata']['password']))
	{
	if($db -> one("SELECT COUNT(*) FROM `users` WHERE `login` = '{$_SESSION['userdata']['login']}' AND `password` = '{$_SESSION['userdata']['password']}'"))
		{
		$userdata = $db -> fetch("SELECT * FROM `users` WHERE `login` = '{$_SESSION['userdata']['login']}' AND `password` = '{$_SESSION['userdata']['password']}'");
		define('USER_AUTH', true);
		}
	else
		{
		unset($_SESSION['userdata']);
		}
	}

define('USER_LEVEL', (int)$userdata['level']);
define('USER_ID', (int)$userdata['id']);

$levels = array
	(
	0 => array('USER_GUEST', 'უბრალო სტატუსი'),
	1 => array('USER_JUST', 'მომხმარებელი'),
	2 => array('USER_MODERATOR', 'მოდერატორი'),
	3 => array('USER_ADMIN', 'ადმინისტრატორი')
	);



define('PAGE', !empty($_GET['page']) && int($_GET['page']) > 0 ? int($_GET['page']) : 1);
define('ONPAGE_TOPICS', !empty($userdata['set_onpage_topics']) ? $userdata['set_onpage_topics'] : $cfg['onpage_topics']);
define('ONPAGE_POSTS', !empty($userdata['set_onpage_posts']) ? $userdata['set_onpage_posts'] : $cfg['onpage_posts']);
define('START_TOPICS', (PAGE - 1) * ONPAGE_TOPICS);
define('START_POSTS', (PAGE - 1) * ONPAGE_POSTS);






		foreach($levels as $level => $info)
	{
	define($info[0], $level);
	$template -> assign(strtolower($info[0]), $level);
	}

$template -> user_level = USER_LEVEL;

if(!defined('USER_AUTH'))define('USER_AUTH', false);
$template -> user_auth = USER_AUTH;


if(USER_AUTH)
	{


	$template -> user_nick = $userdata['nick'];
	$template -> user_name = $userdata['info_name'];

	if($userdata['active'] != 0 || !empty($userdata['date_last_visit']))
		{
		$db -> sql("UPDATE `users` SET `date_last_visit` = '".TIME."', `ip` = '".MY_INT_IP."', `ua` = '".MY_UA."', `page` = '".MY_URI."' WHERE `id` = '".USER_ID."'");
		}

	if($userdata['active'] == 0 && (substr(MY_URI,0 , strlen(PATH.'index.php?mode=deactive')) != PATH.'index.php?mode=deactive' && substr(MY_URI,0 , strlen(PATH.'login.php') != PATH.'login.php')))
		{
		locate(PATH.'index.php?mode=deactive');
		}

	}

define('TIME_SHIFT', (!empty($userdata['set_time_shift']) ? $userdata['set_time_shift'] : $cfg['time_shift']));

		function only_reg($min_level = 1)
	{
	if(!USER_AUTH || USER_LEVEL < $min_level)
		{
		locate(PATH.'login.php?mode=enter&referer='.rawurlencode(MY_URI));
		}
	}

		function only_unreg()
	{
	if(USER_AUTH)locate(PATH.'index.php');
	}


?>