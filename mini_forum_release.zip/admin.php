<?php

	require 'sys/inc/core.php';

if(USER_LEVEL < USER_ADMIN)
	{
	$db -> sql("INSERT INTO `users_punish` SET `user_id` = '".USER_ID."', `punished_id` = '1', `date` = '".TIME."', `to_date` = '".(TIME + 43200)."', `comment` = 'თქვენ არაფერი გესაქმებათ სამართავ პანელში', 'ip' = '0', 'ua' = 'Auto'");
	err('თქვენთვის აქ შესვლა აკრძალულია!', PATH.'inex.php');

	
	exit;
	}

		switch(MODE)
	{
	default:
	
	{

	show_title('სამართავი პანელი');

	$template -> block = 'index';

	$template -> count_deactive_users = $db -> one("SELECT COUNT(*) FROM `users` WHERE `active` = '0' AND `date_last_visit` = '0'");

	}
	break;
	
	case 'set':
	
	{

	show_title('სამართავი პანელი', 'პარამეტრები');

	if(isset($_GET['save']) && postval('save', 1))
		{
		check_fields(PATH.'admin.php?mode=set&'.RAND, array(array('index_title', 'not null'), array('path', 'not null'), array('onpage_topics', 'not null'), array('onpage_posts', 'not null'), array('time_antispam_topics'), array('time_antispam_posts'), array('time_antispam_private'), array('time_edit_post'), array('maxlen_post', 'not null'), array('maxlen_short_post', 'not null'), array('time_shift', 'values' => range(-12, 12))));

		$newcfg['index_title'] = str($_POST['index_title']);
		$newcfg['path'] = trim($_POST['path']);
		$newcfg['domain'] = trim($_POST['domain']);
		$newcfg['onpage_topics'] = int($_POST['onpage_topics']);
		$newcfg['onpage_posts'] = int($_POST['onpage_posts']);
		$newcfg['time_antispam_topics'] = int($_POST['time_antispam_topics']);
		$newcfg['time_antispam_posts'] = int($_POST['time_antispam_posts']);
		$newcfg['time_antispam_private'] = int($_POST['time_antispam_private']);
		$newcfg['time_edit_post'] = int($_POST['time_edit_post']);
		$newcfg['time_silence'] = int($_POST['time_silence']);
		$newcfg['maxlen_post'] = int($_POST['maxlen_post']);
		$newcfg['maxlen_short_post'] = int($_POST['maxlen_short_post']);
		$newcfg['time_shift'] = $_POST['time_shift'];

		$newcfg['users_active'] = (int)!postval('users_active', 1, false);
		$newcfg['mod_reply_to'] = postval('mod_reply_to', 1, false);
		$newcfg['open_reg'] = postval('open_reg', 1, false);


				foreach($newcfg as $key => $val)
			{
			$db -> sql("UPDATE `config` SET `value` = '$val' WHERE `name` = '$key'");
			}

		msg('პარამეტრები განახლდა', PATH.'index.php');

		}


	$cfg['users_active'] = !(bool)$cfg['users_active'];
	$cfg['mod_reply_to'] = (bool)$cfg['mod_reply_to'];
	$cfg['open_reg'] = (bool)$cfg['open_reg'];

	$template -> cfg = $cfg;

	$template_times = array();
			for($i = -12;$i <= 12;$i ++)
		{
		$template_time = array('time' => date('d.m G:i', TIME + ($i * 3600)), 'shift' => $i);
		if($cfg['time_shift'] == $i)$template_time['selected'] = ' selected="selected"';

		$template_times[] = $template_time;
		}

	$template -> assign('times', $template_times);

	$template -> block = 'set';

	}
	break;
	
	case 'new_users':
	
	{

	show_title('სამართავი პანელი', 'წევრების მოდერაცია');

	if(!empty($_GET['uid']) && in_array(ACT, array('active', 'deactive')))
		{
		$uid = int($_GET['uid']);
		if($db -> one("SELECT COUNT(*) FROM `users` WHERE `id` = '$uid' AND `active` = '0' AND `date_last_visit` = '0'") == 0)
			{
			locate(PATH.'admin.php?mode=new_users');
			}

		if(ACT == 'active')
			{
			if($db -> sql("UPDATE `users` SET `active` = '1' WHERE `id` = '$uid'"))
				{
				msg('მომხმარებელი გააქტიურდა', PATH.'admin.php?mode=new_users');
				}
			else
				{
				err('შეცდომა', PATH.'admin.php?mode=new_users');
				}
			}
		else
			{
			if($db -> sql("UPDATE `users` SET `date_last_visit` = '1' WHERE `id` = '$uid'"))
				{
				msg('მომხმარებელი დეაქტივირებულია', PATH.'admin.php?mode=new_users');
				}
			else
				{
				err('შეცდომა', PATH.'admin.php?mode=new_users');
				}
			}

		}

	$count_users = $db -> one("SELECT COUNT(*) FROM `users` WHERE `active` = '0' AND `date_last_visit` = '0'");

	if($count_users > 0)
		{
		$template -> count_users = $count_users;

		check_page($count_users, PATH.'admin.php?mode=new_users&upage={$page}', ONPAGE_TOPICS);

		$template_users = array();

		$i = START_TOPICS;


				while($user = $db -> fetch("SELECT `nick`, `id`, `date_reg`, `ua`, `ip` FROM `users` WHERE `active` = '0' AND `date_last_visit` = '0' ORDER BY `date_reg` DESC LIMIT ".START_TOPICS.", ".ONPAGE_TOPICS))
			{
			$i ++;

			$template_user = array('i' => $i, 'id' => $user['id'], 'nick' => $user['nick'], 'date_reg' => xdate($user['date_reg']), 'ip' => long2ip($user['ip']), 'ua' => $user['ua']);


			$template_users[] = $template_user;
			}

		$template -> assign('users', $template_users);

		pagebar($str, PAGE, PATH.'admin.php?mode=new_users&page={$page}');

		}

	$template -> block = 'new_users';


	}
	break;
	
	case 'mysql':
	
	{

	show_title('სამართავი პანელი', 'მონაცემთაბაზის მართვა');

	if(isset($_GET['execut']) && postval('execut', 1) && !empty($_POST['query']))
		{
		$query = trim($_POST['query']);

		$result = $db -> sql($query, false);

		
		if(postval('view_result', 1))
			{
			$template -> view_result = true;


			$template -> sql = str($query, null, true, false);
			$template -> view_sql = nl2br(str($query, null, true, false));


			
			if(is_string($result))
				{
				$template -> error = true;

				$template -> error_string = $result;

				}
			else
				{
				$result_view = $db -> allfetch($result);
				if(count($result_view) == 1 && count($result_view[0]) == 2)$result_view = $result_view[0][0];
				$template -> result = d($result_view, false, true);
				}
			}
		else
			{
			if(is_string($result))err('შეცდომა', PATH.'admin.php?mode=mysql&'.RAND);
			else msg('მოთხოვნა დასრულდა', PATH.'admin.php?mode=mysql&'.RAND);
			}

		}

	$template -> block = 'mysql';

	}
	break;
	
	case 'cache':
	
	{

	show_title('სამართავი პანელი', 'მონაცემების განახლება');

	if(isset($_GET['update']) && postval('update'))
		{

		
		if(postval('forums'))
			{
			if($db -> sql("UPDATE `forums` SET `count_topics` = (SELECT COUNT(*) FROM `topics` WHERE `fid` = `forums`.`id`), `count_posts` = (SELECT COUNT(*) FROM `posts` WHERE `fid` = `forums`.`id` AND (SELECT COUNT(*) FROM `topics` WHERE `topics`.`first_post` = `posts`.`id`) = 0)"))
				{
				msg('ფორუმის მონაცემები განახლდა');
				}
			}

		
		if(postval('topics'))
			{
			if($db -> sql("UPDATE `topics` SET `count_posts` = (SELECT COUNT(*) FROM `posts` WHERE `tid` = `topics`.`id` AND `id` != `topics`.`first_post`), `date` = (SELECT MIN(`date`) FROM `posts` WHERE `tid` = `topics`.`id`), `user_id` = (SELECT `user_id` FROM `posts` WHERE `tid` = `topics`.`id` ORDER BY `date` ASC LIMIT 0, 1), `last_date` = (SELECT MAX(`date`) FROM `posts` WHERE `tid` = `topics`.`id`), `last_user_id` = (SELECT `user_id` FROM `posts` WHERE `tid` = `topics`.`id` ORDER BY `date` DESC LIMIT 0, 1)"))
				{
				msg('თემების მონაცემები განახლდა');
				}

			
			$db -> sql("DELETE FROM `topics_views` WHERE (SELECT COUNT(*) FROM `users` WHERE `id` = `topics_views`.`user_id`) = 0 OR (SELECT COUNT(*) FROM `topics` WHERE `id` = `topics_views`.`tid`) = 0");

			
			$db -> sql("DELETE FROM `topics_bookmarks` WHERE (SELECT COUNT(*) FROM `users` WHERE `id` = `topics_bookmarks`.`user_id`) = 0 OR (SELECT COUNT(*) FROM `topics` WHERE `id` = `topics_bookmarks`.`tid`) = 0");

			
			$db -> sql("DELETE FROM `topics_logs` WHERE (SELECT COUNT(*) FROM `topics` WHERE `id` = `topics_logs`.`tid`) = 0");

			
			$topics = $db -> allfetch("SELECT `id` FROM `topics` WHERE `first_post` != '0' AND (SELECT COUNT(*) FROM `posts` WHERE `id` = `topics`.`first_post`) = 0", true);
			
			if(!empty($topics))$db -> sql("UPDATE `topics` SET `first_post` = '0' WHERE `id` IN (".implode(', ', $topics).")");

			}

		
		if(postval('posts'))
			{
			
			$db -> sql("DELETE FROM `posts_text` WHERE (SELECT COUNT(*) FROM `posts` WHERE `id` = `posts_text`.`pid`) = 0");

			
			$db -> sql("DELETE FROM `posts_answers` WHERE (SELECT COUNT(*) FROM `posts` WHERE `id` = `posts_answers`.`pid`) = 0 OR (SELECT COUNT(*) FROM `users` WHERE `id` = `posts_answers`.`user_id`) = 0 OR (SELECT COUNT(*) FROM `posts` WHERE `id` = `posts_answers`.`answer_pid`) = 0 OR (SELECT COUNT(*) FROM `topics` WHERE `id` = `posts_answers`.`tid`) = 0");

			
			$posts = $db -> allfetch("SELECT `id` FROM `posts` WHERE `answer_to` != '0' AND (SELECT COUNT(*) FROM `posts` AS `p` WHERE `p`.`id` = `posts`.`answer_to`) = 0", true);
			
			if(!empty($posts))$db -> sql("UPDATE `posts` SET `answer_to` = '0' WHERE `id` IN (".implode(', ', $posts).")");

			msg('გამოხმაურებების მონაცემები განახლდა');

			}

		
		$db -> sql("OPTIMIZE TABLE `".implode('`, `',($db -> allfetch("SHOW TABLES", true)))."`", false);

		locate(PATH.'index.php?'.RAND);

		}

	$template -> block = 'cache';

	}
	break;
	
	case 'sitemap':
	
	{

	if(generate_sitemap())msg('ფაილი განახლდა ('.xsize(filesize(CONFIG_DIR.'sitemap.xml')).')', PATH.'index.php');
	else err('შეცდომა', PATH.'index.php');

	}
	break;
	}

$template -> display('admin.page');

show_foot();


?>