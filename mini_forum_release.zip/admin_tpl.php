<?php



	require 'sys/inc/core.php';


unset($template);

restore_error_handler();

if(USER_LEVEL < USER_ADMIN)
	{
	$db -> sql("INSERT INTO `users_punish` SET `user_id` = '".USER_ID."', `punished_id` = '1', `date` = '".TIME."', `to_date` = '".(TIME + 43200)."', `comment` = 'თქვენ არაფერი გესაქმებათ სამართავ პანელში', 'ip' = '0', 'ua' = 'Auto'");
	err('თქვენთვის აქ შესვლა აკრძალულია!', PATH.'inex.php');

	
	exit;
	}

ob_start();

echo '<?xml version="1.0" encoding="utf-8"?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd"><html xmlns="http://www.w3.org/1999/xhtml" xml:lang="ru"><head> <meta http-equiv="Content-Type" content="application/xhtml+xml; charset=utf-8" /> <link rel="stylesheet" href="'.PATH.'style/style.css" type="text/css" /> <title>სამართავი პანელი: გვერდების მართვა</title> </head><body>';

		switch(MODE)
	{
	default:
	
	{

	echo '<div class="head">ფაილების ჩამონათვალი</div>';

	$tpl_files = glob(TEMPLATES_DIR.'/*.tpl');

	$count_files = count($tpl_files);
	if($count_files > 0)
		{

		check_page($count_files, PATH.'admin_tpl.php?page={$page}', ONPAGE_TOPICS);

		$end = PAGE * ONPAGE_TOPICS;
		$start = $end - ONPAGE_TOPICS;
		if($end > $count_files)$end = $count_files;

				for($i = $start;$i < $end;$i ++)
			{
			$tpl_file = basename($tpl_files[$i]);
			echo '<div class="unit"><i>#'.($i + 1).'.</i> <a href="'.PATH.'admin_tpl.php?mode=file&file='.rawurlencode($tpl_file).'"><b>'.$tpl_file.'</b></a> / '.xsize(filesize($tpl_files[$i])).'<br />';
			echo xdate(filemtime($tpl_files[$i])).'<br />';

			if(is_writable($tpl_files[$i]))echo '<a href="'.PATH.'admin_tpl.php?mode=file&file='.rawurlencode($tpl_file).'&act=del">ფაილის წაშლა</a>';
			else echo '<font color="red">ფაილში ჩაწერა აკრძალულია</font>';

			echo '</div>';
			}

		pagebar($str, PAGE, PATH.'admin_tpl.php?page={$page}', true);

		}
	else
		{
		echo 'ფაილები არაა<br />';
		}

	echo '&raquo; <a href="'.PATH.'admin_tpl.php?mode=new">შექმენით ახალი ფაილი</a><br />';

	}
	break;
	
	case 'new';
	
	{
	echo '<div class="head">ფაილის შექმნა</div>';

	if(is_writable(TEMPLATES_DIR))
		{

		if(isset($_GET['create']) && !empty($_POST['filename']) && postval('create'))
			{
			$filename = trim($_POST['filename']);

			if(preg_match('~^[A-Za-z0-9-_.]+$~', $filename))
				{
				if(!file_exists(TEMPLATES_DIR.$filename.'.tpl'))
					{
					if(file_write(TEMPLATES_DIR.$filename.'.tpl', 'w', ''))
						{
						echo '<font color="green">ფაილი '.$filename.'.tpl შეიქმნა <a href="'.PATH.'admin_tpl.php?mode=file&file='.rawurlencode($filename.'.tpl').'">&gt;&gt;</a></font>';
						if(!chmod(TEMPLATES_DIR.$filename.'.tpl', 0777))
							{
							echo '<font color="red">არ შგიძლიათ ფაილზე უფლებების მინიჭება</font><br />';
							}
						}
					else
						{
						echo '<font color="red">არ იქმნება ფაილი '.$filename.'.tpl</font><br />';
						}
					}
				else
					{
					echo '<font color="red">ფაილი '.$filename.'.tpl უკვე არსებობს</font><br />';
					}
				}
			else
				{
				echo '<font color="red">გაუგებარია ფაილის სახელი</font><br />';
				}

			}

		echo '<form action="'.PATH.'admin_tpl.php?mode=new&create&'.RAND.'" method="post" class="unit"><input type="hidden" name="create" value="1"/>';
		echo 'ფაილის სახელი (გარეშე .tpl, [A-z0-9_-.]) : <br />';
		echo '<input name="filename" type="text"/><br />';
		echo '<input type="submit" value="შექმნა"/>';
		echo '</form>';

		}
	else
		{
		echo '<font color="red">ჩაწერა შეუძლებელია</font><br />';
		echo 'საქაღალდეში '.str_delimpos(TEMPLATES_DIR, ROOT_DIR).' უფლებები შეზღუდულია '.xchmod(TEMPLATES_DIR).'<br />';
		}
	}
	break;
	
	case 'file':
	
	{

	if(empty($_GET['file']))locate(PATH.'admin_tpl.php');
	$filename = rawurldecode($_GET['file']);

	if(!preg_match('~^[A-Za-z0-9-_.]+$~', $filename) || !file_exists(TEMPLATES_DIR.$filename))locate(PATH.'admin_tpl.php');

	$filename = TEMPLATES_DIR.$filename;
	$file = $_GET['file'];

	if(!is_writable($filename))echo '<div class="err">ფაილზე "'.$filename.'" მინიჭებული უფლებები არ იძლევა მასში ჩაწერის უფლებას.</div>';

	if((file_exists($filename.'.bak') && !is_writable($filename.'.bak')) || !is_writable(TEMPLATES_DIR))echo '<div class="err">BAK-ფაილის შექმნა შეუძლებელია.</div>';

			switch(ACT)
		{
		default:
		
		{

		echo '<div class="head">რედაქტირება: '.$file.'</div>';

		if(isset($_GET['edit']) && isset($_POST['content']) && postval('edit'))
			{
			$content = $_POST['content'];

			
			if(copy($filename, $filename.'.bak'))
				{
				
				if(file_write($filename, 'w', $content))
					{
					$info = 'write';
					}
				else
					{
					$info = 'no_wrie_file';
					}
				}
			else
				{
				$info = 'no_write_bakfile';
				}
			locate(PATH.'admin_tpl.php?mode=file&file='.rawurlencode($file).'&info='.$info);
			}

		$infos = array
			(
			'write' => array('ფაილში წარმატებით ჩაიწერა', 'msg'),
			'no_write_file' => array('ფაილში ვერ ჩაიწერა', 'err'),
			'no_write_bakfile' => array('ვერ ჩაიწერა BAK-ფაილში', 'err'),
			'restore' => array('ფაილი წარმატებით აღდგა', 'msg')
			);
		if(isset($_GET['info']) && isset($infos[$_GET['info']]))echo '<div class="'.$infos[$_GET['info']][1].'">'.$infos[$_GET['info']][0].'</div>';

		$lines = file($filename);
		$count_lines = count($lines);
		$filemtime = filemtime($filename);

		echo '<small>'.$count_lines.' '.postfix($count_lines, 'ხაზი', 'ხაზი' ,'ხაზი').', '.xsize(filesize($filename)).', '.(($filemtime > TIME_TODAY) ? 'ცვლილების შემდეგ გავიდა '.((TIME - $filemtime) > 10 ? xtime(TIME - $filemtime, true) : 'ძალიან ცოტა დრო') : 'შეიცვალა '.xdate($filemtime)).'</small><br />';

		echo '<form action="'.PATH.'admin_tpl.php?mode=file&file='.rawurlencode($file).'&edit&'.RAND.'" method="post" class="unit"><input type="hidden" name="edit" value="1"/>';
		echo '<textarea name="content" name="content" style="width:100%" rows="'.(min($count_lines, (MY_WEB ? 35 : 15)) + 2).'">'.htmlspecialchars(implode('', $lines), ENT_QUOTES, 'utf-8').'</textarea>';
		echo '<input type="submit" value="შენახვა"/>';

		echo '</form>';
		echo '&raquo; <a href="'.PATH.'admin_tpl.php?mode=file&file='.rawurlencode($file).'&act=color">კოდების ნახვა</a><br />';
		if(file_exists($filename.'.bak') && file_get_contents($filename.'.bak') != file_get_contents($filename))echo '&raquo; <a href="'.PATH.'admin_tpl.php?mode=file&file='.rawurlencode($file).'&act=bakfile">აღდგენა BAK ფაილიდან</a> (შეიქმნა '.xdate(filemtime($filename.'.bak')).')<br />';
		echo '&raquo; <a href="'.PATH.'admin_tpl.php?mode=file&file='.rawurlencode($file).'&act=del">ფაილის წაშლა</a><br />';

		}
		break;
		
		case 'del':
		
		{

		echo '<div class="head">იშლება: '.$file.'</div>';

		if(isset($_GET['delete']))
			{
			if(!file_exists($filename.'.bak') || unlink($filename.'.bak'))
				{
				if(unlink($filename))
					{
					echo '<font color="green">ფაილი &quot;'.$file.'&quot; წაიშალა.</font><br />';
					echo '<a href="'.PATH.'admin_tpl.php">ფაილების ჩამონათვალი</a><br />';
					}
				else
					{
					echo '<font color="red">ვერ ხერხდება ფაილის წაშლა</font><br />';
					}
				}
			else
				{
				echo '<font color="red">ვერ ხერხდება BAK ფაილის წაშლა</font><br />';
				}
			echo '<br />';
			}
		else
			{
			echo 'ნამდვილად გსურთ რომ წაშალოთ ფაილი &quot;'.$file.'&quot;<br />';
			echo 'თუ ეს ფაილი სკრიპტში შედის, წაშლის შემთხევაში გვერდი აღარ იმუშავებს!<br />';
			echo '<a href="'.PATH.'admin_tpl.php?mode=file&file='.rawurlencode($file).'&act=del&delete">წაშლა</a> / <a href="'.PATH.'admin_tpl.php?mode=file&file='.rawurlencode($file).'">უარყოფა</a><br />';
			echo '<br />';
			}

		}
		break;
		
		case 'color':
		
		{

		echo '<div class="head">კოდების ჩვენება: '.$file.'</div>';

		$content = htmlspecialchars(file_get_contents($filename), ENT_QUOTES, 'utf-8');

		$content = highlight_template($content);

		$content = highlight_html($content);

		echo '<div class="code">'.nl2br($content).'</div>';


		}
		break;
		
		case 'bakfile':
		
		{

		echo '<div class="head">აღდგენა: '.$file.'</div>';

		if(file_exists($filename.'.bak'))
			{

			if(isset($_GET['restore']))
				{
				if(copy($filename.'.bak', $filename))
					{
					$info = 'restore';
					}
				else
					{
					$info = 'no_write_file';
					}
				locate(PATH.'admin_tpl.php?mode=file&file='.rawurlencode($file).'&info='.$info);
				}

			echo 'ფაილის შექმნის თარიღი: '.xdate(filemtime($filename.'.bak')).'<br />';
			echo 'ზომა: '.xsize(filesize($filename.'.bak')).'<br />';
			echo '<a href="'.PATH.'admin_tpl.php?mode=file&file='.rawurlencode($file).'&act=bakfile&restore">ფაილის აღდგენა '.$file.' ფაილიდან</a><br />';
			if(!isset($_GET['view']))echo '<a href="'.PATH.'admin_tpl.php?mode=file&file='.rawurlencode($file).'&act=bakfile&view">კოდების ნახვა</a><br />';

			similar_text(file_get_contents($filename), file_get_contents($filename.'.bak'), $persent);
			echo 'ფაილების მზგავსება: <b>'.round($persent, 4).'%</b><br />';

			echo '<br />';

			if(isset($_GET['view']))
				{
				echo '<b>შინაარსი</b>: <br />';
				$content = htmlspecialchars(file_get_contents($filename.'.bak'), ENT_QUOTES, 'utf-8');

				$content = highlight_template($content);

				$content = highlight_html($content);

				echo '<div class="code">'.nl2br($content).'</div>';

				echo '<br />';
				}

			}
		else
			{
			echo '<font color="red">BAK ფაილი არ არსებობს</font><br />';
			}

		}
		}

	if(ACT != null)echo '<a href="'.PATH.'admin_tpl.php?mode=file&file='.rawurlencode($file).'">ფაილი &quot;'.$file.'&quot;</a><br />';

	}
	break;
	}

if(MODE != null)echo '<a href="'.PATH.'admin_tpl.php">ფაილების ჩამონათვალი</a><br />';
echo '<a href="'.PATH.'admin.php">სამართავი პანელი</a><br />';
echo '<a href="'.PATH.'index.php">ფორუმი</a><br />';
echo '<div class="foot">&copy; 2020</div><small>'.round(microtime(true) - MT, 3).'</small></body></html>';

ob_end_flush();
exit;


?>